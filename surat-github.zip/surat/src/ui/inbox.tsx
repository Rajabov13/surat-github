import React, { useEffect, useState } from 'react';
import { answerRequest } from '../core/actions';
import { getPost, groupNotifs, notifications, type NotifGroup } from '../core/derive';
import { patchMe, S, useStore } from '../core/store';
import type { NotifType } from '../core/types';
import { cx } from '../core/util';
import { t, timeAgo } from './i18n';
import { Icon } from './icons';
import { act, Avatar, Empty, FollowButton, Header, ReadOnlyNote } from './kit';
import { go } from './nav';
import { Thumb } from './player';
import { ChatList } from './chat';

const FILTERS: [string, NotifType[] | null][] = [
  ['Все', null],
  ['Лайки', ['like', 'clike']],
  ['Комментарии', ['comment', 'reply']],
  ['Упоминания', ['mention', 'tag']],
  ['Подписчики', ['follow', 'request']],
  ['Репосты и дуэты', ['repost', 'duet', 'stitch']],
];

function verb(g: NotifGroup): string {
  const n = g.items.length;
  const v: Record<NotifType, string> = {
    like: 'оценил(а) вашу публикацию',
    clike: 'оценил(а) ваш комментарий',
    comment: 'прокомментировал(а)',
    reply: 'ответил(а) на ваш комментарий',
    mention: 'упомянул(а) вас',
    tag: 'отметил(а) вас в публикации',
    follow: 'подписался(-ась) на вас',
    request: 'хочет подписаться на вас',
    repost: 'сделал(а) репост вашей публикации',
    duet: 'записал(а) дуэт с вашим видео',
    stitch: 'сделал(а) стежок с вашим видео',
  };
  const first = S.u[g.items[0].by]?.nm || S.u[g.items[0].by]?.un || '…';
  const who = n > 1 ? t('{a} и ещё {n}', { a: first, n: n - 1 }) : first;
  return `${who} ${t(v[g.type])}`;
}

export function NotifRow({ g }: { g: NotifGroup }): React.ReactElement {
  const first = g.items[0];
  const post = g.post ? getPost(g.post) : undefined;
  const unread = g.ts > (S.me.ns || 0);
  return (
    <div className={cx('row notif', unread && 'unread')} onClick={() => (post ? go('post', { postKey: post.key, openComments: g.type === 'comment' || g.type === 'reply' }) : go('profile', { uid: first.by }))}>
      <div className="notif-avs">
        <Avatar uid={first.by} size={44} onClick={() => go('profile', { uid: first.by })} />
        {g.items.length > 1 && <Avatar uid={g.items[1].by} size={26} />}
      </div>
      <div className="grow min0">
        <div className="notif-text">{verb(g)}</div>
        {first.text && <div className="notif-quote ell">{first.text}</div>}
        <small className="muted">{timeAgo(g.ts)}</small>
      </div>
      {g.type === 'request' ? (
        <div className="row gap-s" onClick={(e) => e.stopPropagation()}>
          <button className="btn btn-primary btn-sm" onClick={() => void act(() => answerRequest(first.by, true), t('Заявка принята'))}>
            {t('Принять')}
          </button>
          <button className="btn btn-muted btn-sm" onClick={() => void act(() => answerRequest(first.by, false))}>
            ×
          </button>
        </div>
      ) : g.type === 'follow' && g.items.length === 1 ? (
        <div onClick={(e) => e.stopPropagation()}>
          <FollowButton uid={first.by} small />
        </div>
      ) : post ? (
        <div className="notif-thumb">
          <Thumb post={post} />
        </div>
      ) : null}
    </div>
  );
}

export function NotificationsScreen(): React.ReactElement {
  useStore();
  const [f, setF] = useState(0);
  const all = notifications();
  const types = FILTERS[f][1];
  const groups = groupNotifs(types ? all.filter((n) => types.includes(n.type)) : all);
  useEffect(() => {
    const latest = all[0]?.ts || 0;
    return () => {
      if (S.uid && !S.readOnly && latest > (S.me.ns || 0)) void patchMe({ ns: Date.now() }).catch(() => undefined);
    };
  }, [all[0]?.ts]);
  return (
    <div className="screen">
      <Header title={t('Вся активность')} />
      <div className="hscroll chips pad-x">
        {FILTERS.map(([label], i) => (
          <button key={label} className={cx('chip', f === i && 'on')} onClick={() => setF(i)}>
            {t(label)}
          </button>
        ))}
      </div>
      <div className="scroll">
        {groups.length === 0 && <Empty icon="bell" title={t('Пока тихо')} text={t('Здесь появятся лайки, комментарии и новые подписчики')} />}
        {groups.map((g, i) => (
          <NotifRow key={i + g.type + g.ts} g={g} />
        ))}
      </div>
    </div>
  );
}

/** The Inbox tab: latest activity on top, chats below. */
export function InboxScreen(): React.ReactElement {
  useStore();
  const all = notifications();
  const groups = groupNotifs(all).slice(0, 4);
  const unread = all.filter((n) => n.ts > (S.me.ns || 0)).length;
  const newFollowers = all.filter((n) => (n.type === 'follow' || n.type === 'request') && n.ts > (S.me.ns || 0)).length;
  return (
    <div className="screen inbox">
      <header className="hdr">
        <span />
        <div className="hdr-title">
          <b>{t('Входящие')}</b>
        </div>
        <div className="hdr-right">
          <button className="icon-btn" onClick={() => go('newchat')} aria-label={t('Новое сообщение')}>
            <Icon n="edit" />
          </button>
        </div>
      </header>
      <ReadOnlyNote />
      <div className="scroll">
        <button className="row inbox-entry" onClick={() => go('follows', { uid: S.uid, tab: newFollowers ? 'followers' : 'suggested' })}>
          <span className="entry-ic ic-blue">
            <Icon n="users" size={22} />
          </span>
          <span className="grow left">
            <b>{t('Новые подписчики')}</b>
            <small className="muted block">{newFollowers ? t('{n} новых', { n: newFollowers }) : t('Посмотрите, кого вы можете знать')}</small>
          </span>
          {newFollowers > 0 && <span className="count">{newFollowers}</span>}
        </button>
        <button className="row inbox-entry" onClick={() => go('notifications')}>
          <span className="entry-ic ic-accent">
            <Icon n="bell" size={22} />
          </span>
          <span className="grow left">
            <b>{t('Активность')}</b>
            <small className="muted block">{groups[0] ? verb(groups[0]) : t('Лайки, комментарии, упоминания')}</small>
          </span>
          {unread > 0 && <span className="count">{unread > 99 ? '99+' : unread}</span>}
        </button>
        {groups.length > 0 && (
          <div className="inbox-recent">
            {groups.map((g, i) => (
              <NotifRow key={i} g={g} />
            ))}
          </div>
        )}
        <div className="sec-hdr pad-x">
          <b>{t('Сообщения')}</b>
        </div>
        <ChatList />
      </div>
    </div>
  );
}
