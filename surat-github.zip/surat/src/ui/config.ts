export const cfg = {
  kind: 'surat',
  name: 'Surat',
  url: '', // published artifact link, used for share links and QR codes
  watermark: 'Surat',
};

export function shareLink(hash: string): string {
  const base = cfg.url || location.href.split('#')[0];
  return `${base}#${hash}`;
}
