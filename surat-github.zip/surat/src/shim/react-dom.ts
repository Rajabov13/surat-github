const RD = (window as unknown as { ReactDOM: typeof import('react-dom/client') & typeof import('react-dom') }).ReactDOM;
export default RD;
export const { createRoot } = RD;
export const { createPortal } = RD;
