import React, { useState } from 'react';
import { modBan, modBanners, modRemove, modResolve, modTagDesc, modTrends } from '../core/actions';
import { agg, getPost, searchUsers } from '../core/derive';
import { S, useStore } from '../core/store';
import type { Banner, Report } from '../core/types';
import { DAY, fmtCount, live, now, pkey, rid, splitKey } from '../core/util';
import { t, timeAgo } from './i18n';
import { act, Avatar, Empty, Header, Tabs, UserRow } from './kit';
import { confirmDialog, go } from './nav';
import { Thumb } from './player';

interface RepX extends Report {
  key: string;
  by: string;
}

function reportTarget(r: RepX): { uid?: string; content?: string } {
  if (r.k === 'user') return { uid: r.id };
  if (r.k === 'post') return { uid: splitKey(r.id)[0], content: r.id };
  if (r.k === 'comment') return { uid: splitKey(r.id)[0], content: r.id };
  if (r.k === 'story') return { uid: splitKey(r.id)[0], content: r.id };
  if (r.k === 'msg') return { uid: splitKey(r.id.split('/')[1] || '')[0] };
  return {};
}

export function AdminScreen(): React.ReactElement {
  useStore();
  const [tab, setTab] = useState<'reports' | 'users' | 'stats' | 'trends'>('reports');
  if (!S.isOwner) return <div className="screen"><Header title={t('Админ-панель')} /><Empty icon="shield" title={t('Только для владельца приложения')} /></div>;
  return (
    <div className="screen">
      <Header title={t('Админ-панель')} />
      <Tabs className="tabs-scroll" value={tab} onChange={setTab} items={[['reports', t('Жалобы')], ['users', t('Пользователи')], ['stats', t('Статистика')], ['trends', t('Тренды и баннеры')]]} />
      <div className="scroll">
        {tab === 'reports' && <Reports />}
        {tab === 'users' && <Users />}
        {tab === 'stats' && <Stats />}
        {tab === 'trends' && <Trends />}
      </div>
    </div>
  );
}

function Reports(): React.ReactElement {
  const [showDone, setShowDone] = useState(false);
  const list: RepX[] = [];
  for (const by in S.reports) for (const [id, r] of live(S.reports[by].r)) list.push({ ...r, key: pkey(by, id), by });
  const resolved = S.mod.resolved || {};
  const shown = list.filter((r) => !!resolved[r.key] === showDone).sort((a, b) => b.ts - a.ts);
  const A = agg();
  return (
    <div>
      <div className="chips pad-x">
        <button className={'chip' + (!showDone ? ' on' : '')} onClick={() => setShowDone(false)}>
          {t('Открытые')} · {list.filter((r) => !resolved[r.key]).length}
        </button>
        <button className={'chip' + (showDone ? ' on' : '')} onClick={() => setShowDone(true)}>
          {t('Закрытые')}
        </button>
      </div>
      {shown.length === 0 && <Empty icon="check" title={t('Очередь пуста')} />}
      {shown.map((r) => {
        const tg = reportTarget(r);
        const post = r.k === 'post' ? getPost(r.id) : undefined;
        const comment = r.k === 'comment' ? A.commentByKey.get(r.id) : undefined;
        return (
          <div key={r.key} className="card report">
            <div className="row gap-s">
              <span className="badge">{t({ post: 'Публикация', comment: 'Комментарий', user: 'Пользователь', msg: 'Сообщение', story: 'История' }[r.k])}</span>
              <b className="grow">{t(r.why)}</b>
              <small className="muted">{timeAgo(r.ts)}</small>
            </div>
            {r.note && <p className="muted">«{r.note}»</p>}
            <small className="muted">
              {t('Пожаловался')}: @{S.u[r.by]?.un}
            </small>
            {post && (
              <div className="row gap">
                <div className="stat-thumb">
                  <Thumb post={post} onClick={() => go('post', { postKey: post.key })} />
                </div>
                <span className="ell">{post.cap}</span>
              </div>
            )}
            {comment && <p className="quote">{comment.t}</p>}
            {r.k === 'msg' && <small className="muted">{t('Сообщения зашифрованы — содержимое недоступно модератору.')}</small>}
            {tg.uid && <UserRow uid={tg.uid} right={S.mod.bans?.[tg.uid] ? <span className="badge">{t('Забанен')}</span> : <span />} />}
            <div className="chips">
              {tg.content && !S.mod.removed?.[tg.content] && (
                <button className="chip danger" onClick={() => void act(async () => { await modRemove(tg.content!); await modResolve(r.key); }, t('Контент удалён'))}>
                  {t('Удалить контент')}
                </button>
              )}
              {tg.content && S.mod.removed?.[tg.content] && (
                <button className="chip" onClick={() => void act(() => modRemove(tg.content!, false), t('Восстановлено'))}>
                  {t('Восстановить')}
                </button>
              )}
              {tg.uid && !S.mod.bans?.[tg.uid] && tg.uid !== S.uid && (
                <button className="chip danger" onClick={async () => (await confirmDialog(t('Забанить @{u}?', { u: S.u[tg.uid!]?.un || '' }), t('Забанить'))) && void act(async () => { await modBan(tg.uid!); await modResolve(r.key); }, t('Пользователь забанен'))}>
                  {t('Забанить автора')}
                </button>
              )}
              {!resolved[r.key] && (
                <button className="chip" onClick={() => void act(() => modResolve(r.key))}>
                  {t('Отклонить жалобу')}
                </button>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}

function Users(): React.ReactElement {
  const [q, setQ] = useState('');
  const bans = live(S.mod.bans).map(([u]) => u);
  const list = q ? searchUsers(q, 40) : Object.keys(S.u).filter((u) => !S.u[u].del).sort((a, b) => S.u[b].ts - S.u[a].ts).slice(0, 100);
  return (
    <div>
      <div className="pad-x">
        <input id="adm-q" className="input" placeholder={t('Поиск пользователей')} value={q} onChange={(e) => setQ(e.target.value)} />
      </div>
      {bans.length > 0 && (
        <div className="set-group">
          <small className="set-label">{t('Забаненные')}</small>
          {bans.map((u) => (
            <div key={u} className="row user-row">
              <Avatar uid={u} size={40} />
              <span className="grow">@{S.u[u]?.un}</span>
              <button className="btn btn-muted btn-sm" onClick={() => void act(() => modBan(u, false), t('Бан снят'))}>
                {t('Разбанить')}
              </button>
            </div>
          ))}
        </div>
      )}
      {list.map((u) => (
        <UserRow
          key={u}
          uid={u}
          sub={`@${S.u[u]?.un} · ${new Date(S.u[u]?.ts || 0).toLocaleDateString()}`}
          right={
            u === S.uid ? (
              <span className="badge">{t('Вы')}</span>
            ) : S.mod.bans?.[u] ? (
              <button className="btn btn-muted btn-sm" onClick={() => void act(() => modBan(u, false))}>
                {t('Разбанить')}
              </button>
            ) : (
              <button className="btn btn-danger btn-sm" onClick={async () => (await confirmDialog(t('Забанить @{u}?', { u: S.u[u]?.un || '' }), t('Забанить'))) && void act(() => modBan(u, true), t('Пользователь забанен'))}>
                {t('Бан')}
              </button>
            )
          }
        />
      ))}
    </div>
  );
}

function Stats(): React.ReactElement {
  const A = agg();
  const users = Object.keys(S.u).filter((u) => !S.u[u].del);
  const posts = [...A.posts.values()];
  const active = Object.keys(S.v).filter((v) => live(S.v[v].pv).some(([, x]) => now() - x.l < DAY)).length;
  const newUsers = users.filter((u) => now() - S.u[u].ts < 7 * DAY).length;
  const tiles: [string, number][] = [
    ['Пользователи', users.length],
    ['Новые за 7 дней', newUsers],
    ['Активные за сутки', active],
    ['Публикации', posts.length],
    ['Видео', posts.filter((p) => p.t === 'video').length],
    ['Фото-карусели', posts.filter((p) => p.t === 'photo').length],
    ['Текстовые посты', posts.filter((p) => p.t === 'text').length],
    ['Комментарии', A.commentByKey.size],
    ['Лайки', posts.reduce((a, p) => a + p.likes, 0)],
    ['Просмотры', posts.reduce((a, p) => a + p.views, 0)],
    ['Истории сейчас', [...A.stories.values()].reduce((a, s) => a + s.length, 0)],
    ['Жалобы', Object.values(S.reports).reduce((a, r) => a + live(r.r).length, 0)],
  ];
  return (
    <div className="tiles pad">
      {tiles.map(([l, v]) => (
        <div key={l} className="tile">
          <small>{t(l)}</small>
          <b>{fmtCount(v)}</b>
        </div>
      ))}
    </div>
  );
}

function Trends(): React.ReactElement {
  const [tag, setTag] = useState('');
  const [b, setB] = useState<Banner>({ id: '', title: '', text: '', tag: '', color: 'linear-gradient(135deg,#ff5a36,#8b5cf6)' });
  const [desc, setDesc] = useState({ tag: '', d: '' });
  const trends = S.mod.trends || [];
  const banners = S.mod.banners || [];
  return (
    <div className="pad col gap">
      <div className="card col gap-s">
        <b>{t('Закреплённые тренды')}</b>
        <div className="row gap-s">
          <input id="adm-tag" className="input grow" placeholder="#" value={tag} onChange={(e) => setTag(e.target.value.replace(/[#\s]/g, '').toLowerCase())} />
          <button className="btn btn-primary btn-sm" disabled={!tag} onClick={() => (void act(() => modTrends([...new Set([...trends, tag])])), setTag(''))}>
            {t('Добавить')}
          </button>
        </div>
        <div className="chips">
          {trends.map((x) => (
            <button key={x} className="chip on" onClick={() => void act(() => modTrends(trends.filter((y) => y !== x)))}>
              #{x} ×
            </button>
          ))}
        </div>
      </div>
      <div className="card col gap-s">
        <b>{t('Описание хэштега')}</b>
        <input id="adm-desc-tag" className="input" placeholder="#" value={desc.tag} onChange={(e) => setDesc({ ...desc, tag: e.target.value.replace(/[#\s]/g, '').toLowerCase() })} />
        <textarea id="adm-desc" className="input" rows={2} maxLength={200} value={desc.d} onChange={(e) => setDesc({ ...desc, d: e.target.value })} />
        <button className="btn btn-primary btn-sm" disabled={!desc.tag} onClick={() => void act(() => modTagDesc(desc.tag, desc.d), t('Сохранено'))}>
          {t('Сохранить')}
        </button>
      </div>
      <div className="card col gap-s">
        <b>{t('Баннеры в обзоре')}</b>
        {banners.map((x) => (
          <div key={x.id} className="banner" style={{ background: x.color }}>
            <b>{x.title}</b>
            <span>{x.text}</span>
            <button className="chip" onClick={() => void act(() => modBanners(banners.filter((y) => y.id !== x.id)))}>
              {t('Удалить')}
            </button>
          </div>
        ))}
        <input id="adm-b-title" className="input" placeholder={t('Заголовок')} maxLength={40} value={b.title} onChange={(e) => setB({ ...b, title: e.target.value })} />
        <input id="adm-b-text" className="input" placeholder={t('Текст')} maxLength={80} value={b.text} onChange={(e) => setB({ ...b, text: e.target.value })} />
        <input id="adm-b-tag" className="input" placeholder={t('Хэштег для перехода (необязательно)')} value={b.tag} onChange={(e) => setB({ ...b, tag: e.target.value.replace(/[#\s]/g, '').toLowerCase() })} />
        <select id="adm-b-color" className="select" value={b.color} onChange={(e) => setB({ ...b, color: e.target.value })}>
          <option value="linear-gradient(135deg,#ff5a36,#8b5cf6)">{t('Закат')}</option>
          <option value="linear-gradient(135deg,#0ea5e9,#22c55e)">{t('Море')}</option>
          <option value="linear-gradient(135deg,#f59e0b,#ef4444)">{t('Огонь')}</option>
          <option value="linear-gradient(135deg,#14b8a6,#6366f1)">{t('Мята')}</option>
        </select>
        <button className="btn btn-primary" disabled={!b.title} onClick={() => (void act(() => modBanners([...banners, { ...b, id: rid(6) }]), t('Баннер добавлен')), setB({ ...b, title: '', text: '', tag: '' }))}>
          {t('Добавить баннер')}
        </button>
      </div>
    </div>
  );
}
