import React, { useState } from 'react';
import { block, deleteAccount, exportData, resetRecommendations, saveSettings, updateProfile } from '../core/actions';
import { S, useStore } from '../core/store';
import type { Audience, Lang, Profile } from '../core/types';
import { live, lsSet } from '../core/util';
import { cfg } from './config';
import { t } from './i18n';
import { Icon } from './icons';
import { act, Header, MenuItem, Toggle, UserRow } from './kit';
import { confirmDialog, go, toast } from './nav';

function AudienceSelect({ id, value, onChange }: { id: string; value: Audience | undefined; onChange: (v: Audience) => void }): React.ReactElement {
  return (
    <select id={id} className="select" value={value || 'all'} onChange={(e) => onChange(e.target.value as Audience)}>
      <option value="all">{t('Все')}</option>
      <option value="friends">{t('Друзья')}</option>
      <option value="none">{t('Никто')}</option>
    </select>
  );
}

export function SettingsScreen(): React.ReactElement {
  useStore();
  return (
    <div className="screen">
      <Header title={t('Настройки и конфиденциальность')} />
      <div className="scroll">
        <div className="set-group">
          <small className="set-label">{t('Аккаунт')}</small>
          <MenuItem icon="user" label={t('Аккаунт')} onClick={() => go('set-account')} />
          <MenuItem icon="lock" label={t('Конфиденциальность')} onClick={() => go('set-privacy')} />
          <MenuItem icon="shield" label={t('Заблокированные и скрытые слова')} onClick={() => go('set-blocked')} />
          <MenuItem icon="chart" label={t('Аналитика для авторов')} onClick={() => go('analytics')} />
          <MenuItem icon="file" label={t('Черновики')} onClick={() => go('drafts')} />
        </div>
        <div className="set-group">
          <small className="set-label">{t('Контент и активность')}</small>
          <MenuItem icon="bell" label={t('Уведомления')} onClick={() => go('set-notif')} />
          <MenuItem icon="filter" label={t('Предпочтения контента')} onClick={() => go('set-content')} />
          <MenuItem icon="clock" label={t('Экранное время')} onClick={() => go('set-time')} />
          <MenuItem icon="download" label={t('Экономия трафика')} onClick={() => go('set-data')} />
          <MenuItem icon="globe" label={t('Язык и оформление')} onClick={() => go('set-display')} />
        </div>
        {S.isOwner && (
          <div className="set-group">
            <small className="set-label">{t('Администрирование')}</small>
            <MenuItem icon="shield" label={t('Админ-панель')} onClick={() => go('admin')} />
          </div>
        )}
        <div className="set-group">
          <small className="set-label">{t('О приложении')}</small>
          <MenuItem icon="info" label={t('Как это работает')} onClick={() => go('about')} />
        </div>
      </div>
    </div>
  );
}

export function AccountSettings(): React.ReactElement {
  useStore();
  const me = S.uid!;
  const [busy, setBusy] = useState(false);
  return (
    <div className="screen">
      <Header title={t('Аккаунт')} />
      <div className="scroll pad col gap">
        <div className="card col gap-s">
          <div className="row">
            <span className="grow">{t('Ник')}</span>
            <b>@{S.u[me]?.un}</b>
          </div>
          <button className="btn btn-muted" onClick={() => go('editprofile')}>
            {t('Изменить ник и профиль')}
          </button>
          <small className="muted">{t('Вход выполнен через ваш аккаунт Claude: отдельные email, телефон и пароль в {app} не нужны.', { app: cfg.name })}</small>
        </div>
        <button className="btn btn-muted" disabled={busy} onClick={() => void act(async () => { setBusy(true); try { if (!(await exportData())) toast(t('Сохранение отменено')); } finally { setBusy(false); } })}>
          <Icon n="download" size={18} /> {t('Скачать мои данные')}
        </button>
        <button
          className="btn btn-danger"
          onClick={async () => {
            if (!(await confirmDialog(t('Удалить аккаунт?'), t('Удалить навсегда'), t('Профиль, публикации, комментарии, лайки и сообщения будут удалены без возможности восстановления.')))) return;
            if (await act(() => deleteAccount(), t('Аккаунт удалён'))) go('home');
          }}
        >
          <Icon n="trash" size={18} /> {t('Удалить аккаунт')}
        </button>
      </div>
    </div>
  );
}

export function PrivacySettings(): React.ReactElement {
  useStore();
  const me = S.uid!;
  const p = S.u[me];
  if (!p) return <div className="screen" />;
  const set = (ch: Partial<Profile>): void => void act(() => updateProfile(ch));
  return (
    <div className="screen">
      <Header title={t('Конфиденциальность')} />
      <div className="scroll">
        <div className="set-group">
          <Toggle id="pv-priv" label={t('Закрытый аккаунт')} sub={t('Подписка только по заявке, публикации видят только подписчики')} on={!!p.priv} onChange={(v) => set({ priv: v })} />
          <div className="row">
            <span className="grow">{t('Кто может комментировать')}</span>
            <AudienceSelect id="pv-cmt" value={p.cmt} onChange={(v) => set({ cmt: v })} />
          </div>
          <div className="row">
            <span className="grow">{t('Кто может писать мне')}</span>
            <AudienceSelect id="pv-dm" value={p.dm} onChange={(v) => set({ dm: v })} />
          </div>
          <div className="row">
            <span className="grow">{t('Кто может делать дуэт и стежок')}</span>
            <AudienceSelect id="pv-duet" value={p.duet} onChange={(v) => set({ duet: v })} />
          </div>
          <Toggle id="pv-dl" label={t('Разрешить скачивать мои видео')} on={p.dl !== false} onChange={(v) => set({ dl: v })} />
          <Toggle id="pv-likes" label={t('Скрыть понравившееся')} on={!!p.hideLikes} onChange={(v) => set({ hideLikes: v })} />
          <Toggle id="pv-fol" label={t('Скрыть список подписок')} on={!!p.hideFollowing} onChange={(v) => set({ hideFollowing: v })} />
          <Toggle id="pv-pv" label={t('История просмотров профиля')} sub={t('Если выключить, вы не увидите, кто смотрел ваш профиль, и другие не увидят вас')} on={!p.pvOff} onChange={(v) => set({ pvOff: !v })} />
          <Toggle id="pv-act" label={t('Статус активности')} sub={t('Показывать, когда вы в сети')} on={!p.actOff} onChange={(v) => set({ actOff: !v })} />
        </div>
      </div>
    </div>
  );
}

export function BlockedSettings(): React.ReactElement {
  useStore();
  const me = S.uid!;
  const blocked = live(S.g[me]?.blk).map(([u]) => u);
  const [word, setWord] = useState('');
  const sw = S.u[me]?.sw || [];
  return (
    <div className="screen">
      <Header title={t('Заблокированные и скрытые слова')} />
      <div className="scroll">
        <div className="set-group">
          <small className="set-label">{t('Заблокированные пользователи')}</small>
          {blocked.length === 0 && <p className="muted pad-x">{t('Список пуст')}</p>}
          {blocked.map((u) => (
            <UserRow key={u} uid={u} right={<button className="btn btn-muted btn-sm" onClick={() => void act(() => block(u, false), t('Пользователь разблокирован'))}>{t('Разблокировать')}</button>} />
          ))}
        </div>
        <div className="set-group pad-x col gap-s">
          <small className="set-label">{t('Скрытые слова в комментариях')}</small>
          <small className="muted">{t('Комментарии с этими словами под вашими публикациями будут скрыты от всех, кроме автора комментария')}</small>
          <div className="row gap-s">
            <input id="sw-word" className="input grow" value={word} maxLength={30} onChange={(e) => setWord(e.target.value)} placeholder={t('Слово или фраза')} />
            <button className="btn btn-primary btn-sm" disabled={!word.trim()} onClick={() => (void act(() => updateProfile({ sw: [...new Set([...sw, word.trim().toLowerCase()])].slice(0, 100) })), setWord(''))}>
              {t('Добавить')}
            </button>
          </div>
          <div className="chips">
            {sw.map((w) => (
              <button key={w} className="chip on" onClick={() => void act(() => updateProfile({ sw: sw.filter((x) => x !== w) }))}>
                {w} ×
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

const NT: [string, string][] = [
  ['like', 'Лайки'],
  ['comment', 'Комментарии'],
  ['reply', 'Ответы'],
  ['mention', 'Упоминания'],
  ['tag', 'Отметки на публикациях'],
  ['follow', 'Новые подписчики'],
  ['request', 'Заявки на подписку'],
  ['repost', 'Репосты'],
  ['duet', 'Дуэты'],
  ['stitch', 'Стежки'],
  ['clike', 'Лайки комментариев'],
];

export function NotifSettings(): React.ReactElement {
  useStore();
  const nt = S.me.set?.nt || {};
  return (
    <div className="screen">
      <Header title={t('Уведомления')} />
      <div className="scroll">
        <p className="muted pad">{t('Выберите, о чём сообщать во «Входящих» и на значке. Push-уведомления на телефон в веб-версии недоступны.')}</p>
        <div className="set-group">
          {NT.map(([k, label]) => (
            <Toggle key={k} id={'nt-' + k} label={t(label)} on={nt[k] !== false} onChange={(v) => void act(() => saveSettings({ nt: { ...nt, [k]: v } }))} />
          ))}
        </div>
      </div>
    </div>
  );
}

export function ContentSettings(): React.ReactElement {
  useStore();
  const kw = S.me.set?.kw || [];
  const [w, setW] = useState('');
  return (
    <div className="screen">
      <Header title={t('Предпочтения контента')} />
      <div className="scroll pad col gap">
        <div className="card col gap-s">
          <b>{t('Фильтр по ключевым словам')}</b>
          <small className="muted">{t('Публикации с этими словами в описании или хэштегах не попадут в ваши ленты')}</small>
          <div className="row gap-s">
            <input id="kw-word" className="input grow" value={w} maxLength={30} onChange={(e) => setW(e.target.value)} />
            <button className="btn btn-primary btn-sm" disabled={!w.trim()} onClick={() => (void act(() => saveSettings({ kw: [...new Set([...kw, w.trim().toLowerCase()])] })), setW(''))}>
              {t('Добавить')}
            </button>
          </div>
          <div className="chips">
            {kw.map((x) => (
              <button key={x} className="chip on" onClick={() => void act(() => saveSettings({ kw: kw.filter((y) => y !== x) }))}>
                {x} ×
              </button>
            ))}
          </div>
        </div>
        <div className="card col gap-s">
          <b>{t('Сбросить рекомендации')}</b>
          <small className="muted">{t('Лента «Для вас» начнёт подбираться заново, как для нового пользователя')}</small>
          <button className="btn btn-muted" onClick={async () => (await confirmDialog(t('Сбросить рекомендации?'), t('Сбросить'))) && void act(() => resetRecommendations(), t('Рекомендации сброшены'))}>
            {t('Сбросить')}
          </button>
        </div>
      </div>
    </div>
  );
}

export function TimeSettings(): React.ReactElement {
  useStore();
  const s = S.me.set || {};
  return (
    <div className="screen">
      <Header title={t('Экранное время')} />
      <div className="scroll pad col gap">
        <div className="card col gap-s">
          <b>{t('Напоминание сделать перерыв')}</b>
          <select id="st-brk" className="select" value={s.brk || 0} onChange={(e) => void act(() => saveSettings({ brk: Number(e.target.value) }))}>
            <option value={0}>{t('Выкл')}</option>
            {[10, 20, 30, 45, 60, 90].map((m) => (
              <option key={m} value={m}>
                {t('Каждые {m} мин', { m })}
              </option>
            ))}
          </select>
        </div>
        <div className="card col gap-s">
          <b>{t('Дневной лимит')}</b>
          <select id="st-lim" className="select" value={s.lim || 0} onChange={(e) => void act(() => saveSettings({ lim: Number(e.target.value) }))}>
            <option value={0}>{t('Выкл')}</option>
            {[30, 60, 90, 120, 180].map((m) => (
              <option key={m} value={m}>
                {m} {t('мин')}
              </option>
            ))}
          </select>
          <small className="muted">{t('Сегодня в приложении: {m} мин', { m: Math.round(todayMinutes()) })}</small>
        </div>
      </div>
    </div>
  );
}
export function todayMinutes(): number {
  try {
    const d = JSON.parse(localStorage.getItem('st') || '{}') as { day?: string; ms?: number };
    return d.day === new Date().toDateString() ? (d.ms || 0) / 60000 : 0;
  } catch {
    return 0;
  }
}

export function DataSettings(): React.ReactElement {
  useStore();
  const s = S.me.set || {};
  return (
    <div className="screen">
      <Header title={t('Экономия трафика')} />
      <div className="scroll">
        <div className="set-group">
          <Toggle id="ds-saver" label={t('Экономия трафика')} sub={t('Предзагружать только следующее видео вместо трёх')} on={!!s.saver} onChange={(v) => void act(() => saveSettings({ saver: v }))} />
          <Toggle id="ds-auto" label={t('Автопрокрутка')} sub={t('Переходить к следующему видео после просмотра')} on={!!s.auto} onChange={(v) => void act(() => saveSettings({ auto: v }))} />
        </div>
        <p className="muted pad">{t('Большие видео (больше 20 МБ) сжимаются до 720p прямо на устройстве перед загрузкой.')}</p>
      </div>
    </div>
  );
}

export function DisplaySettings(): React.ReactElement {
  useStore();
  const s = S.me.set || {};
  const setLang = (l: Lang): void => {
    lsSet('lang', l);
    if (S.uid && !S.readOnly) void act(() => saveSettings({ lang: l }));
    else toast(t('Сохранено'));
  };
  return (
    <div className="screen">
      <Header title={t('Язык и оформление')} />
      <div className="scroll">
        <div className="set-group">
          <small className="set-label">{t('Язык')}</small>
          {(['ru', 'en', 'uz'] as Lang[]).map((l) => (
            <label key={l} className="row" htmlFor={'lang-' + l}>
              <span className="grow">{l === 'ru' ? 'Русский' : l === 'en' ? 'English' : 'Oʻzbekcha'}</span>
              <input id={'lang-' + l} type="radio" name="lang" checked={(s.lang || 'ru') === l} onChange={() => setLang(l)} />
            </label>
          ))}
        </div>
        <div className="set-group">
          <small className="set-label">{t('Тема')}</small>
          {(['system', 'dark', 'light'] as const).map((th) => (
            <label key={th} className="row" htmlFor={'th-' + th}>
              <span className="grow">{th === 'dark' ? t('Тёмная') : th === 'light' ? t('Светлая') : t('Как в системе')}</span>
              <input id={'th-' + th} type="radio" name="theme" checked={(s.theme || 'system') === th} onChange={() => (lsSet('theme', th), void act(() => saveSettings({ theme: th })))} />
            </label>
          ))}
        </div>
      </div>
    </div>
  );
}

export function AboutScreen(): React.ReactElement {
  return (
    <div className="screen">
      <Header title={t('Как это работает')} />
      <div className="scroll pad col gap about">
        <p>{t('{app} работает на базе данных этого артефакта: публикации, лайки, комментарии и подписки видят все участники в реальном времени.', { app: cfg.name })}</p>
        <p>{t('Личные сообщения шифруются на устройствах участников (ECDH + AES-GCM). Сервер хранит только зашифрованный текст.')}</p>
        <p>{t('Публиковать могут участники с правом записи. Владелец приложения видит жалобы и модерирует контент.')}</p>
        <p>{t('Видео до 20 МБ загружаются как есть, большие сжимаются на устройстве. Звук, фильтры, текст и стикеры накладываются при воспроизведении.')}</p>
        <p className="muted">{t('В веб-версии нет прямых эфиров, push-уведомлений и встроенной камеры: съёмка открывает камеру телефона через выбор файла.')}</p>
      </div>
    </div>
  );
}

