// Minimal stand-in for the claude.ai runtime (db, user, assets, room, downloads) for local testing.
(function () {
  const params = new URLSearchParams(location.search);
  const UID = params.get('uid') || 'u_alice';
  const OWNER = params.get('owner') === '1';
  const KEY = 'mockdb';
  const load = () => { try { return JSON.parse(localStorage.getItem(KEY) || '{}'); } catch { return {}; } };
  const save = (d) => localStorage.setItem(KEY, JSON.stringify(d));
  const listeners = new Set();
  const notify = () => setTimeout(() => listeners.forEach((l) => l()), 0);
  window.addEventListener('storage', (e) => { if (e.key === KEY) notify(); });
  const clone = (x) => (x === undefined ? undefined : JSON.parse(JSON.stringify(x)));
  const merge = (a, b) => { const o = { ...(a || {}) }; for (const k in b) { const v = b[k]; o[k] = v && typeof v === 'object' && !Array.isArray(v) && o[k] && typeof o[k] === 'object' && !Array.isArray(o[k]) ? merge(o[k], v) : v; } return o; };
  const canWrite = (path) => { const seg = path.split('/'); if (seg[0] === 'data') return seg[2] === UID; if (['u','g','p','c','v','s','cv','ms','rep'].includes(seg[0])) return seg[1] === UID || OWNER; if (seg[0] === 'mod') return OWNER; return true; };
  const snap = (path, data) => ({ id: path.split('/').pop(), exists: data !== undefined, data: () => clone(data), metadata: { fromCache: false, hasPendingWrites: false } });
  const deny = () => Promise.reject({ code: 'invalid_argument', message: 'denied' });
  const docRef = (path) => ({
    id: path.split('/').pop(), path,
    get: async () => snap(path, load()[path]),
    set: async (data) => { if (!canWrite(path)) return deny(); const d = load(); d[path] = clone(data); save(d); notify(); },
    update: async (data) => { if (!canWrite(path)) return deny(); const d = load(); if (!d[path]) return Promise.reject({ code: 'invalid_argument', message: 'missing' }); d[path] = merge(d[path], clone(data)); save(d); notify(); },
    delete: async () => { if (!canWrite(path)) return deny(); const d = load(); delete d[path]; save(d); notify(); },
    acquire: async () => ({ acquired: true, version: 1 }),
    onSnapshot: (next) => { let last = "\u0000"; const l = () => { const v = JSON.stringify(load()[path]) ?? "null"; if (v !== last) { last = v; next(snap(path, load()[path])); } }; listeners.add(l); setTimeout(l, 5); return () => listeners.delete(l); },
    collection: (sub) => collRef(path + '/' + sub),
  });
  const collRef = (path) => ({
    path,
    doc: (id) => docRef(path + '/' + (id || Math.random().toString(36).slice(2))),
    onSnapshot: (next) => { let last; const l = () => { const d = load(); const n = path.split('/').length + 1; const docs = Object.keys(d).filter((k) => k.startsWith(path + '/') && k.split('/').length === n).sort(); const v = JSON.stringify(docs.map((k) => [k, d[k]])); if (v !== last) { last = v; const ds = docs.map((k) => snap(k, d[k])); next({ docs: ds, size: ds.length, empty: !ds.length, docChanges: () => [], metadata: { fromCache: false, hasPendingWrites: false } }); } }; listeners.add(l); setTimeout(l, 5); return () => listeners.delete(l); },
    get: async () => { const d = load(); const n = path.split('/').length + 1; const ds = Object.keys(d).filter((k) => k.startsWith(path + '/') && k.split('/').length === n).map((k) => snap(k, d[k])); return { docs: ds, size: ds.length, empty: !ds.length, docChanges: () => [] }; },
  });
  const db = Object.freeze({ doc: docRef, collection: collRef });
  const user = Object.freeze({ id: async () => UID, isOwner: async () => OWNER, canEdit: async () => OWNER, can: async () => null, me: async () => ({ id: UID, name: '', avatarUrl: '', color: '#888', email: null, isOwner: OWNER, canEdit: OWNER }), profiles: async (ids) => Object.fromEntries([].concat(ids).map((i) => [i, { id: i, name: '', avatarUrl: '', color: '#888', email: null, isMe: i === UID, guest: false }])), name: async () => '', avatarUrl: async () => null, search: async () => [], email: async () => null });
  const assets = Object.freeze({ upload: async (blob, o) => { const r = await fetch('/_upload', { method: 'POST', headers: { 'content-type': (o && o.type) || blob.type || 'application/octet-stream' }, body: blob }); const j = await r.json(); return { id: j.id, url: '/_blob/' + j.id, sizeBytes: blob.size, contentType: (o && o.type) || blob.type }; }, list: async () => ({ assets: [], usage: {} }), delete: async () => ({ deleted: true }) });
  let peersFn = null;
  const room = Object.freeze({ onPeers: (fn) => { peersFn = fn; setTimeout(() => fn({ peers: [{ peer: 'p1', by: UID, isMe: true, sameTab: true, kind: 'viewer', guest: false, presence: {}, updatedAt: Date.now() }], joined: [], left: [], updated: [] }), 10); return () => {}; }, presence: async () => {}, emit: async () => {}, on: () => () => {}, peers: () => [], connected: () => true });
  const downloads = Object.freeze({ save: async ({ filename }) => { window.__saved = (window.__saved || []).concat(filename); return { status: 'saved' }; } });
  const caps = { db, user, assets, room, downloads };
  window.claude = { use: (n) => Promise.resolve(caps[n] || null) };
})();
