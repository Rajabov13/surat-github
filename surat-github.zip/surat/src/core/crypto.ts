// End-to-end encryption for direct messages (WebCrypto).
// Each user has an ECDH P-256 key pair: the public half lives in their public profile,
// the private half in their private db subtree. A conversation has a random AES-GCM key,
// wrapped for every member with the ECDH key shared between the creator and that member.
import { b64, unb64 } from './util';
import type { Enc } from './types';

const ECDH = { name: 'ECDH', namedCurve: 'P-256' } as const;
const te = new TextEncoder();
const td = new TextDecoder();

/** Bytes backed by a plain ArrayBuffer, as WebCrypto expects. */
type Bytes = Uint8Array<ArrayBuffer>;

export async function genKeyPair(): Promise<{ pub: JsonWebKey; priv: JsonWebKey }> {
  const kp = await crypto.subtle.generateKey(ECDH, true, ['deriveKey']);
  const pub = await crypto.subtle.exportKey('jwk', kp.publicKey);
  const priv = await crypto.subtle.exportKey('jwk', kp.privateKey);
  return { pub, priv };
}

const privCache = new Map<string, CryptoKey>();
async function importPriv(jwk: JsonWebKey): Promise<CryptoKey> {
  const k = JSON.stringify(jwk);
  let key = privCache.get(k);
  if (!key) {
    key = await crypto.subtle.importKey('jwk', jwk, ECDH, false, ['deriveKey']);
    privCache.set(k, key);
  }
  return key;
}
async function importPub(jwk: JsonWebKey): Promise<CryptoKey> {
  return crypto.subtle.importKey('jwk', { ...jwk, key_ops: [] }, ECDH, false, []);
}

const pairCache = new Map<string, CryptoKey>();
export async function pairKey(myPriv: JsonWebKey, theirPub: JsonWebKey): Promise<CryptoKey> {
  const id = JSON.stringify(myPriv.d) + '|' + theirPub.x + theirPub.y;
  let k = pairCache.get(id);
  if (!k) {
    k = await crypto.subtle.deriveKey(
      { name: 'ECDH', public: await importPub(theirPub) },
      await importPriv(myPriv),
      { name: 'AES-GCM', length: 256 },
      false,
      ['encrypt', 'decrypt'],
    );
    pairCache.set(id, k);
  }
  return k;
}

export async function encryptBytes(key: CryptoKey, data: Bytes): Promise<Enc> {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, data);
  return { i: b64(iv), d: b64(ct) };
}
export async function decryptBytes(key: CryptoKey, e: Enc): Promise<Bytes> {
  const pt = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: unb64(e.i) }, key, unb64(e.d));
  return new Uint8Array(pt);
}
export async function encryptJson(key: CryptoKey, v: unknown): Promise<Enc> {
  return encryptBytes(key, te.encode(JSON.stringify(v)));
}
export async function decryptJson<T>(key: CryptoKey, e: Enc): Promise<T> {
  return JSON.parse(td.decode(await decryptBytes(key, e))) as T;
}

export async function newConvKey(): Promise<{ key: CryptoKey; raw: Bytes }> {
  const raw = crypto.getRandomValues(new Uint8Array(32));
  const key = await crypto.subtle.importKey('raw', raw, 'AES-GCM', false, ['encrypt', 'decrypt']);
  return { key, raw };
}
export async function importConvKey(raw: Bytes): Promise<CryptoKey> {
  return crypto.subtle.importKey('raw', raw, 'AES-GCM', false, ['encrypt', 'decrypt']);
}
