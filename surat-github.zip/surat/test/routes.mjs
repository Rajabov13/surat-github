// Serves the CDN scripts from node_modules and stubs Google Fonts, so tests run offline.
import { readFileSync } from 'node:fs';

const nm = new URL('../node_modules/', import.meta.url);
const files = {
  'react.production.min.js': 'react/umd/react.production.min.js',
  'react-dom.production.min.js': 'react-dom/umd/react-dom.production.min.js',
  'qrcode.min.js': 'qrcodejs/qrcode.min.js',
};

export async function offline(ctx) {
  await ctx.route(/cdnjs\.cloudflare\.com|fonts\.(googleapis|gstatic)\.com/, (route) => {
    const u = route.request().url();
    const f = Object.keys(files).find((k) => u.endsWith(k));
    if (f) return route.fulfill({ body: readFileSync(new URL(files[f], nm)), contentType: 'application/javascript' });
    return route.fulfill({ body: '', contentType: 'text/css' });
  });
}
