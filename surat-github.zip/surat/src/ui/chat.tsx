import React, { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { block } from '../core/actions';
import { agg, getPost, searchUsers } from '../core/derive';
import { convTitle, createGroup, deleteForAll, hideConv, hideForMe, lastPreview, markRead, messages, myConvs, openDirect, react, readBy, renameGroup, send, type ConvX, type MsgX } from '../core/dm';
import { prepareImage, upload, MAX_ASSET } from '../core/media';
import { S, setTyping, useStore, watchConv } from '../core/store';
import type { MsgBody } from '../core/types';
import { blob, cx } from '../core/util';
import { t, timeAgo } from './i18n';
import { Icon } from './icons';
import { act, Avatar, Empty, errToast, FilePick, Header, MenuItem, RichText, Spinner } from './kit';
import { back, closeSheet, confirmDialog, go, popScreen, sheet } from './nav';
import { Thumb } from './player';
import { copyText, ReportSheet } from './share';

const REACTIONS = ['❤️', '😂', '😮', '😢', '👍', '🔥'];

function previewText(c: ConvX): string {
  const p = lastPreview(c);
  if (!c.lastEnc) return t('Начните переписку');
  if (p === 'deleted') return t('Сообщение удалено');
  if (!p) return '🔒 ' + t('Зашифрованное сообщение');
  const mine = c.lastBy === S.uid ? t('Вы: ') : c.g && c.lastBy ? (S.u[c.lastBy]?.nm || '') + ': ' : '';
  const body = p.k === 'text' ? p.t || '' : p.k === 'img' ? '📷 ' + t('Фото') : p.k === 'video' ? '🎬 ' + t('Видео') : p.k === 'audio' ? '🎤 ' + t('Аудио') : p.k === 'post' ? '▶ ' + t('Публикация') : p.k === 'story' ? t('Ответ на историю') + (p.t ? ': ' + p.t : '') : '@' + t('Профиль');
  return mine + body;
}

export function ConvAvatar({ c, size = 52 }: { c: ConvX; size?: number }): React.ReactElement {
  const others = c.m.filter((m) => m !== S.uid);
  if (c.g) {
    return (
      <span className="conv-av" style={{ width: size, height: size }}>
        <Avatar uid={others[0]} size={size * 0.7} />
        <Avatar uid={others[1]} size={size * 0.7} />
      </span>
    );
  }
  const online = !!S.online[others[0]] && !S.u[others[0]]?.actOff;
  return (
    <span className="conv-av1">
      <Avatar uid={others[0]} size={size} ring />
      {online && <span className="online-dot" />}
    </span>
  );
}

export function ChatList({ requests }: { requests?: boolean }): React.ReactElement {
  useStore();
  const [q, setQ] = useState('');
  const all = myConvs();
  const reqs = all.filter((c) => c.request);
  let list = all.filter((c) => (requests ? c.request : !c.request));
  if (q) list = list.filter((c) => convTitle(c).toLowerCase().includes(q.toLowerCase()));
  list = [...list.filter((c) => c.unread), ...list.filter((c) => !c.unread)];
  if (!S.uid) return <Empty icon="messenger" title={t('Войдите, чтобы переписываться')} />;
  return (
    <div className="chat-list">
      <div className="pad-x">
        <input id="chat-q" className="input" placeholder={t('Поиск в сообщениях')} value={q} onChange={(e) => setQ(e.target.value)} />
      </div>
      {!requests && reqs.length > 0 && (
        <button className="row inbox-entry" onClick={() => go('chatrequests')}>
          <span className="entry-ic ic-muted">
            <Icon n="inbox" size={22} />
          </span>
          <span className="grow left">
            <b>{t('Запросы на переписку')}</b>
            <small className="muted block">{t('От тех, на кого вы не подписаны')}</small>
          </span>
          <span className="count">{reqs.length}</span>
        </button>
      )}
      {list.length === 0 && <Empty icon="messenger" title={requests ? t('Запросов нет') : t('Сообщений пока нет')} text={requests ? undefined : t('Напишите другу — переписка зашифрована')} />}
      {list.map((c) => {
        const typing = c.m.some((m) => m !== S.uid && S.online[m]?.typing === c.id);
        return (
          <button key={c.id} className={cx('row conv-row', c.unread && 'unread')} onClick={() => go('chat', { cid: c.id })}>
            <ConvAvatar c={c} />
            <span className="grow left min0">
              <b className="ell block">{convTitle(c)}</b>
              <small className={cx('ell block', c.unread ? 'strong' : 'muted')}>{typing ? t('печатает…') : previewText(c)}</small>
            </span>
            <span className="col right gap-s">
              <small className="muted">{timeAgo(c.lastTs)}</small>
              {c.unread && <span className="dot-unread" />}
            </span>
          </button>
        );
      })}
    </div>
  );
}

export function ChatRequestsScreen(): React.ReactElement {
  return (
    <div className="screen">
      <Header title={t('Запросы на переписку')} />
      <div className="scroll">
        <ChatList requests />
      </div>
    </div>
  );
}

export function NewChatScreen(): React.ReactElement {
  useStore();
  const [q, setQ] = useState('');
  const [sel, setSel] = useState<string[]>([]);
  const [name, setName] = useState('');
  const [busy, setBusy] = useState(false);
  const A = agg();
  const me = S.uid || '';
  const base = q ? searchUsers(q, 30) : [...new Set([...(A.following.get(me) || []), ...(A.followers.get(me) || [])])];
  const list = base.filter((u) => u !== me);
  const start = async (): Promise<void> => {
    setBusy(true);
    try {
      const cid = sel.length === 1 ? await openDirect(sel[0]) : await createGroup(sel, name || sel.map((u) => S.u[u]?.nm).join(', ').slice(0, 40));
      popScreen();
      go('chat', { cid });
    } catch (e) {
      errToast(e);
    } finally {
      setBusy(false);
    }
  };
  return (
    <div className="screen">
      <Header title={t('Новое сообщение')} right={<button className="btn btn-primary btn-sm" disabled={!sel.length || busy} onClick={() => void start()}>{sel.length > 1 ? t('Создать группу') : t('Чат')}</button>} />
      <div className="pad-x col gap-s">
        <input id="nc-q" className="input" placeholder={t('Кому: поиск')} value={q} onChange={(e) => setQ(e.target.value)} />
        {sel.length > 1 && <input id="nc-name" className="input" placeholder={t('Название группы')} maxLength={40} value={name} onChange={(e) => setName(e.target.value)} />}
        {sel.length > 0 && (
          <div className="chips">
            {sel.map((u) => (
              <button key={u} className="chip on" onClick={() => setSel(sel.filter((x) => x !== u))}>
                {S.u[u]?.nm} ×
              </button>
            ))}
          </div>
        )}
        <small className="muted">{t('Выберите одного человека для личного чата или до 31 для группы')}</small>
      </div>
      <div className="scroll">
        {list.length === 0 && <Empty icon="users" title={t('Никого не нашли')} />}
        {list.map((u) => (
          <label key={u} className="row user-row" htmlFor={'nc-' + u}>
            <Avatar uid={u} size={44} />
            <span className="grow min0">
              <span className="row-title ell">{S.u[u]?.nm}</span>
              <span className="row-sub">@{S.u[u]?.un}</span>
            </span>
            <input id={'nc-' + u} type="checkbox" checked={sel.includes(u)} onChange={(e) => setSel(e.target.checked ? [...sel, u].slice(0, 31) : sel.filter((x) => x !== u))} />
          </label>
        ))}
      </div>
    </div>
  );
}

function MsgBodyView({ b, mine }: { b: MsgBody; mine: boolean }): React.ReactElement {
  if (b.k === 'img' && b.a) return <img className="msg-img" src={blob(b.a)} alt="" loading="lazy" />;
  if (b.k === 'video' && b.a) return <video className="msg-img" src={blob(b.a)} controls playsInline preload="metadata" />;
  if (b.k === 'audio' && b.a) return <audio className="msg-audio" src={blob(b.a)} controls preload="metadata" />;
  if (b.k === 'post' && b.p) {
    const p = getPost(b.p);
    if (!p) return <span className="muted">{t('Публикация недоступна')}</span>;
    return (
      <div className="msg-post tap" onClick={() => go('post', { postKey: b.p })}>
        <Thumb post={p} />
        <div className="msg-post-meta">
          <Avatar uid={p.by} size={20} /> <b>@{S.u[p.by]?.un}</b>
          <span className="ell">{p.cap.slice(0, 60)}</span>
        </div>
      </div>
    );
  }
  if (b.k === 'profile' && b.u) {
    return (
      <div className="msg-post tap row" onClick={() => go('profile', { uid: b.u })}>
        <Avatar uid={b.u} size={36} />
        <b>@{S.u[b.u]?.un}</b>
      </div>
    );
  }
  if (b.k === 'story') {
    return (
      <div>
        <small className={mine ? 'on-accent-muted' : 'muted'}>{t('Ответ на историю')}</small>
        {b.t && <div>{b.t}</div>}
      </div>
    );
  }
  return <RichText text={b.t || ''} />;
}

export function ChatScreen({ cid }: { cid: string }): React.ReactElement {
  useStore();
  const conv = myConvs().find((c) => c.id === cid);
  const [text, setText] = useState('');
  const [reply, setReply] = useState<MsgX | null>(null);
  const [busy, setBusy] = useState(false);
  const list = useRef<HTMLDivElement | null>(null);
  const typingTimer = useRef(0);
  const members = conv?.m.join(',') || '';
  useEffect(() => {
    if (!conv) return;
    return watchConv(cid, conv.m);
  }, [cid, members]);
  const msgs = conv ? messages(conv) : [];
  const lastTs = msgs[msgs.length - 1]?.ts || 0;
  useEffect(() => {
    if (conv && conv.unread) void markRead(cid);
  }, [lastTs, conv?.unread]);
  useLayoutEffect(() => {
    const el = list.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [msgs.length]);
  useEffect(() => () => setTyping(null), []);

  if (!conv) return <div className="screen"><Header title={t('Чат')} /><Empty icon="messenger" title={t('Чат не найден')} /></div>;
  const me = S.uid!;
  const others = conv.m.filter((m) => m !== me);
  const typingNow = others.filter((m) => S.online[m]?.typing === cid);
  const online = !conv.g && !!S.online[others[0]] && !S.u[others[0]]?.actOff;
  const byKey = new Map(msgs.map((m) => [m.key, m]));

  const doSend = async (body: MsgBody): Promise<void> => {
    setBusy(true);
    try {
      if (reply) body.r = reply.key;
      await send(cid, body);
      setText('');
      setReply(null);
      setTyping(null);
    } catch (e) {
      errToast(e);
    } finally {
      setBusy(false);
    }
  };
  const onFiles = async (files: File[], kind: 'media' | 'audio'): Promise<void> => {
    for (const f of files) {
      try {
        setBusy(true);
        if (f.size > MAX_ASSET && !f.type.startsWith('image/')) throw { code: 'too_large' };
        if (kind === 'audio') await doSend({ k: 'audio', a: (await upload(f)).id });
        else if (f.type.startsWith('image/')) await doSend({ k: 'img', a: (await upload(f.type === 'image/gif' ? f : (await prepareImage(f, 1600)).blob)).id });
        else if (f.type.startsWith('video/')) await doSend({ k: 'video', a: (await upload(f)).id });
      } catch (e) {
        errToast(e);
      } finally {
        setBusy(false);
      }
    }
  };
  const onType = (v: string): void => {
    setText(v);
    setTyping(v ? cid : null);
    clearTimeout(typingTimer.current);
    typingTimer.current = window.setTimeout(() => setTyping(null), 3500);
  };
  const msgMenu = (m: MsgX): void => {
    const mine = m.by === me;
    sheet(() => (
      <div>
        <div className="reactions-row">
          {REACTIONS.map((e) => (
            <button key={e} onClick={() => (void act(() => react(cid, m.key, m.reactions[me] === e ? '' : e)), closeSheet())}>
              {e}
            </button>
          ))}
        </div>
        <MenuItem icon="back" label={t('Ответить')} onClick={() => (setReply(m), closeSheet())} />
        {m.body?.t && <MenuItem icon="copy" label={t('Копировать')} onClick={() => (void copyText(m.body!.t!), closeSheet())} />}
        <MenuItem icon="eyeoff" label={t('Удалить у себя')} onClick={() => (void act(() => hideForMe(m.key)), closeSheet())} />
        {mine && !m.deleted && (
          <MenuItem
            icon="trash"
            danger
            label={t('Удалить у всех')}
            onClick={async () => {
              closeSheet();
              if (await confirmDialog(t('Удалить сообщение у всех?'), t('Удалить'))) void act(() => deleteForAll(cid, m.id));
            }}
          />
        )}
        {!mine && <MenuItem icon="flag" label={t('Пожаловаться')} onClick={() => sheet(() => <ReportSheet k="msg" id={cid + '/' + m.key} />)} />}
      </div>
    ));
  };
  const chatMenu = (): void =>
    sheet(() => (
      <div>
        {!conv.g && <MenuItem icon="user" label={t('Профиль')} onClick={() => (closeSheet(), go('profile', { uid: others[0] }))} />}
        {conv.g && conv.by === me && <MenuItem icon="edit" label={t('Переименовать группу')} onClick={() => sheet(() => <RenameGroup cid={cid} cur={conv.n || ''} />)} />}
        {conv.g && (
          <div className="pad-x">
            <b>{t('Участники')}: {conv.m.length}</b>
            {conv.m.map((u) => (
              <div key={u} className="row tap" onClick={() => (closeSheet(), go('profile', { uid: u }))}>
                <Avatar uid={u} size={32} /> <span>{S.u[u]?.nm}</span>
              </div>
            ))}
          </div>
        )}
        <MenuItem icon="eyeoff" label={t('Скрыть чат')} onClick={() => (closeSheet(), void act(() => hideConv(cid)).then(() => back()))} />
        {!conv.g && <MenuItem icon="shield" danger label={t('Заблокировать')} onClick={async () => (closeSheet(), (await confirmDialog(t('Заблокировать?'), t('Заблокировать'))) && void act(() => block(others[0], true)).then(() => back()))} />}
      </div>
    ));

  const myLast = [...msgs].reverse().find((m) => m.by === me && !m.deleted);
  return (
    <div className="screen chat">
      <header className="hdr">
        <button className="icon-btn" onClick={back} aria-label={t('Назад')}>
          <Icon n="back" />
        </button>
        <button className="hdr-title row gap-s tap left" onClick={chatMenu}>
          <ConvAvatar c={conv} size={34} />
          <span className="col min0">
            <b className="ell">{convTitle(conv)}</b>
            <small className="muted">{typingNow.length ? t('печатает…') : conv.g ? t('{n} участников', { n: conv.m.length }) : online ? t('в сети') : '@' + (S.u[others[0]]?.un || '')}</small>
          </span>
        </button>
        <div className="hdr-right">
          <button className="icon-btn" onClick={chatMenu} aria-label={t('Меню')}>
            <Icon n="more" />
          </button>
        </div>
      </header>
      {conv.request && (
        <div className="req-note">
          <span>{t('Этот человек не в ваших подписках. Ответьте, чтобы принять запрос.')}</span>
          <div className="row gap-s">
            <button className="btn btn-muted btn-sm" onClick={() => void act(() => hideConv(cid)).then(() => back())}>
              {t('Удалить')}
            </button>
            <button className="btn btn-danger btn-sm" onClick={() => void act(() => block(conv.by, true)).then(() => back())}>
              {t('Заблокировать')}
            </button>
          </div>
        </div>
      )}
      <div className="msgs" ref={list}>
        <div className="e2e-note">
          <Icon n="lock" size={14} /> {t('Сообщения зашифрованы на устройствах участников')}
        </div>
        {msgs.map((m, i) => {
          const mine = m.by === me;
          const prev = msgs[i - 1];
          const showName = conv.g && !mine && prev?.by !== m.by;
          const showTime = !prev || m.ts - prev.ts > 15 * 60000;
          const rep = m.body?.r ? byKey.get(m.body.r) : undefined;
          const rx = Object.entries(m.reactions);
          return (
            <React.Fragment key={m.key}>
              {showTime && <div className="msg-time">{new Date(m.ts).toLocaleString([], { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}</div>}
              <div className={cx('msg-row', mine && 'mine')}>
                {!mine && <Avatar uid={m.by} size={28} onClick={() => go('profile', { uid: m.by })} />}
                <div className="msg-col">
                  {showName && <small className="msg-name">{S.u[m.by]?.nm}</small>}
                  <div className={cx('bubble', mine && 'mine', m.deleted && 'deleted', (m.body?.k === 'img' || m.body?.k === 'video' || m.body?.k === 'post') && 'media')} onClick={() => msgMenu(m)} onContextMenu={(e) => (e.preventDefault(), msgMenu(m))}>
                    {rep && (
                      <div className="msg-quote">
                        <b>{S.u[rep.by]?.nm}</b> <span className="ell">{rep.body?.t || (rep.body ? t('Вложение') : '…')}</span>
                      </div>
                    )}
                    {m.deleted ? <i>{t('Сообщение удалено')}</i> : m.body ? <MsgBodyView b={m.body} mine={mine} /> : <span className="muted"><Spinner size={12} /> {t('Расшифровка…')}</span>}
                  </div>
                  {rx.length > 0 && (
                    <div className={cx('msg-rx', mine && 'mine')}>
                      {rx.map(([u, e]) => (
                        <span key={u} title={S.u[u]?.nm}>{e}</span>
                      ))}
                    </div>
                  )}
                  {m === myLast && (
                    <small className="msg-status">
                      {readBy(conv, m.ts).length ? (
                        <>
                          <Icon n="checks" size={14} /> {conv.g ? t('Прочитали: {n}', { n: readBy(conv, m.ts).length }) : t('Прочитано')}
                        </>
                      ) : (
                        <>
                          <Icon n="check" size={14} /> {t('Отправлено')}
                        </>
                      )}
                    </small>
                  )}
                </div>
              </div>
            </React.Fragment>
          );
        })}
        {typingNow.length > 0 && (
          <div className="msg-row">
            <Avatar uid={typingNow[0]} size={28} />
            <div className="bubble typing">
              <span />
              <span />
              <span />
            </div>
          </div>
        )}
      </div>
      {S.readOnly ? (
        <div className="comment-closed">{t('Только просмотр')}</div>
      ) : (
        <div className="chat-bar">
          {reply && (
            <div className="reply-chip">
              {t('Ответ')}: {reply.body?.t?.slice(0, 50) || t('Вложение')}
              <button className="icon-btn" onClick={() => setReply(null)}>
                <Icon n="close" size={14} />
              </button>
            </div>
          )}
          <div className="chat-input">
            {S.canUpload && (
              <FilePick id="chat-media" accept="image/*,video/*" multiple onFiles={(f) => void onFiles(f, 'media')} className="icon-btn">
                <Icon n="image" size={22} />
              </FilePick>
            )}
            {S.canUpload && (
              <FilePick id="chat-audio" accept="audio/*" capture="user" onFiles={(f) => void onFiles(f, 'audio')} className="icon-btn">
                <Icon n="mic" size={22} />
              </FilePick>
            )}
            <input id="chat-text" className="input grow" placeholder={t('Сообщение…')} value={text} maxLength={2000} onChange={(e) => onType(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && text.trim() && void doSend({ k: 'text', t: text.trim() })} />
            {text.trim() ? (
              <button className="icon-btn accent" disabled={busy} onClick={() => void doSend({ k: 'text', t: text.trim() })} aria-label={t('Отправить')}>
                {busy ? <Spinner size={18} /> : <Icon n="send" size={22} />}
              </button>
            ) : (
              <button className="icon-btn" onClick={() => void doSend({ k: 'text', t: '❤️' })} aria-label="❤️">
                <Icon n="heart" size={22} />
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

function RenameGroup({ cid, cur }: { cid: string; cur: string }): React.ReactElement {
  const [n, setN] = useState(cur);
  return (
    <div className="pad col gap">
      <b>{t('Название группы')}</b>
      <input id="rg-name" className="input" maxLength={40} value={n} onChange={(e) => setN(e.target.value)} />
      <button className="btn btn-primary" disabled={!n.trim()} onClick={() => void act(() => renameGroup(cid, n.trim()), t('Сохранено')).then(closeSheet)}>
        {t('Сохранить')}
      </button>
    </div>
  );
}

