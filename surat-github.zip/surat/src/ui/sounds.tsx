import React, { useEffect, useState } from 'react';
import { addTrack, favSound } from '../core/actions';
import { agg, canSee, getPost, searchSounds, soundName, type SoundX } from '../core/derive';
import { upload } from '../core/media';
import { S, useStore } from '../core/store';
import type { SoundRef } from '../core/types';
import { cx, fmtCount, fmtDur, has, rid, splitKey } from '../core/util';
import { t } from './i18n';
import { Icon } from './icons';
import { act, Avatar, Empty, errToast, FilePick, Header, Tabs } from './kit';
import { closeSheet, go, sheet, toast } from './nav';
import { msrc, Thumb } from './player';

export const GENRES = ['Поп', 'Хип-хоп', 'Электроника', 'Рок', 'Инди', 'Джаз', 'Классика', 'Фолк', 'Лоу-фай', 'Звуки', 'Юмор'];

let previewEl: HTMLAudioElement | null = null;
let previewKey = '';
export function previewSound(s: SoundX, onEnd?: () => void): boolean {
  if (previewEl) {
    previewEl.pause();
    previewEl = null;
  }
  if (previewKey === s.key) {
    previewKey = '';
    return false;
  }
  const a = new Audio(msrc(s.asset));
  a.currentTime = s.start;
  void a.play().catch(() => toast(t('Не удалось воспроизвести звук')));
  a.onended = () => onEnd?.();
  previewEl = a;
  previewKey = s.key;
  setTimeout(() => {
    if (previewEl === a) {
      a.pause();
      previewKey = '';
      onEnd?.();
    }
  }, 20000);
  return true;
}
export function stopPreview(): void {
  previewEl?.pause();
  previewEl = null;
  previewKey = '';
}

function SoundRow({ s, onUse, playing, onPlay }: { s: SoundX; onUse?: () => void; playing: boolean; onPlay: () => void }): React.ReactElement {
  useStore();
  const fav = has(S.me.fs, s.key);
  return (
    <div className="row sound-row">
      <button className="sound-cover" onClick={onPlay} aria-label={t('Прослушать')}>
        {s.cover ? <img src={msrc(s.cover)} alt="" /> : <Avatar uid={s.au} size={52} />}
        <span className="sound-play">
          <Icon n={playing ? 'pause' : 'play'} size={18} fill />
        </span>
      </button>
      <div className="grow min0 tap" onClick={() => (closeSheet(), go('sound', { key: s.key }))}>
        <div className="row-title ell">{soundName(s, t('Оригинальный звук'))}</div>
        <div className="row-sub ell">
          {s.track?.g ? t(s.track.g) + ' · ' : ''}
          {fmtDur(s.dur)} · {fmtCount(s.posts.length)} {t('видео')}
        </div>
      </div>
      {!S.readOnly && (
        <button className={cx('icon-btn', fav && 'accent')} onClick={() => void act(() => favSound(s.key, !fav))} aria-label={t('В избранное')}>
          <Icon n="bookmark" size={20} fill={fav} />
        </button>
      )}
      {onUse && (
        <button className="btn btn-primary btn-sm" onClick={onUse}>
          {t('Выбрать')}
        </button>
      )}
    </div>
  );
}

/** Pick a sound for a new post: trending, favourites, genres and search, with fragment trim. */
export function SoundPicker({ onPick, withTrim, current }: { onPick: (s: SoundRef) => void; withTrim?: boolean; current?: SoundRef }): React.ReactElement {
  useStore();
  const [tab, setTab] = useState<'top' | 'fav' | 'genre'>('top');
  const [q, setQ] = useState('');
  const [genre, setGenre] = useState<string | null>(null);
  const [playing, setPlaying] = useState('');
  const [trim, setTrim] = useState<{ s: SoundX; st: number } | null>(null);
  useEffect(() => () => stopPreview(), []);
  let list = searchSounds(q, t('Оригинальный звук'), 60);
  if (tab === 'fav') list = list.filter((s) => has(S.me.fs, s.key));
  if (tab === 'genre' && genre) list = list.filter((s) => s.track?.g === genre);
  const toRef = (s: SoundX, st = 0): SoundRef => ({ k: s.k, au: s.au, id: s.id, st, v: 1 });

  if (trim) {
    return (
      <div className="pad col gap">
        <b>{t('Выберите фрагмент')}</b>
        <div className="row-sub">{soundName(trim.s, t('Оригинальный звук'))}</div>
        <label className="range-label">
          {t('Начало')}: {fmtDur(trim.st)}
          <input id="snd-trim" type="range" min={0} max={Math.max(0, trim.s.dur - 1)} step={0.1} value={trim.st} onChange={(e) => setTrim({ ...trim, st: Number(e.target.value) })} />
        </label>
        <button
          className="btn btn-muted"
          onClick={() => {
            stopPreview();
            const a = new Audio(msrc(trim.s.asset));
            a.currentTime = trim.s.start + trim.st;
            void a.play().catch(() => undefined);
            setTimeout(() => a.pause(), 6000);
          }}
        >
          <Icon n="play" size={16} /> {t('Прослушать 6 сек')}
        </button>
        <button className="btn btn-primary" onClick={() => onPick(toRef(trim.s, trim.st))}>
          {t('Использовать')}
        </button>
      </div>
    );
  }

  return (
    <div className="sound-picker">
      <div className="pad-x col gap-s">
        <b className="sheet-title">{t('Звуки')}</b>
        <input id="snd-search" className="input" placeholder={t('Поиск звуков')} value={q} onChange={(e) => setQ(e.target.value)} />
        <Tabs value={tab} onChange={setTab} items={[['top', t('Рекомендуемые')], ['fav', t('Избранное')], ['genre', t('Жанры')]]} />
        {tab === 'genre' && (
          <div className="hscroll chips">
            {GENRES.map((g) => (
              <button key={g} className={cx('chip', genre === g && 'on')} onClick={() => setGenre(genre === g ? null : g)}>
                {t(g)}
              </button>
            ))}
          </div>
        )}
      </div>
      <div className="sound-list">
        {current && (
          <div className="pad-x muted">
            {t('Сейчас')}: {soundName(agg().sounds.get(`${current.k}:${current.au}~${current.id}`) || ({ track: undefined, au: current.au } as SoundX), t('Оригинальный звук'))}
          </div>
        )}
        {list.length === 0 && <Empty icon="music" title={t('Звуков пока нет')} text={t('Звук появляется из каждого опубликованного видео. Можно загрузить свой трек.')} />}
        {list.map((s) => (
          <SoundRow
            key={s.key}
            s={s}
            playing={playing === s.key}
            onPlay={() => setPlaying(previewSound(s, () => setPlaying('')) ? s.key : '')}
            onUse={() => (stopPreview(), withTrim && s.dur > 8 ? setTrim({ s, st: 0 }) : onPick(toRef(s)))}
          />
        ))}
      </div>
      {S.canUpload && !S.readOnly && (
        <div className="pad-x">
          <button className="btn btn-muted wide" onClick={() => sheet(() => <TrackUpload onDone={(ref) => onPick(ref)} />)}>
            <Icon n="plus" size={18} /> {t('Загрузить свой трек')}
          </button>
        </div>
      )}
    </div>
  );
}

function TrackUpload({ onDone }: { onDone: (r: SoundRef) => void }): React.ReactElement {
  const [file, setFile] = useState<File | null>(null);
  const [name, setName] = useState('');
  const [genre, setGenre] = useState(GENRES[0]);
  const [busy, setBusy] = useState(false);
  const go2 = async (): Promise<void> => {
    if (!file || !S.uid) return;
    setBusy(true);
    try {
      const url = URL.createObjectURL(file);
      const dur = await new Promise<number>((res) => {
        const a = new Audio();
        a.preload = 'metadata';
        a.onloadedmetadata = () => res(isFinite(a.duration) ? a.duration : 30);
        a.onerror = () => res(30);
        a.src = url;
      });
      URL.revokeObjectURL(url);
      const up = await upload(file);
      const id = rid(10);
      await addTrack({ id, n: name.trim() || file.name.replace(/\.[^.]+$/, ''), a: up.id, d: dur, g: genre, ts: Date.now() });
      toast(t('Трек добавлен в библиотеку'));
      closeSheet();
      onDone({ k: 's', au: S.uid, id, st: 0, v: 1 });
    } catch (e) {
      errToast(e);
    } finally {
      setBusy(false);
    }
  };
  return (
    <div className="pad col gap">
      <b>{t('Загрузить трек')}</b>
      <small className="muted">{t('Загружайте только музыку, на которую у вас есть права. Подходят файлы m4a, mp4, webm.')}</small>
      <FilePick id="track-file" accept="audio/*,video/mp4,video/webm" onFiles={([f]) => setFile(f)} className="btn btn-muted">
        <Icon n="music" size={18} /> {file ? file.name : t('Выбрать файл')}
      </FilePick>
      <input id="track-name" className="input" placeholder={t('Название')} maxLength={60} value={name} onChange={(e) => setName(e.target.value)} />
      <select id="track-genre" className="select" value={genre} onChange={(e) => setGenre(e.target.value)}>
        {GENRES.map((g) => (
          <option key={g} value={g}>
            {t(g)}
          </option>
        ))}
      </select>
      <button className="btn btn-primary" disabled={!file || busy} onClick={() => void go2()}>
        {busy ? t('Загрузка…') : t('Загрузить')}
      </button>
    </div>
  );
}

export function SoundScreen({ soundKey }: { soundKey: string }): React.ReactElement {
  useStore();
  const s = agg().sounds.get(soundKey);
  const [playing, setPlaying] = useState(false);
  const [tab, setTab] = useState<'top' | 'new'>('top');
  useEffect(() => () => stopPreview(), []);
  if (!s) return <div className="screen"><Header title={t('Звук')} /><Empty icon="music" title={t('Звук недоступен')} /></div>;
  const fav = has(S.me.fs, s.key);
  const keys = s.posts.filter((k) => {
    const p = getPost(k);
    return p && canSee(p);
  });
  const origin = s.k === 'p' ? `${s.au}~${s.id}` : null;
  const sorted = keys
    .map((k) => getPost(k)!)
    .sort((a, b) => (tab === 'top' ? b.views + b.likes * 5 - (a.views + a.likes * 5) : b.ts - a.ts))
    .map((p) => p.key);
  if (origin && !sorted.includes(origin) && getPost(origin)) sorted.unshift(origin);
  return (
    <div className="screen">
      <Header title={t('Звук')} />
      <div className="scroll">
        <div className="sound-head pad">
          <button className="sound-cover big" onClick={() => setPlaying(previewSound(s, () => setPlaying(false)))}>
            {s.cover ? <img src={msrc(s.cover)} alt="" /> : <Avatar uid={s.au} size={96} />}
            <span className="sound-play">
              <Icon n={playing ? 'pause' : 'play'} size={26} fill />
            </span>
          </button>
          <div className="col gap-s min0">
            <b className="sound-title">{soundName(s, t('Оригинальный звук'))}</b>
            <a className="muted" onClick={() => go('profile', { uid: s.au })}>
              @{S.u[s.au]?.un}
            </a>
            <small className="muted">
              {fmtCount(keys.length)} {t('видео')} · {fmtDur(s.dur)}
            </small>
            {!S.readOnly && (
              <button className={cx('btn btn-sm', fav ? 'btn-muted' : 'btn-outline')} onClick={() => void act(() => favSound(s.key, !fav))}>
                <Icon n="bookmark" size={16} fill={fav} /> {fav ? t('В избранном') : t('В избранное')}
              </button>
            )}
          </div>
        </div>
        <Tabs value={tab} onChange={setTab} items={[['top', t('Популярные')], ['new', t('Новые')]]} />
        <div className="grid3">
          {sorted.map((k) => {
            const p = getPost(k)!;
            return (
              <Thumb key={k} post={p} onClick={() => go('post', { postKey: k, list: sorted, src: 'sound' })}>
                {k === origin && <span className="thumb-badge accent-bg">{t('Оригинал')}</span>}
                <span className="thumb-views">
                  <Icon n="play" size={12} fill /> {fmtCount(p.views)}
                </span>
              </Thumb>
            );
          })}
        </div>
        {sorted.length === 0 && <Empty icon="video" title={t('Пока нет видео с этим звуком')} />}
      </div>
      {!S.readOnly && (
        <div className="float-cta">
          <button className="btn btn-primary btn-lg" onClick={() => go('create', { sound: s.key })}>
            <Icon n="video" size={20} /> {t('Использовать звук')}
          </button>
        </div>
      )}
    </div>
  );
}

export function parseSoundKey(key: string): { k: string; au: string; id: string } {
  const [au, id] = splitKey(key.slice(2));
  return { k: key.slice(0, 1), au, id };
}
