// Background publishing queue: uploads local media, then writes the post. The feed stays usable.
import { publishPost, saveDraft, publishStory } from '../core/actions';
import { captureFrame, imageWithText, MAX_ASSET, prepareImage, recorderSupported, textCover, transcode, upload } from '../core/media';
import { bump } from '../core/store';
import type { Post, Story } from '../core/types';
import { errMsg, rid } from '../core/util';
import { t } from './i18n';
import { toast } from './nav';
import { FONTS } from './player';

export interface LocalMedia {
  url: string; // object URL (or /_blob/ for already uploaded)
  file?: File;
  kind: 'video' | 'image';
  uploaded?: string; // asset id once uploaded
}

export interface Job {
  id: string;
  post: Post;
  media: Record<string, LocalMedia>; // keyed by the placeholder used inside the post
  cover?: { time: number; text?: string; clipRef?: string };
  progress: number;
  stage: string;
  status: 'running' | 'error' | 'done';
  error?: string;
  thumb?: string;
  mode: 'post' | 'draft' | 'story';
  story?: Story;
}

export const jobs: Job[] = [];

async function uploadOne(m: LocalMedia, job: Job): Promise<string> {
  if (m.uploaded) return m.uploaded;
  if (!m.file) throw new Error('missing file');
  let blob: Blob = m.file;
  if (m.kind === 'image') blob = (await prepareImage(m.file)).blob;
  else if (m.file.size > MAX_ASSET) {
    if (!recorderSupported()) throw { code: 'too_large' };
    job.stage = t('Сжимаем видео…');
    bump();
    blob = await transcode([{ src: m.url }], {
      maxSide: 720,
      bitrate: 1_400_000,
      onProgress: (f) => {
        job.stage = t('Сжимаем видео… {p}%', { p: Math.round(f * 100) });
        bump();
      },
    });
    if (blob.size > MAX_ASSET) throw { code: 'too_large' };
  }
  const r = await upload(blob);
  m.uploaded = r.id;
  return r.id;
}

function swap(post: Post, map: Record<string, string>): Post {
  const p: Post = JSON.parse(JSON.stringify(post));
  if (p.clips) p.clips = p.clips.map((c) => ({ ...c, a: map[c.a] || c.a }));
  if (p.ph) p.ph = p.ph.map((a) => map[a] || a);
  if (p.poster && map[p.poster]) p.poster = map[p.poster];
  return p;
}

export async function runJob(job: Job): Promise<void> {
  job.status = 'running';
  job.error = undefined;
  bump();
  try {
    const keys = Object.keys(job.media);
    const map: Record<string, string> = {};
    let i = 0;
    for (const k of keys) {
      job.stage = t('Загрузка {i} из {n}', { i: i + 1, n: keys.length });
      job.progress = (i / (keys.length + 1)) * 0.9;
      bump();
      map[k] = await uploadOne(job.media[k], job);
      i++;
    }
    let post = swap(job.post, map);
    job.stage = t('Обложка…');
    job.progress = 0.92;
    bump();
    if (job.mode !== 'story') {
      if (post.t === 'video' && post.clips?.length && !post.poster) {
        const c0 = job.post.clips![0];
        const at = job.cover ? job.cover.time : c0.s + 0.2;
        for (const src of [job.media[c0.a]?.url, '/_blob/' + post.clips[0].a]) {
          if (!src) continue;
          try {
            const b = await captureFrame(src, at, 720, job.cover?.text);
            post.poster = (await upload(b)).id;
            break;
          } catch {
            /* try the uploaded copy; a cover is optional */
          }
        }
      } else if (post.t === 'photo' && post.ph?.length && job.cover?.text && !post.poster) {
        try {
          post.poster = (await upload(await imageWithText('/_blob/' + post.ph[0], job.cover.text))).id;
        } catch {
          /* optional */
        }
      } else if (post.t === 'text' && !post.poster && post.txt) {
        try {
          post.poster = (await upload(await textCover(post.cap.replace(/#[\p{L}\p{N}_]+/gu, '').trim(), post.txt.bg, post.txt.c, FONTS[post.txt.f] || FONTS[0]))).id;
        } catch {
          /* optional */
        }
      }
    }
    job.stage = t('Публикуем…');
    job.progress = 0.97;
    bump();
    if (job.mode === 'draft') await saveDraft(post);
    else if (job.mode === 'story' && job.story) {
      const st: Story = { ...job.story, m: job.story.m ? map[job.story.m] || job.story.m : undefined };
      await publishStory(st);
    } else await publishPost(post);
    job.status = 'done';
    job.progress = 1;
    for (const m of Object.values(job.media)) if (m.url.startsWith('blob:')) URL.revokeObjectURL(m.url);
    bump();
    toast(job.mode === 'draft' ? t('Черновик сохранён') : job.mode === 'story' ? t('История опубликована') : post.at && post.at > Date.now() ? t('Публикация запланирована') : t('Опубликовано!'));
    setTimeout(() => {
      const k = jobs.indexOf(job);
      if (k >= 0) jobs.splice(k, 1);
      bump();
    }, 1500);
    post = post as Post;
  } catch (e) {
    job.status = 'error';
    const code = errMsg(e);
    job.error = code === 'too_large' ? t('Файл больше 20 МБ, а сжать его в этом браузере не получилось') : code === 'quota' ? t('Хранилище заполнено') : code === 'not_granted' ? t('Загрузка файлов недоступна для вашего уровня доступа') : t('Не удалось загрузить: {e}', { e: code });
    bump();
  }
}

export function startJob(j: Omit<Job, 'id' | 'progress' | 'stage' | 'status'>): Job {
  const job: Job = { ...j, id: rid(8), progress: 0, stage: '', status: 'running' };
  jobs.push(job);
  void runJob(job);
  return job;
}

export function dismissJob(job: Job): void {
  const k = jobs.indexOf(job);
  if (k >= 0) jobs.splice(k, 1);
  bump();
}
