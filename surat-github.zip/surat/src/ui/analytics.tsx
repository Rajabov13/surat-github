import React, { useState } from 'react';
import { agg, audience, getPost, overview, postStats } from '../core/derive';
import { S, useStore } from '../core/store';
import { fmtCount, fmtDur } from '../core/util';
import { lang, t } from './i18n';
import { Empty, Header, Tabs } from './kit';
import { go } from './nav';
import { Thumb } from './player';

export function Bars({ values, labels, h = 120 }: { values: number[]; labels?: string[]; h?: number }): React.ReactElement {
  const max = Math.max(1, ...values);
  const w = 100 / Math.max(1, values.length);
  return (
    <div className="chart">
      <svg viewBox={`0 0 100 ${h}`} preserveAspectRatio="none" className="chart-svg" style={{ height: h }}>
        {[0.25, 0.5, 0.75].map((g) => (
          <line key={g} x1="0" x2="100" y1={h - g * (h - 4)} y2={h - g * (h - 4)} className="chart-grid" />
        ))}
        {values.map((v, i) => {
          const bh = (v / max) * (h - 4);
          return <rect key={i} x={i * w + w * 0.15} y={h - bh} width={w * 0.7} height={Math.max(bh, v ? 1 : 0)} rx="0.6" className="chart-bar" />;
        })}
      </svg>
      {labels && (
        <div className="chart-labels">
          <small>{labels[0]}</small>
          <small>{labels[Math.floor(labels.length / 2)]}</small>
          <small>{labels[labels.length - 1]}</small>
        </div>
      )}
      <small className="chart-max">{fmtCount(max)}</small>
    </div>
  );
}

export function Line({ values, h = 120, pct }: { values: number[]; h?: number; pct?: boolean }): React.ReactElement {
  const max = pct ? 1 : Math.max(1, ...values);
  const n = Math.max(2, values.length);
  const pts = values.map((v, i) => `${(i / (n - 1)) * 100},${h - (v / max) * (h - 6) - 3}`).join(' ');
  return (
    <div className="chart">
      <svg viewBox={`0 0 100 ${h}`} preserveAspectRatio="none" className="chart-svg" style={{ height: h }}>
        {[0.25, 0.5, 0.75].map((g) => (
          <line key={g} x1="0" x2="100" y1={h - g * (h - 6) - 3} y2={h - g * (h - 6) - 3} className="chart-grid" />
        ))}
        <polyline points={`0,${h} ${pts} 100,${h}`} className="chart-area" />
        <polyline points={pts} className="chart-line" vectorEffect="non-scaling-stroke" />
      </svg>
      {pct && <small className="chart-max">100%</small>}
    </div>
  );
}

function HBars({ data, total, labelMap }: { data: Record<string, number>; total?: number; labelMap?: Record<string, string> }): React.ReactElement {
  const entries = Object.entries(data).sort((a, b) => b[1] - a[1]);
  const sum = total || entries.reduce((a, [, v]) => a + v, 0) || 1;
  if (!entries.length) return <p className="muted">{t('Пока нет данных')}</p>;
  return (
    <div className="hbars">
      {entries.map(([k, v]) => (
        <div key={k} className="hbar">
          <span className="hbar-label">{labelMap?.[k] ? t(labelMap[k]) : k}</span>
          <span className="hbar-track">
            <span style={{ width: `${(v / sum) * 100}%` }} />
          </span>
          <small>{Math.round((v / sum) * 100)}%</small>
        </div>
      ))}
    </div>
  );
}

export const SOURCES: Record<string, string> = { fy: 'Для вас', fol: 'Подписки', fr: 'Друзья', profile: 'Профиль', search: 'Поиск', sound: 'Звук', tag: 'Хэштег', explore: 'Обзор', share: 'Ссылка', post: 'Публикация', home: 'Главная', reels: 'Рилсы' };

export function AnalyticsScreen(): React.ReactElement {
  useStore();
  const me = S.uid!;
  const [days, setDays] = useState<'7' | '28' | '60'>('7');
  const [tab, setTab] = useState<'overview' | 'content' | 'audience'>('overview');
  const o = overview(me, Number(days));
  const labels = o.days.map((d) => new Date(d).toLocaleDateString(lang(), { day: 'numeric', month: 'short' }));
  const posts = [...agg().posts.values()].filter((p) => p.by === me).sort((a, b) => b.ts - a.ts);
  const aud = audience(me);
  const tiles: [string, number][] = [
    ['Просмотры видео', o.totals.views],
    ['Просмотры профиля', o.totals.profileViews],
    ['Лайки', o.totals.likes],
    ['Комментарии', o.totals.comments],
    ['Репосты', o.totals.reposts],
    ['Новые подписчики', o.totals.followers],
  ];
  return (
    <div className="screen">
      <Header title={t('Аналитика')} />
      <Tabs value={tab} onChange={setTab} items={[['overview', t('Обзор')], ['content', t('Контент')], ['audience', t('Аудитория')]]} />
      <div className="scroll pad col gap">
        {tab === 'overview' && (
          <>
            <div className="chips">
              {(['7', '28', '60'] as const).map((d) => (
                <button key={d} className={'chip' + (days === d ? ' on' : '')} onClick={() => setDays(d)}>
                  {t('{d} дней', { d })}
                </button>
              ))}
            </div>
            <div className="tiles">
              {tiles.map(([l, v]) => (
                <div key={l} className="tile">
                  <small>{t(l)}</small>
                  <b>{fmtCount(v)}</b>
                </div>
              ))}
            </div>
            <div className="card">
              <b>{t('Просмотры видео')}</b>
              <Bars values={o.views} labels={labels} />
            </div>
            <div className="card">
              <b>{t('Новые подписчики')}</b>
              <Bars values={o.followers} labels={labels} h={80} />
            </div>
            <div className="card">
              <b>{t('Лайки')}</b>
              <Bars values={o.likes} labels={labels} h={80} />
            </div>
          </>
        )}
        {tab === 'content' && (
          <>
            {posts.length === 0 && <Empty icon="chart" title={t('Опубликуйте видео, чтобы увидеть статистику')} />}
            {posts.map((p) => (
              <button key={p.key} className="row stat-row" onClick={() => go('poststats', { postKey: p.key })}>
                <div className="stat-thumb">
                  <Thumb post={p} />
                </div>
                <span className="grow left min0">
                  <span className="ell block">{p.cap || t('Без описания')}</span>
                  <small className="muted">
                    {fmtCount(p.views)} {t('просмотров')} · {fmtCount(p.likes)} {t('лайков')} · {new Date(p.ts).toLocaleDateString()}
                  </small>
                </span>
              </button>
            ))}
          </>
        )}
        {tab === 'audience' && (
          <>
            <div className="tiles">
              <div className="tile">
                <small>{t('Подписчики')}</small>
                <b>{fmtCount(aud.total)}</b>
              </div>
            </div>
            <div className="card">
              <b>{t('Когда подписчики активны')}</b>
              <Bars values={aud.hours} labels={['0:00', '12:00', '23:00']} h={90} />
            </div>
            <div className="card">
              <b>{t('Языки подписчиков')}</b>
              <HBars data={aud.langs} />
            </div>
            <small className="muted">{t('Пол, возраст и страна при регистрации не собираются, поэтому в аналитике их нет.')}</small>
          </>
        )}
      </div>
    </div>
  );
}

export function PostStatsScreen({ postKey }: { postKey: string }): React.ReactElement {
  useStore();
  const p = getPost(postKey);
  if (!p) return <div className="screen"><Header title={t('Статистика')} /><Empty title={t('Публикация недоступна')} /></div>;
  const s = postStats(postKey);
  const tiles: [string, string][] = [
    ['Просмотры', fmtCount(p.views)],
    ['Среднее время просмотра', fmtDur(s.avgWatch)],
    ['Досмотры', Math.round(s.completion * 100) + '%'],
    ['Лайки', fmtCount(p.likes)],
    ['Комментарии', fmtCount(p.comments)],
    ['Репосты', fmtCount(p.reposts)],
    ['Сохранения', fmtCount(p.saves)],
    ['Отправки', fmtCount(p.shares)],
  ];
  return (
    <div className="screen">
      <Header title={t('Статистика публикации')} />
      <div className="scroll pad col gap">
        <div className="row gap">
          <div className="stat-thumb">
            <Thumb post={p} onClick={() => go('post', { postKey })} />
          </div>
          <div className="min0">
            <div className="ell">{p.cap || t('Без описания')}</div>
            <small className="muted">{new Date(p.ts).toLocaleString()}</small>
          </div>
        </div>
        <div className="tiles">
          {tiles.map(([l, v]) => (
            <div key={l} className="tile">
              <small>{t(l)}</small>
              <b>{v}</b>
            </div>
          ))}
        </div>
        {p.t === 'video' && (
          <div className="card">
            <b>{t('Удержание аудитории')}</b>
            <small className="muted block">{t('Доля зрителей, досмотревших до каждой секунды')}</small>
            <Line values={s.retention} pct />
            <div className="chart-labels">
              <small>0:00</small>
              <small>{fmtDur((s.retention.length - 1) / 2)}</small>
              <small>{fmtDur(s.retention.length - 1)}</small>
            </div>
          </div>
        )}
        <div className="card">
          <b>{t('Источники трафика')}</b>
          <HBars data={s.sources} labelMap={SOURCES} />
        </div>
        <div className="card">
          <b>{t('Время просмотров')}</b>
          <Bars values={s.hours} labels={['0:00', '12:00', '23:00']} h={80} />
        </div>
      </div>
    </div>
  );
}
