// Write-side: every mutation the apps perform. Writes go to the viewer's own documents only.
import { caps, saveFile } from './caps';
import { genKeyPair } from './crypto';
import { agg, getPost } from './derive';
import { prepareImage, upload } from './media';
import { mePath, patch, patchMe, privPath, queued, ref, S, setDoc, COLLS } from './store';
import type { Banner, Comment, Lang, ModCfg, Post, Profile, Rec, Report, Settings, Story, Track } from './types';
import { DAY, allow, now, normalizeUsername, parseTags, pkey, rid, splitKey } from './util';

export class AppError extends Error {
  constructor(public code: string) {
    super(code);
  }
}
function need(): string {
  if (!S.uid || S.readOnly) throw new AppError('readonly');
  return S.uid;
}
function limit(bucket: string, n: number, win: number): void {
  if (!allow(bucket, n, win)) throw new AppError('rate');
}

// ---------- account ----------
export async function claimName(un: string, uid: string): Promise<void> {
  for (const other in S.u) if (other !== uid && S.u[other].un === un && !S.u[other].del) throw new AppError('taken');
  const r = ref('names/' + un);
  const lease = await r.acquire({ holder: uid, ttlMs: 5000 });
  if (!lease.acquired) throw new AppError('taken');
  const snap = await r.get();
  const owner = snap.exists ? (snap.data()?.uid as string | undefined) : undefined;
  if (owner && owner !== uid && S.u[owner]?.un === un && !S.u[owner]?.del) throw new AppError('taken');
  await r.set({ uid, ts: now() });
}

/** One-time write check for a new viewer; read-only viewers get the browse-only app. */
export async function probeWrite(): Promise<boolean> {
  if (!S.uid) return false;
  try {
    await setDoc(mePath(), { ...(S.me as Record<string, unknown>), probe: now() });
    return true;
  } catch {
    S.readOnly = true;
    return false;
  }
}

export interface RegisterInput {
  un: string;
  nm: string;
  bio: string;
  avatar?: File | null;
  bd: string;
  interests: string[];
  lang: Lang;
}
export async function register(inp: RegisterInput): Promise<void> {
  const uid = S.uid;
  if (!uid) throw new AppError('signedout');
  const un = normalizeUsername(inp.un);
  if (!/^[a-z0-9_]{3,24}$/.test(un)) throw new AppError('bad_un');
  const age = (now() - new Date(inp.bd).getTime()) / (365.25 * DAY);
  if (!isFinite(age) || age < 13) throw new AppError('age');
  // Probe write access first so read-only viewers get a clear message.
  try {
    await setDoc(mePath(), { ...(S.me as Record<string, unknown>), probe: now() });
  } catch {
    S.readOnly = true;
    throw new AppError('readonly');
  }
  await claimName(un, uid);
  const { pub, priv } = await genKeyPair();
  let av: string | undefined;
  if (inp.avatar && caps.assets) av = (await upload((await prepareImage(inp.avatar, 512)).blob)).id;
  await setDoc(mePath(), {
    sk: priv,
    int: Object.fromEntries(inp.interests.map((t) => [t, 1])),
    bd: inp.bd,
    set: { lang: inp.lang },
    ns: now(),
  });
  const prof: Profile = { un, nm: inp.nm.trim().slice(0, 30) || un, bio: inp.bio.slice(0, 80), pk: pub, ts: now(), unAt: now(), lang: navigator.language || inp.lang, dm: 'all', cmt: 'all', duet: 'all', dl: true };
  if (av) prof.av = av;
  await setDoc(`u/${uid}`, prof as unknown as Record<string, unknown>);
  for (const c of COLLS) if (c !== 'u' && !(S as unknown as Rec<Rec<unknown>>)[c][uid]) await setDoc(`${c}/${uid}`, {});
  S.readOnly = false;
}

/** Make sure my profile has an encryption key pair (older or migrated accounts). */
export async function ensureKeys(): Promise<void> {
  const uid = S.uid;
  if (!uid || S.readOnly || !S.u[uid]) return;
  if (S.me.sk && S.u[uid].pk) return;
  const { pub, priv } = await genKeyPair();
  await patchMe({ sk: priv });
  await patch('u', { pk: pub });
}

export async function updateProfile(ch: Partial<Profile>, avatar?: File | null): Promise<void> {
  const uid = need();
  const data: Record<string, unknown> = { ...ch };
  if (avatar) {
    if (avatar.type.startsWith('video/')) {
      if (avatar.size > 20 * 1024 * 1024) throw new AppError('too_large');
      data.av = (await upload(avatar)).id;
      data.avv = true;
    } else {
      data.av = (await upload((await prepareImage(avatar, 512)).blob)).id;
      data.avv = false;
    }
  }
  if (typeof ch.un === 'string' && ch.un !== S.u[uid]?.un) {
    const un = normalizeUsername(ch.un);
    if (!/^[a-z0-9_]{3,24}$/.test(un)) throw new AppError('bad_un');
    const last = S.u[uid]?.unAt || 0;
    if (now() - last < 30 * DAY) throw new AppError('un_wait');
    await claimName(un, uid);
    const old = S.u[uid]?.un;
    data.un = un;
    data.unAt = now();
    if (old) void ref('names/' + old).delete().catch(() => undefined);
  } else delete data.un;
  await patch('u', data);
}

export async function saveSettings(s: Partial<Settings>): Promise<void> {
  need();
  await patchMe({ set: { ...(S.me.set || {}), ...s } });
}

// ---------- social graph ----------
export async function follow(b: string, on: boolean): Promise<void> {
  need();
  limit('follow', 30, 60000);
  await patch('g', { fol: { [b]: on ? now() : 0 } });
}
export async function answerRequest(a: string, accept: boolean): Promise<void> {
  need();
  await patch('g', accept ? { acc: { [a]: now() }, rmv: { [a]: 0 } } : { acc: { [a]: 0 }, rmv: { [a]: now() } });
}
export async function removeFollower(a: string): Promise<void> {
  need();
  await patch('g', { rmv: { [a]: now() }, acc: { [a]: 0 } });
}
export async function block(b: string, on: boolean): Promise<void> {
  need();
  await patch('g', on ? { blk: { [b]: now() }, fol: { [b]: 0 }, rmv: { [b]: now() } } : { blk: { [b]: 0 } });
}

// ---------- engagement ----------
export async function like(key: string, on: boolean): Promise<void> {
  need();
  limit('like', 60, 60000);
  await patch('g', { lk: { [key]: on ? now() : 0 } });
}
export async function save(key: string, on: boolean): Promise<void> {
  need();
  limit('save', 40, 60000);
  await patch('g', { sv: { [key]: on ? now() : 0 } });
}
export async function repost(key: string, on: boolean): Promise<void> {
  need();
  limit('repost', 20, 60000);
  await patch('g', { rp: { [key]: on ? now() : 0 } });
}
export async function countShare(key: string): Promise<void> {
  const uid = S.uid;
  if (!uid || S.readOnly) return;
  const n = (S.g[uid]?.sh?.[key] || 0) + 1;
  await patch('g', { sh: { [key]: n } }).catch(() => undefined);
}
export async function vote(key: string, option: number): Promise<void> {
  need();
  await patch('g', { pl: { [key]: option + 1 } });
}
export async function setCollections(cols: Rec<string[]>): Promise<void> {
  need();
  await queued(mePath(), () => ref(mePath()).set({ ...(S.me as Record<string, unknown>), cols }));
}
export async function notInterested(key: string): Promise<void> {
  need();
  await patchMe({ ni: { [key]: now() } });
}
export async function resetRecommendations(): Promise<void> {
  const uid = need();
  const me = { ...(S.me as Record<string, unknown>) };
  delete me.ni;
  delete me.nia;
  delete me.int;
  await queued(mePath(), () => ref(mePath()).set(me));
  await queued(`v/${uid}`, () => ref(`v/${uid}`).set({ prof: S.v[uid]?.prof || {}, sv: S.v[uid]?.sv || {} }));
}

// ---------- comments ----------
export async function addComment(postKey: string, text: string, parent?: string, img?: string): Promise<string> {
  need();
  limit('comment', 8, 30000);
  const t = text.trim().slice(0, 500);
  if (!t && !img) throw new AppError('empty');
  const [pa, p] = splitKey(postKey);
  const cid = rid(10);
  const c: Comment = { p, pa, t, ts: now() };
  if (parent) c.r = parent;
  if (img) c.img = img;
  await patch('c', { cm: { [cid]: c } });
  return pkey(S.uid!, cid);
}
export async function deleteComment(ckey: string, postKey: string): Promise<void> {
  const uid = need();
  const [by, cid] = splitKey(ckey);
  if (by === uid) await patch('c', { cm: { [cid]: { del: 1, t: '' } } });
  else {
    const [pa, pid] = splitKey(postKey);
    if (pa !== uid) throw new AppError('denied');
    await updatePost(pid, { hc: { [ckey]: 1 } } as Partial<Post>);
  }
}
export async function likeComment(ckey: string, on: boolean): Promise<void> {
  need();
  limit('clike', 60, 60000);
  await patch('g', { cl: { [ckey]: on ? now() : 0 } });
}
export async function pinComment(postKey: string, ckey: string | null): Promise<void> {
  const uid = need();
  const [pa, pid] = splitKey(postKey);
  if (pa !== uid) throw new AppError('denied');
  await updatePost(pid, { pc: ckey || '' });
}

// ---------- posts ----------
export function newPost(t: Post['t']): Post {
  return { id: rid(12), by: S.uid || '', t, ts: now(), cap: '', priv: 'all', cm: true, du: true, stc: true, dl: S.u[S.uid || '']?.dl !== false };
}

export async function publishPost(post: Post): Promise<void> {
  const uid = need();
  limit('post', 10, 60000);
  const p: Post = { ...post, by: uid, ts: post.ts || now(), ht: parseTags(post.cap) };
  if (p.priv === 'me') await queued(privPath(), () => ref(privPath()).set({ posts: { ...(S.priv.posts || {}), [p.id]: p } }));
  else await patch('p', { posts: { [p.id]: p } });
}

export async function updatePost(pid: string, ch: Partial<Post>): Promise<void> {
  const uid = need();
  const isPriv = !!S.priv.posts?.[pid];
  const cur = isPriv ? S.priv.posts![pid] : S.p[uid]?.posts?.[pid];
  if (!cur) throw new AppError('missing');
  const merged: Post = { ...cur, ...ch, ed: now() } as Post;
  if (ch.cap !== undefined) merged.ht = parseTags(merged.cap);
  if (ch.hc) merged.hc = { ...(cur.hc || {}), ...ch.hc };
  const wantPriv = merged.priv === 'me';
  if (wantPriv !== isPriv) {
    // privacy moved between the public posts document and the private one
    if (wantPriv) {
      await queued(privPath(), () => ref(privPath()).set({ posts: { ...(S.priv.posts || {}), [pid]: merged } }));
      await removeFromPublic(pid);
    } else {
      await patch('p', { posts: { [pid]: merged } });
      const rest = { ...(S.priv.posts || {}) };
      delete rest[pid];
      await queued(privPath(), () => ref(privPath()).set({ posts: rest }));
    }
    return;
  }
  if (isPriv) await queued(privPath(), () => ref(privPath()).set({ posts: { ...(S.priv.posts || {}), [pid]: merged } }));
  else await patch('p', { posts: { [pid]: merged as unknown as Record<string, unknown> } });
}

async function removeFromPublic(pid: string): Promise<void> {
  const uid = S.uid!;
  const path = `p/${uid}`;
  await queued(path, async () => {
    const doc = { ...(S.p[uid] || {}) };
    const posts = { ...(doc.posts || {}) };
    delete posts[pid];
    await ref(path).set({ ...doc, posts });
  });
}

export async function deletePost(pid: string): Promise<void> {
  const uid = need();
  const post = getPost(pkey(uid, pid));
  if (S.priv.posts?.[pid]) {
    const rest = { ...(S.priv.posts || {}) };
    delete rest[pid];
    await queued(privPath(), () => ref(privPath()).set({ posts: rest }));
  } else await removeFromPublic(pid);
  const pins = (S.u[uid]?.pins || []).filter((x) => x !== pid);
  await patch('u', { pins });
  if (post && caps.assets) {
    const ids = [...(post.clips || []).map((c) => c.a), ...(post.ph || []), post.poster].filter(Boolean) as string[];
    for (const id of ids) void caps.assets.delete(id).catch(() => undefined);
  }
}

export async function pinPost(pid: string, on: boolean): Promise<void> {
  const uid = need();
  let pins = (S.u[uid]?.pins || []).filter((x) => x !== pid);
  if (on) {
    if (pins.length >= 3) throw new AppError('pins');
    pins = [pid, ...pins];
  }
  await patch('u', { pins });
}

export async function saveDraft(post: Post): Promise<void> {
  need();
  await patchMe({ drafts: { [post.id]: { id: post.id, ts: now(), post } } });
}
export async function deleteDraft(id: string): Promise<void> {
  need();
  const drafts = { ...(S.me.drafts || {}) };
  delete drafts[id];
  await queued(mePath(), () => ref(mePath()).set({ ...(S.me as Record<string, unknown>), drafts }));
}

export async function addTrack(tr: Track): Promise<void> {
  need();
  await patch('p', { tracks: { [tr.id]: tr } });
}
export async function favSound(key: string, on: boolean): Promise<void> {
  need();
  await patchMe({ fs: { [key]: on ? now() : 0 } });
}

// ---------- views ----------
const viewWriteTimes: Rec<number> = {};
export async function recordView(key: string, watchMs: number, completed: boolean, maxSec: number, src: string): Promise<void> {
  const uid = S.uid;
  if (!uid || S.readOnly || watchMs < 1000) return; // honest views: at least one second watched
  const cur = S.v[uid]?.pv?.[key];
  const v = {
    n: (cur?.n || 0) + 1,
    w: (cur?.w || 0) + Math.round(watchMs),
    c: (cur?.c || 0) + (completed ? 1 : 0),
    l: now(),
    s: src,
    m: [...(cur?.m || []).slice(-4), Math.round(maxSec)],
  };
  const pv = S.v[uid]?.pv || {};
  if (Object.keys(pv).length > 450) {
    const kept = Object.entries(pv)
      .sort((a, b) => b[1].l - a[1].l)
      .slice(0, 350);
    await queued(`v/${uid}`, () => ref(`v/${uid}`).set({ ...(S.v[uid] || {}), pv: { ...Object.fromEntries(kept), [key]: v } })).catch(() => undefined);
    return;
  }
  await patch('v', { pv: { [key]: v } }).catch(() => undefined);
}
export async function recordProfileView(target: string): Promise<void> {
  const uid = S.uid;
  if (!uid || S.readOnly || uid === target) return;
  if (S.u[uid]?.pvOff || S.u[target]?.pvOff) return;
  if (now() - (viewWriteTimes[target] || 0) < 10 * 60000) return;
  viewWriteTimes[target] = now();
  await patch('v', { prof: { [target]: now() } }).catch(() => undefined);
}
export async function recordStoryView(owner: string, sid: string): Promise<void> {
  const uid = S.uid;
  if (!uid || S.readOnly || uid === owner) return;
  const k = pkey(owner, sid);
  if (S.v[uid]?.sv?.[k]) return;
  await patch('v', { sv: { [k]: now() } }).catch(() => undefined);
}

// ---------- stories ----------
export async function publishStory(st: Story): Promise<void> {
  const uid = need();
  limit('story', 10, 60000);
  const cur = S.s[uid]?.st || {};
  const fresh = Object.fromEntries(Object.entries(cur).filter(([, s]) => s && now() - s.ts < DAY));
  await queued(`s/${uid}`, () => ref(`s/${uid}`).set({ st: { ...fresh, [st.id]: st } }));
}
export async function deleteStory(sid: string): Promise<void> {
  const uid = need();
  const cur = { ...(S.s[uid]?.st || {}) };
  delete cur[sid];
  await queued(`s/${uid}`, () => ref(`s/${uid}`).set({ st: cur }));
}

// ---------- reports & moderation ----------
export async function report(r: Omit<Report, 'ts'>): Promise<void> {
  const uid = need();
  limit('report', 10, 60000);
  const path = `rep/${uid}`;
  const id = rid(8);
  await queued(path, async () => {
    try {
      await ref(path).update({ r: { [id]: { ...r, ts: now() } } });
    } catch {
      await ref(path).set({ r: { [id]: { ...r, ts: now() } } });
    }
  });
}
async function modPatch(data: Partial<ModCfg> | Record<string, unknown>): Promise<void> {
  if (!S.isOwner) throw new AppError('denied');
  await queued('mod/cfg', async () => {
    try {
      await ref('mod/cfg').update(data as Record<string, unknown>);
    } catch {
      await ref('mod/cfg').set({ ...(S.mod as Record<string, unknown>), ...(data as Record<string, unknown>) });
    }
  });
}
export const modRemove = (key: string, on = true): Promise<void> => modPatch({ removed: { [key]: on ? now() : 0 } });
export const modBan = (uid: string, on = true): Promise<void> => modPatch({ bans: { [uid]: on ? now() : 0 } });
export const modResolve = (rk: string): Promise<void> => modPatch({ resolved: { [rk]: now() } });
export const modTrends = (trends: string[]): Promise<void> => modPatch({ trends });
export const modBanners = (banners: Banner[]): Promise<void> => modPatch({ banners });
export const modTagDesc = (tag: string, d: string): Promise<void> => modPatch({ tagDesc: { [tag]: d } });

// ---------- data export & account deletion ----------
export async function exportData(): Promise<boolean> {
  const uid = need();
  const data: Rec<unknown> = { exportedAt: new Date().toISOString() };
  for (const c of COLLS) data[c] = (S as unknown as Rec<Rec<unknown>>)[c][uid] || null;
  const me = { ...(S.me as Record<string, unknown>) };
  delete me.sk;
  data.private = me;
  data.privatePosts = S.priv;
  return saveFile(`my-data-${S.u[uid]?.un || 'account'}.json`, JSON.stringify(data, null, 2));
}
export async function deleteAccount(): Promise<void> {
  const uid = need();
  const A = agg();
  if (caps.assets) {
    for (const p of A.posts.values()) {
      if (p.by !== uid) continue;
      for (const id of [...(p.clips || []).map((c) => c.a), ...(p.ph || []), p.poster]) if (id) void caps.assets.delete(id).catch(() => undefined);
    }
  }
  const un = S.u[uid]?.un;
  for (const c of COLLS) if (c !== 'u') await queued(`${c}/${uid}`, () => ref(`${c}/${uid}`).delete()).catch(() => undefined);
  await queued(privPath(), () => ref(privPath()).delete()).catch(() => undefined);
  await queued(mePath(), () => ref(mePath()).delete()).catch(() => undefined);
  if (un) await ref('names/' + un).delete().catch(() => undefined);
  await queued(`u/${uid}`, () => ref(`u/${uid}`).delete());
}
