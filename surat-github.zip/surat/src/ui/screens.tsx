import React, { useEffect, useRef, useState } from 'react';
import { ensureKeys } from '../core/actions';
import { agg, getPost } from '../core/derive';
import { S, useStore } from '../core/store';
import { hashToUn, lsGet, lsSet } from '../core/util';
import { AdminScreen } from './admin';
import { AnalyticsScreen, PostStatsScreen } from './analytics';
import { ChatRequestsScreen, ChatScreen, NewChatScreen } from './chat';
import { CommentsSheet } from './comments';
import { cfg } from './config';
import { CreateScreen, DraftsScreen, EditPostScreen } from './create';
import { VerticalFeed } from './feed';
import { t } from './i18n';
import { Icon } from './icons';
import { NotificationsScreen } from './inbox';
import { DialogHost, SheetHost, Toasts } from './kit';
import { back, go, nav, sheet, toast, type Screen } from './nav';
import { msrc } from './player';
import { EditProfileScreen, FindPeopleScreen, FollowsScreen, ProfileScreen, ProfileViewsScreen } from './profile';
import { SearchScreen, TagScreen } from './search';
import { AboutScreen, AccountSettings, BlockedSettings, ContentSettings, DataSettings, DisplaySettings, NotifSettings, PrivacySettings, SettingsScreen, TimeSettings } from './settings';
import { SoundScreen } from './sounds';
import { StoryViewer } from './stories';
import { dismissJob, jobs, runJob } from './upload';

export function PostScreen({ postKey, list, src, openComments, visible }: { postKey: string; list?: string[]; src?: string; openComments?: boolean; visible: boolean }): React.ReactElement {
  const keys = list && list.includes(postKey) ? list : [postKey];
  const initial = Math.max(0, keys.indexOf(postKey));
  useEffect(() => {
    if (openComments) sheet(() => <CommentsSheet postKey={postKey} />, true);
  }, []);
  return (
    <div className="screen post-screen dark-screen">
      <VerticalFeed keys={keys} src={src || 'post'} visible={visible} initial={initial} />
      <button className="float-back" onClick={back} aria-label={t('Назад')}>
        <Icon n="back" />
      </button>
    </div>
  );
}

export type ScreenRenderer = (s: Screen, visible: boolean) => React.ReactNode | undefined;

export function renderShared(s: Screen, visible: boolean): React.ReactNode {
  const p = s.props as Record<string, never>;
  switch (s.name) {
    case 'post':
      return <PostScreen postKey={p.postKey} list={p.list} src={p.src} openComments={p.openComments} visible={visible} />;
    case 'profile':
      return <ProfileScreen uid={p.uid} />;
    case 'editprofile':
      return <EditProfileScreen />;
    case 'follows':
      return <FollowsScreen uid={p.uid || S.uid} tab={p.tab || 'followers'} />;
    case 'find-people':
      return <FindPeopleScreen />;
    case 'profileviews':
      return <ProfileViewsScreen />;
    case 'create':
      return <CreateScreen {...(p as object)} />;
    case 'editpost':
      return <EditPostScreen postKey={p.postKey} />;
    case 'drafts':
      return <DraftsScreen />;
    case 'sound':
      return <SoundScreen soundKey={p.key} />;
    case 'tag':
      return <TagScreen tag={p.tag} />;
    case 'search':
      return <SearchScreen q={p.q} />;
    case 'notifications':
      return <NotificationsScreen />;
    case 'chat':
      return <ChatScreen cid={p.cid} />;
    case 'newchat':
      return <NewChatScreen />;
    case 'chatrequests':
      return <ChatRequestsScreen />;
    case 'stories':
      return <StoryViewer start={p.start} list={p.list} only={p.only} />;
    case 'settings':
      return <SettingsScreen />;
    case 'set-account':
      return <AccountSettings />;
    case 'set-privacy':
      return <PrivacySettings />;
    case 'set-blocked':
      return <BlockedSettings />;
    case 'set-notif':
      return <NotifSettings />;
    case 'set-content':
      return <ContentSettings />;
    case 'set-time':
      return <TimeSettings />;
    case 'set-data':
      return <DataSettings />;
    case 'set-display':
      return <DisplaySettings />;
    case 'about':
      return <AboutScreen />;
    case 'admin':
      return <AdminScreen />;
    case 'analytics':
      return <AnalyticsScreen />;
    case 'poststats':
      return <PostStatsScreen postKey={p.postKey} />;
    default:
      return null;
  }
}

/** Renders the navigation stack above the tabs; only the top screen is "visible". */
export function Stack({ render }: { render?: ScreenRenderer }): React.ReactElement {
  useStore();
  return (
    <>
      {nav.stack.map((s, i) => {
        const visible = i === nav.stack.length - 1 && nav.sheets.length === 0;
        const top = i === nav.stack.length - 1;
        const el = render?.(s, top) ?? renderShared(s, top);
        return (
          <div key={s.id} className={'layer' + (top ? ' top' : '')} aria-hidden={!top}>
            {el}
            {!visible && top && null}
          </div>
        );
      })}
    </>
  );
}

export function JobsBar(): React.ReactElement | null {
  useStore();
  if (!jobs.length) return null;
  return (
    <div className="jobs">
      {jobs.map((j) => (
        <div key={j.id} className={'job ' + j.status}>
          <span className="job-thumb">{j.thumb ? <img src={j.thumb} alt="" /> : <Icon n={j.post.t === 'photo' ? 'image' : j.post.t === 'text' ? 'text' : 'video'} size={18} />}</span>
          <span className="grow min0">
            <b className="block ell">{j.status === 'error' ? j.error : j.status === 'done' ? t('Готово') : j.stage || t('Загрузка…')}</b>
            {j.status !== 'error' && (
              <span className="job-bar">
                <i style={{ width: `${Math.round(j.progress * 100)}%` }} />
              </span>
            )}
          </span>
          {j.status === 'running' && <small>{Math.round(j.progress * 100)}%</small>}
          {j.status === 'error' && (
            <>
              <button className="btn btn-primary btn-sm" onClick={() => void runJob(j)}>
                {t('Повторить')}
              </button>
              <button className="icon-btn" onClick={() => dismissJob(j)} aria-label={t('Закрыть')}>
                <Icon n="close" size={16} />
              </button>
            </>
          )}
        </div>
      ))}
    </div>
  );
}

/** Theme from settings; without a saved choice the app uses `defaultTheme`. */
let hostTheme: string | null | undefined;
export function useTheme(defaultTheme: 'dark' | 'system'): void {
  useStore();
  const th = S.me.set?.theme || lsGet<string | null>('theme', null) || defaultTheme;
  useEffect(() => {
    const root = document.documentElement;
    if (hostTheme === undefined) hostTheme = root.getAttribute('data-theme');
    if (th === 'dark' || th === 'light') root.setAttribute('data-theme', th);
    else if (hostTheme) root.setAttribute('data-theme', hostTheme);
    else root.removeAttribute('data-theme');
  }, [th]);
}

/** Screen-time tracking: break reminders and a daily limit (per device). */
export function ScreenTime(): React.ReactElement | null {
  useStore();
  const [blocked, setBlocked] = useState(false);
  const last = useRef(performance.now());
  const sinceBreak = useRef(0);
  const extra = useRef(0);
  useEffect(() => {
    const id = setInterval(() => {
      const nowT = performance.now();
      const dt = Math.min(5000, nowT - last.current);
      last.current = nowT;
      if (document.hidden) return;
      const day = new Date().toDateString();
      const st = lsGet<{ day: string; ms: number }>('st', { day, ms: 0 });
      const ms = (st.day === day ? st.ms : 0) + dt;
      lsSet('st', { day, ms });
      sinceBreak.current += dt;
      const brk = S.me.set?.brk || 0;
      if (brk && sinceBreak.current > brk * 60000) {
        sinceBreak.current = 0;
        toast(t('Вы смотрите уже {m} мин. Может, сделать перерыв?', { m: brk }));
      }
      const lim = S.me.set?.lim || 0;
      if (lim && ms > (lim + extra.current) * 60000) setBlocked(true);
    }, 2000);
    return () => clearInterval(id);
  }, []);
  if (!blocked) return null;
  return (
    <div className="limit-wall">
      <Icon n="clock" size={48} />
      <b>{t('Дневной лимит исчерпан')}</b>
      <p>{t('Вы установили лимит экранного времени. Отдохните и возвращайтесь завтра.')}</p>
      <button className="btn btn-muted" onClick={() => ((extra.current += 15), setBlocked(false))}>
        {t('Ещё 15 минут')}
      </button>
    </div>
  );
}

/** Open #post-… / #user-… links inside the app. */
export function useDeepLinks(): void {
  useStore();
  const done = useRef(false);
  useEffect(() => {
    const open = (): void => {
      const h = location.hash.replace(/^#/, '');
      if (!h) return;
      if (h.startsWith('post-')) {
        const id = h.slice(5);
        const p = [...agg().posts.values()].find((x) => x.id === id);
        if (p) go('post', { postKey: p.key, src: 'share' });
        else toast(t('Публикация недоступна'));
      } else if (h.startsWith('user-')) {
        const un = hashToUn(h.slice(5));
        const uid = Object.keys(S.u).find((u) => S.u[u].un === un);
        if (uid) go('profile', { uid });
        else toast(t('Аккаунт не найден'));
      }
    };
    if (S.phase === 'ready' && !done.current) {
      done.current = true;
      open();
      void ensureKeys().catch(() => undefined);
    }
    window.addEventListener('hashchange', open);
    return () => window.removeEventListener('hashchange', open);
  }, [S.phase]);
}

export function Overlays(): React.ReactElement {
  return (
    <>
      <JobsBar />
      <SheetHost />
      <DialogHost />
      <Toasts />
      <ScreenTime />
    </>
  );
}

export function BootGate({ logo, children, onboarding }: { logo: React.ReactNode; children: React.ReactNode; onboarding: React.ReactNode }): React.ReactElement {
  useStore();
  if (S.phase === 'boot' || S.phase === 'loading')
    return (
      <div className="splash">
        {logo}
        <span className="spin" />
      </div>
    );
  if (S.phase === 'nocaps' || S.phase === 'signedout')
    return (
      <div className="splash col gap">
        {logo}
        <p className="center pad">{S.phase === 'nocaps' ? t('Откройте {app} на claude.ai: приложению нужна его база данных.', { app: cfg.name }) : t('Войдите в свой аккаунт Claude, чтобы смотреть и публиковать.')}</p>
      </div>
    );
  if (S.uid && !S.u[S.uid] && !S.readOnly) return <>{onboarding}</>;
  return <>{children}</>;
}

export { getPost, msrc };
