import React, { useState } from 'react';
import { probeWrite, register } from '../core/actions';
import { trendingTags } from '../core/derive';
import { bump, S, useStore } from '../core/store';
import type { Lang } from '../core/types';
import { cx, normalizeUsername } from '../core/util';
import { cfg } from './config';
import { lang, t } from './i18n';
import { Icon } from './icons';
import { errToast, FilePick, Spinner } from './kit';

const TOPICS = ['юмор', 'музыка', 'танцы', 'еда', 'спорт', 'путешествия', 'животные', 'игры', 'красота', 'мода', 'наука', 'кино', 'авто', 'diy', 'учёба', 'природа', 'искусство', 'фитнес', 'технологии', 'лайфхаки'];

export function Onboarding({ logo }: { logo: React.ReactNode }): React.ReactElement {
  useStore();
  const [step, setStep] = useState(0);
  const [bd, setBd] = useState('');
  const [un, setUn] = useState('');
  const [nm, setNm] = useState('');
  const [bio, setBio] = useState('');
  const [av, setAv] = useState<File | null>(null);
  const [ints, setInts] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);
  const taken = !!un && Object.values(S.u).some((p) => p.un === un && !p.del);
  const age = bd ? (Date.now() - new Date(bd).getTime()) / (365.25 * 86400000) : 0;
  const topics = [...new Set([...trendingTags(8).map((x) => x.tag), ...TOPICS])].slice(0, 26);
  const finish = async (): Promise<void> => {
    setBusy(true);
    try {
      await register({ un, nm, bio, avatar: av, bd, interests: ints, lang: lang() as Lang });
    } catch (e) {
      errToast(e);
    } finally {
      setBusy(false);
    }
  };
  return (
    <div className="onb">
      <div className="onb-logo">{logo}</div>
      {step === 0 && (
        <div className="onb-card col gap">
          <h1>{t('Добро пожаловать в {app}', { app: cfg.name })}</h1>
          <p className="muted">{t('Короткие видео, фото и истории ваших друзей. Создайте профиль за минуту.')}</p>
          <label className="field" htmlFor="onb-bd">
            <span>{t('Дата рождения')}</span>
            <input id="onb-bd" type="date" className="input" value={bd} max={new Date().toISOString().slice(0, 10)} onChange={(e) => setBd(e.target.value)} />
            <small className="muted">{t('Не будет показана в профиле. Регистрация доступна с 13 лет.')}</small>
          </label>
          {bd && age < 13 && <p className="danger-text">{t('Регистрация доступна с 13 лет')}</p>}
          <button
            className="btn btn-primary btn-lg"
            disabled={!bd || age < 13 || busy}
            onClick={async () => {
              setBusy(true);
              const ok = await probeWrite();
              setBusy(false);
              if (ok) setStep(1);
              else bump();
            }}
          >
            {busy ? <Spinner size={18} /> : t('Далее')}
          </button>
        </div>
      )}
      {step === 1 && (
        <div className="onb-card col gap">
          <h1>{t('Ваш профиль')}</h1>
          <div className="center col gap-s">
            {av ? <img className="av-preview" src={URL.createObjectURL(av)} alt="" /> : <span className="av-preview av-empty"><Icon n="user" size={40} /></span>}
            {S.canUpload && (
              <FilePick id="onb-av" accept="image/*" onFiles={([f]) => setAv(f)} className="link-btn">
                {t('Добавить фото')}
              </FilePick>
            )}
          </div>
          <label className="field" htmlFor="onb-un">
            <span>{t('Ник')}</span>
            <div className="input-prefix">
              <span>@</span>
              <input id="onb-un" className="input" maxLength={24} value={un} onChange={(e) => setUn(normalizeUsername(e.target.value))} placeholder="your_name" autoCapitalize="off" />
            </div>
            <small className={cx(taken ? 'danger-text' : 'muted')}>{taken ? t('Этот ник уже занят') : t('3–24 символа: латиница, цифры и _')}</small>
          </label>
          <label className="field" htmlFor="onb-nm">
            <span>{t('Имя')}</span>
            <input id="onb-nm" className="input" maxLength={30} value={nm} onChange={(e) => setNm(e.target.value)} />
          </label>
          <label className="field" htmlFor="onb-bio">
            <span>{t('О себе')}</span>
            <input id="onb-bio" className="input" maxLength={80} value={bio} onChange={(e) => setBio(e.target.value)} />
          </label>
          <div className="row gap-s">
            <button className="btn btn-muted" onClick={() => setStep(0)}>
              {t('Назад')}
            </button>
            <button className="btn btn-primary grow" disabled={un.length < 3 || taken} onClick={() => setStep(2)}>
              {t('Далее')}
            </button>
          </div>
        </div>
      )}
      {step === 2 && (
        <div className="onb-card col gap">
          <h1>{t('Что вам интересно?')}</h1>
          <p className="muted">{t('Выберите темы — так лента «Для вас» сразу станет вашей.')}</p>
          <div className="chips wrap">
            {topics.map((x) => (
              <button key={x} className={cx('chip', ints.includes(x) && 'on')} onClick={() => setInts(ints.includes(x) ? ints.filter((y) => y !== x) : [...ints, x])}>
                #{x}
              </button>
            ))}
          </div>
          <div className="row gap-s">
            <button className="btn btn-muted" onClick={() => setStep(1)}>
              {t('Назад')}
            </button>
            <button className="btn btn-primary grow" disabled={busy} onClick={() => void finish()}>
              {busy ? <Spinner size={18} /> : t('Начать')}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
