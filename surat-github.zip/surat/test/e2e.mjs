// End-to-end test: two users sign up, post, like, comment, follow and exchange encrypted messages.
// Runs against test/server.mjs (a local stand-in for claude.ai). Needs Playwright with Chromium.
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
import { startServer } from './server.mjs';
import { offline } from './routes.mjs';

const require = createRequire(import.meta.url);
let chromium;
try {
  ({ chromium } = require('playwright'));
} catch {
  console.log('Playwright is not installed. Install it once with:\n  npm i -D playwright && npx playwright install chromium');
  process.exit(1);
}

const fx = (f) => fileURLToPath(new URL(`fixtures/${f}`, import.meta.url));
const server = await startServer(0);
const B = `http://localhost:${server.address().port}/`;
const browser = await chromium.launch({ args: ['--autoplay-policy=no-user-gesture-required'] });
const ctx = await browser.newContext({ viewport: { width: 400, height: 820 } });
await offline(ctx);

const errors = [];
let failed = 0;
const step = async (name, fn) => {
  try {
    await fn();
    console.log('ok  ', name);
  } catch (e) {
    failed++;
    console.log('FAIL', name, '-', String(e.message).split('\n')[0]);
  }
};
const open = async (uid, owner) => {
  const p = await ctx.newPage();
  p.on('pageerror', (e) => errors.push(`${uid}: ${e.message}`));
  p.on('console', (m) => m.type() === 'error' && errors.push(`${uid} console: ${m.text()}`));
  await p.goto(`${B}?uid=${uid}${owner ? '&owner=1' : ''}`);
  return p;
};
const signUp = async (p, un, nm) => {
  await p.fill('#onb-bd', '1999-05-05');
  await p.click('.onb-card .btn-primary');
  await p.fill('#onb-un', un);
  await p.fill('#onb-nm', nm);
  await p.click('.onb-card .btn-primary');
  await p.click('.chip >> nth=1');
  await p.click('.onb-card .btn-primary');
  await p.waitForSelector('.bottom-nav', { timeout: 8000 });
};
const waitUploads = (p) => p.waitForFunction(() => !document.querySelector('.job'), null, { timeout: 30000 });

const a = await open('u_alice', true);
await step('opens in Uzbek by default', async () => {
  await a.waitForSelector('.onb-card h1');
  const h = await a.locator('.onb-card h1').innerText();
  if (!h.includes('xush kelibsiz')) throw new Error(`heading: ${h}`);
});
// The rest of the test uses Russian labels.
await a.evaluate(() => localStorage.setItem('lang', '"ru"'));
await a.reload();
await step('alice signs up', () => signUp(a, 'alisa', 'Alisa'));
await step('alice posts a photo carousel', async () => {
  await a.click('.bottom-nav [aria-label="Создать"]');
  await a.click('.mode-tabs >> text=Фото');
  await a.setInputFiles('#pick-gallery', [fx('photo1.jpg'), fx('photo2.jpg')]);
  await a.waitForSelector('.editor');
  await a.click('.ed-top >> text=Далее');
  await a.fill('#pub-caption', 'Samarqand kechasi #samarqand #travel');
  await a.fill('#pub-loc', 'Samarqand');
  await a.click('.pub-bar >> text=Опубликовать');
  await waitUploads(a);
});
await step('alice posts a video', async () => {
  await a.click('.bottom-nav [aria-label="Создать"]');
  await a.setInputFiles('#pick-gallery', [fx('clip.mp4')]);
  await a.waitForSelector('.editor');
  await a.click('.ed-top >> text=Далее');
  await a.fill('#pub-caption', 'Fraktal #art');
  await a.click('.pub-bar >> text=Опубликовать');
  await waitUploads(a);
});

const b = await open('u_bob', false);
await b.evaluate(() => localStorage.setItem('lang', '"ru"'));
await b.reload();
await step('bob signs up', () => signUp(b, 'bobur', 'Bobur'));
await step('bob sees alice’s posts', async () => {
  await b.waitForSelector('.card-post', { timeout: 8000 });
});
await step('bob likes with a double tap', async () => {
  await b.locator('.cp-media').first().dblclick({ position: { x: 200, y: 200 } });
  await b.waitForSelector('.cp-actions .liked', { timeout: 4000 });
});
await step('bob comments', async () => {
  await b.locator('.cp-actions [aria-label="Комментарии"]').first().click();
  await b.fill('#comment-input', 'Juda chiroyli!');
  await b.keyboard.press('Enter');
  await b.waitForSelector('.cmt-text', { timeout: 4000 });
  await b.click('.sheet-wrap', { position: { x: 10, y: 10 } });
});
await step('bob follows alice', async () => {
  await b.locator('.cp-head b').first().click();
  await b.waitForSelector('.ig-profile');
  await b.click('.igp-btns .btn-primary');
  await b.waitForSelector('.igp-btns >> text=Вы подписаны', { timeout: 4000 });
});
await step('bob sends alice an encrypted message', async () => {
  await b.click('.igp-btns >> text=Сообщение');
  await b.waitForSelector('.chat');
  await b.fill('#chat-text', 'Salom, Alisa!');
  await b.keyboard.press('Enter');
  await b.waitForSelector('.bubble.mine', { timeout: 5000 });
});
await step('explore and reels open', async () => {
  await b.goto(`${B}?uid=u_bob`);
  await b.waitForSelector('.bottom-nav');
  await b.click('.bottom-nav [aria-label="Поиск"]');
  await b.waitForSelector('.explore-grid .eg-item');
  await b.click('.bottom-nav [aria-label="Рилсы"]');
  await b.waitForSelector('.reels .vitem');
});
await a.bringToFront();
await step('alice gets notifications', async () => {
  await a.click('.bottom-nav [aria-label="Главная"]');
  await a.click('.ig-top [aria-label="Уведомления"]');
  await a.waitForSelector('.notif', { timeout: 5000 });
  const txt = await a.locator('.layer.top').innerText();
  if (!txt.includes('Bobur')) throw new Error('no notification from Bobur');
  await a.click('.layer.top [aria-label="Назад"]');
});
await step('alice reads the decrypted message', async () => {
  await a.click('.ig-top [aria-label="Сообщения"]');
  await a.click('text=Запросы на переписку');
  await a.locator('.conv-row').first().click();
  await a.waitForSelector('.bubble:not(.mine) >> text=Salom, Alisa!', { timeout: 8000 });
});

if (errors.length) {
  failed++;
  console.log('Page errors:\n' + errors.slice(0, 10).join('\n'));
}
await browser.close();
server.close();
console.log(failed ? `\n${failed} check(s) failed` : '\nAll checks passed');
process.exit(failed ? 1 : 0);
