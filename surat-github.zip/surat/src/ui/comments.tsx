import React, { useMemo, useState } from 'react';
import { addComment, deleteComment, likeComment, pinComment } from '../core/actions';
import { audienceOk, commentsFor, getPost, searchUsers, type CommentX } from '../core/derive';
import { prepareImage, upload } from '../core/media';
import { S, useStore } from '../core/store';
import { cx, fmtCount, has, blob } from '../core/util';
import { t, timeAgo } from './i18n';
import { Icon } from './icons';
import { act, Avatar, Empty, errToast, FilePick, MenuItem, RichText, Spinner } from './kit';
import { closeAllSheets, closeSheet, confirmDialog, go, sheet } from './nav';
import { copyText, ReportSheet } from './share';

const EMOJI = ['😂', '😍', '🔥', '👏', '😮', '😢', '🙏', '❤️'];

export function CommentsSheet({ postKey }: { postKey: string }): React.ReactElement {
  useStore();
  const post = getPost(postKey);
  const [text, setText] = useState('');
  const [replyTo, setReplyTo] = useState<CommentX | null>(null);
  const [open, setOpen] = useState<Record<string, boolean>>({});
  const [busy, setBusy] = useState(false);
  const [img, setImg] = useState<{ id: string; url: string } | null>(null);
  const all = post ? commentsFor(postKey) : [];
  const { tops, replies } = useMemo(() => {
    const tops: CommentX[] = [];
    const replies = new Map<string, CommentX[]>();
    const byKey = new Map(all.map((c) => [c.key, c]));
    for (const c of all) {
      if (c.r) {
        // flatten nested replies under their top-level comment
        let root = byKey.get(c.r);
        while (root?.r && byKey.get(root.r)) root = byKey.get(root.r);
        const k = root ? root.key : c.r;
        const arr = replies.get(k) || [];
        arr.push(c);
        replies.set(k, arr);
      } else tops.push(c);
    }
    const score = (c: CommentX): number => c.likes * 2 + (replies.get(c.key)?.length || 0) + (c.by === post?.by ? 1 : 0);
    tops.sort((a, b) => (a.key === post?.pc ? -1 : b.key === post?.pc ? 1 : score(b) - score(a) || b.ts - a.ts));
    for (const arr of replies.values()) arr.sort((a, b) => a.ts - b.ts);
    return { tops, replies };
  }, [all, post?.pc]);

  if (!post) return <div className="pad">{t('Публикация недоступна')}</div>;
  const allowed = post.cm && audienceOk(S.u[post.by]?.cmt, post.by);
  const mention = /@([a-z0-9_]*)$/i.exec(text);
  const mentionList = mention ? searchUsers(mention[1], 6) : [];

  const submit = async (): Promise<void> => {
    if (busy || (!text.trim() && !img)) return;
    setBusy(true);
    try {
      await addComment(postKey, text, replyTo?.key, img?.id);
      setText('');
      setImg(null);
      if (replyTo) setOpen((o) => ({ ...o, [replyTo.r || replyTo.key]: true }));
      setReplyTo(null);
    } catch (e) {
      errToast(e);
    } finally {
      setBusy(false);
    }
  };

  const row = (c: CommentX, isReply = false): React.ReactElement => {
    const liked = S.uid ? has(S.g[S.uid]?.cl, c.key) : false;
    const isAuthor = c.by === post.by;
    return (
      <div key={c.key} className={cx('cmt', isReply && 'cmt-reply')}>
        <Avatar uid={c.by} size={isReply ? 28 : 36} onClick={() => (closeAllSheets(), go('profile', { uid: c.by }))} />
        <div className="grow min0" onContextMenu={(e) => (e.preventDefault(), menu(c))}>
          <div className="cmt-name">
            <span className="tap" onClick={() => (closeAllSheets(), go('profile', { uid: c.by }))}>
              {S.u[c.by]?.nm || S.u[c.by]?.un}
            </span>
            {isAuthor && <span className="badge">{t('Автор')}</span>}
            {post.pc === c.key && <span className="badge badge-pin">{t('Закреплён')}</span>}
          </div>
          {c.t && <RichText text={c.t} className="cmt-text" />}
          {c.img && <img className="cmt-img" src={blob(c.img)} alt="" loading="lazy" />}
          <div className="cmt-meta">
            <span>{timeAgo(c.ts)}</span>
            {allowed && (
              <button className="link-btn" onClick={() => (setReplyTo(c), setText(c.by !== S.uid ? `@${S.u[c.by]?.un} ` : ''))}>
                {t('Ответить')}
              </button>
            )}
            <button className="link-btn" onClick={() => menu(c)} aria-label={t('Ещё')}>
              <Icon n="more" size={16} />
            </button>
          </div>
        </div>
        <button className={cx('cmt-like', liked && 'on')} onClick={() => void act(() => likeComment(c.key, !liked))} aria-label={t('Нравится')}>
          <Icon n="heart" size={18} fill={liked} />
          <small>{c.likes ? fmtCount(c.likes) : ''}</small>
        </button>
      </div>
    );
  };

  const menu = (c: CommentX): void => {
    const me = S.uid;
    const mineComment = c.by === me;
    const myPost = post.by === me;
    sheet(() => (
      <div>
        <MenuItem icon="copy" label={t('Копировать')} onClick={() => (void copyText(c.t), closeSheet())} />
        {myPost && (
          <MenuItem icon="pin" label={post.pc === c.key ? t('Открепить') : t('Закрепить')} onClick={() => (void act(() => pinComment(postKey, post.pc === c.key ? null : c.key)), closeSheet())} />
        )}
        {myPost && !mineComment && (
          <MenuItem icon="video" label={t('Ответить видео')} onClick={() => (closeAllSheets(), go('create', { vreply: { key: c.key, t: c.t.slice(0, 120), au: c.by } }))} />
        )}
        {(mineComment || myPost) && (
          <MenuItem
            icon="trash"
            danger
            label={t('Удалить')}
            onClick={async () => {
              closeSheet();
              if (await confirmDialog(t('Удалить комментарий?'), t('Удалить'))) void act(() => deleteComment(c.key, postKey));
            }}
          />
        )}
        {!mineComment && <MenuItem icon="flag" label={t('Пожаловаться')} onClick={() => sheet(() => <ReportSheet k="comment" id={c.key} />)} />}
      </div>
    ));
  };

  return (
    <div className="comments">
      <div className="comments-hdr">
        <b>
          {fmtCount(all.length)} {t('комментариев')}
        </b>
        <button className="icon-btn" onClick={closeSheet} aria-label={t('Закрыть')}>
          <Icon n="close" size={20} />
        </button>
      </div>
      <div className="comments-list">
        {tops.length === 0 && <Empty icon="comment" title={t('Пока нет комментариев')} text={allowed ? t('Начните обсуждение') : undefined} />}
        {tops.map((c) => {
          const rs = replies.get(c.key) || [];
          return (
            <div key={c.key}>
              {row(c)}
              {rs.length > 0 &&
                (open[c.key] ? (
                  <>
                    {rs.map((r) => row(r, true))}
                    <button className="link-btn replies-btn" onClick={() => setOpen((o) => ({ ...o, [c.key]: false }))}>
                      {t('Скрыть')}
                    </button>
                  </>
                ) : (
                  <button className="link-btn replies-btn" onClick={() => setOpen((o) => ({ ...o, [c.key]: true }))}>
                    {t('Показать {n} ответов', { n: rs.length })}
                  </button>
                ))}
            </div>
          );
        })}
      </div>
      {allowed && !S.readOnly ? (
        <div className="comment-bar">
          {mentionList.length > 0 && (
            <div className="mention-list">
              {mentionList.map((u) => (
                <button key={u} className="mention-item" onClick={() => setText(text.replace(/@([a-z0-9_]*)$/i, '@' + S.u[u].un + ' '))}>
                  <Avatar uid={u} size={28} />
                  <span>{S.u[u].nm}</span>
                  <small className="muted">@{S.u[u].un}</small>
                </button>
              ))}
            </div>
          )}
          <div className="emoji-row">
            {EMOJI.map((e) => (
              <button key={e} onClick={() => setText(text + e)}>
                {e}
              </button>
            ))}
          </div>
          {replyTo && (
            <div className="reply-chip">
              {t('Ответ для @{u}', { u: S.u[replyTo.by]?.un || '' })}
              <button className="icon-btn" onClick={() => setReplyTo(null)}>
                <Icon n="close" size={14} />
              </button>
            </div>
          )}
          {img && (
            <div className="reply-chip">
              <img src={img.url} alt="" className="chip-img" />
              <button className="icon-btn" onClick={() => setImg(null)}>
                <Icon n="close" size={14} />
              </button>
            </div>
          )}
          <div className="comment-input">
            <Avatar uid={S.uid} size={32} />
            <input
              id="comment-input"
              className="input grow"
              placeholder={t('Добавить комментарий…')}
              value={text}
              maxLength={500}
              onChange={(e) => setText(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && void submit()}
            />
            {S.canUpload && (
              <FilePick
                id="comment-img"
                accept="image/*"
                className="icon-btn"
                onFiles={async ([f]) => {
                  try {
                    setBusy(true);
                    const prepared = f.type === 'image/gif' ? f : (await prepareImage(f, 1080)).blob;
                    setImg(await upload(prepared));
                  } catch (e) {
                    errToast(e);
                  } finally {
                    setBusy(false);
                  }
                }}
              >
                <Icon n="image" size={22} />
              </FilePick>
            )}
            <button className="icon-btn accent" disabled={busy || (!text.trim() && !img)} onClick={() => void submit()} aria-label={t('Отправить')}>
              {busy ? <Spinner size={18} /> : <Icon n="send" size={22} />}
            </button>
          </div>
        </div>
      ) : (
        <div className="comment-closed">{!post.cm ? t('Комментарии отключены') : S.readOnly ? t('Комментировать могут участники с правом записи') : t('Автор ограничил комментарии')}</div>
      )}
    </div>
  );
}
