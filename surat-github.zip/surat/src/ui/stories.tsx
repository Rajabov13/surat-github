import React, { useEffect, useRef, useState } from 'react';
import { deleteStory, recordStoryView } from '../core/actions';
import { agg, hasUnseenStory, storyUsers, storyViewers } from '../core/derive';
import { openDirect, send } from '../core/dm';
import { S, useStore } from '../core/store';
import { cx, pkey } from '../core/util';
import { t, timeAgo } from './i18n';
import { Icon } from './icons';
import { act, Avatar, errToast, MenuItem, UserRow } from './kit';
import { closeSheet, confirmDialog, go, popScreen, sheet, toast } from './nav';
import { msrc, resolveSound } from './player';
import { ReportSheet } from './share';

export function StoryBar(): React.ReactElement | null {
  useStore();
  const me = S.uid;
  const users = storyUsers();
  const A = agg();
  const mineHas = !!me && A.stories.has(me);
  if (!me && !users.length) return null;
  return (
    <div className="story-bar hscroll">
      {me && !S.readOnly && (
        <button className="story-item" onClick={() => (mineHas ? go('stories', { start: me, list: users }) : go('create', { story: true }))}>
          <span className="story-av-wrap">
            <Avatar uid={me} size={60} ring={mineHas} />
            {!mineHas && <span className="story-add">+</span>}
          </span>
          <small>{t('Ваша история')}</small>
        </button>
      )}
      {users
        .filter((u) => u !== me)
        .map((u) => (
          <button key={u} className={cx('story-item', !hasUnseenStory(u) && 'seen')} onClick={() => go('stories', { start: u, list: users.filter((x) => x !== me || mineHas) })}>
            <Avatar uid={u} size={60} ring />
            <small className="ell">{S.u[u]?.un}</small>
          </button>
        ))}
    </div>
  );
}

export function StoryViewer({ start, list, only }: { start: string; list?: string[]; only?: boolean }): React.ReactElement {
  useStore();
  const A = agg();
  const users = only ? [start] : (list || storyUsers()).filter((u) => A.stories.has(u));
  const [ui, setUi] = useState(Math.max(0, users.indexOf(start)));
  const uid = users[ui];
  const stories = (uid && A.stories.get(uid)) || [];
  const seenMap = (S.uid && S.v[S.uid]?.sv) || {};
  const firstUnseen = Math.max(0, stories.findIndex((s) => !seenMap[pkey(uid, s.id)]));
  const [si, setSi] = useState(firstUnseen);
  const [paused, setPaused] = useState(false);
  const [prog, setProg] = useState(0);
  const [reply, setReply] = useState('');
  const [dy, setDy] = useState(0);
  const vid = useRef<HTMLVideoElement | null>(null);
  const press = useRef<{ t: number; y: number; x: number } | null>(null);
  const st = stories[si];
  const dur = st?.t === 'video' ? st.dur || 15 : 6;
  const sound = resolveSound(st?.snd);
  const audioEl = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    if (!st || !uid) return;
    void recordStoryView(uid, st.id);
    setProg(0);
  }, [uid, st?.id]);
  useEffect(() => {
    if (!sound) return;
    const a = new Audio(sound.url);
    a.currentTime = sound.start;
    a.volume = sound.vol;
    audioEl.current = a;
    void a.play().catch(() => undefined);
    return () => {
      a.pause();
      audioEl.current = null;
    };
  }, [st?.id]);
  useEffect(() => {
    if (paused || reply) {
      vid.current?.pause();
      audioEl.current?.pause();
      return;
    }
    if (st?.t === 'video') void vid.current?.play().catch(() => undefined);
    void audioEl.current?.play().catch(() => undefined);
    const t0 = performance.now() - prog * dur * 1000;
    const id = setInterval(() => {
      const p = (performance.now() - t0) / (dur * 1000);
      if (p >= 1) next();
      else setProg(p);
    }, 60);
    return () => clearInterval(id);
  }, [paused, reply, si, ui, dur]);

  if (!uid || !st) {
    setTimeout(popScreen, 0);
    return <div className="screen story-view" />;
  }
  function next(): void {
    if (si + 1 < stories.length) setSi(si + 1);
    else if (ui + 1 < users.length) {
      setUi(ui + 1);
      setSi(0);
    } else popScreen();
    setProg(0);
  }
  function prev(): void {
    if (si > 0) setSi(si - 1);
    else if (ui > 0) {
      setUi(ui - 1);
      setSi(0);
    }
    setProg(0);
  }
  const mine = uid === S.uid;
  const sendReply = async (body: string, emoji?: boolean): Promise<void> => {
    try {
      const cid = await openDirect(uid);
      await send(cid, { k: 'story', t: body });
      toast(emoji ? t('Реакция отправлена') : t('Ответ отправлен'));
      setReply('');
    } catch (e) {
      errToast(e);
    }
  };
  const viewers = mine ? storyViewers(uid, st.id) : [];
  return (
    <div
      className="screen story-view"
      style={{ transform: dy ? `translateY(${dy}px)` : undefined, opacity: dy ? 1 - dy / 600 : 1 }}
      onPointerDown={(e) => {
        if ((e.target as HTMLElement).closest('button, input, .no-tap')) return;
        press.current = { t: performance.now(), y: e.clientY, x: e.clientX };
        setPaused(true);
      }}
      onPointerMove={(e) => press.current && setDy(Math.max(0, e.clientY - press.current.y))}
      onPointerUp={(e) => {
        const p = press.current;
        press.current = null;
        setPaused(false);
        if (!p) return;
        if (dy > 120) return popScreen();
        setDy(0);
        if (performance.now() - p.t < 250) {
          if (e.clientX < window.innerWidth * 0.33) prev();
          else next();
        }
      }}
    >
      <div className="story-bars">
        {stories.map((s, i) => (
          <span key={s.id}>
            <i style={{ transform: `scaleX(${i < si ? 1 : i === si ? prog : 0})` }} />
          </span>
        ))}
      </div>
      <div className="story-top">
        <Avatar uid={uid} size={34} onClick={() => (popScreen(), go('profile', { uid }))} />
        <b>{S.u[uid]?.un}</b>
        <small>{timeAgo(st.ts)}</small>
        <span className="grow" />
        <button
          className="icon-btn"
          onClick={() =>
            sheet(() => (
              <div>
                {mine ? (
                  <MenuItem icon="trash" danger label={t('Удалить историю')} onClick={async () => (closeSheet(), (await confirmDialog(t('Удалить историю?'), t('Удалить'))) && void act(() => deleteStory(st.id)))} />
                ) : (
                  <MenuItem icon="flag" label={t('Пожаловаться')} onClick={() => sheet(() => <ReportSheet k="story" id={pkey(uid, st.id)} />)} />
                )}
              </div>
            ))
          }
          aria-label={t('Ещё')}
        >
          <Icon n="more" />
        </button>
        <button className="icon-btn" onClick={popScreen} aria-label={t('Закрыть')}>
          <Icon n="close" />
        </button>
      </div>
      <div className="story-media">
        {st.t === 'video' && st.m ? (
          <video ref={vid} key={st.id} src={msrc(st.m)} playsInline autoPlay muted={!!sound} />
        ) : st.t === 'photo' && st.m ? (
          <img key={st.id} src={msrc(st.m)} alt="" />
        ) : (
          <div className="textpost" style={{ background: st.bg, color: st.c }}>
            <p className="tp-lg">{st.txt}</p>
          </div>
        )}
        {st.txt && st.t !== 'text' && <div className="story-caption">{st.txt}</div>}
      </div>
      {mine ? (
        <button className="story-viewers no-tap" onClick={() => (setPaused(true), sheet(() => <ViewersSheet uids={viewers} />))}>
          <Icon n="eye" size={18} /> {viewers.length} {t('просмотров')}
        </button>
      ) : (
        !S.readOnly && (
          <div className="story-reply no-tap">
            <input id="story-reply" className="input" placeholder={t('Ответить @{u}', { u: S.u[uid]?.un || '' })} value={reply} onChange={(e) => setReply(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && reply.trim() && void sendReply(reply.trim())} />
            {reply.trim() ? (
              <button className="icon-btn" onClick={() => void sendReply(reply.trim())} aria-label={t('Отправить')}>
                <Icon n="send" />
              </button>
            ) : (
              ['❤️', '😂', '🔥'].map((e) => (
                <button key={e} className="story-emoji" onClick={() => void sendReply(e, true)}>
                  {e}
                </button>
              ))
            )}
          </div>
        )
      )}
    </div>
  );
}

function ViewersSheet({ uids }: { uids: string[] }): React.ReactElement {
  return (
    <div>
      <b className="sheet-title pad-x">{t('Просмотрели')}</b>
      {uids.length === 0 && <p className="muted pad-x">{t('Пока никто')}</p>}
      {uids.map((u) => (
        <UserRow key={u} uid={u} />
      ))}
    </div>
  );
}
