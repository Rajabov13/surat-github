// Read-side model: aggregates, relationships, visibility, the "For you" ranking,
// notifications, search and analytics — all derived from the shared per-user documents.
import { S } from './store';
import type { Comment, Notif, NotifType, Post, Profile, Rec, Story, Track } from './types';
import { DAY, live, now, pkey, splitKey } from './util';

export interface PostX extends Post {
  key: string;
  likes: number;
  comments: number;
  saves: number;
  reposts: number;
  shares: number;
  views: number;
  watch: number;
  compl: number;
  soundKey: string | null;
}
export interface CommentX extends Comment {
  key: string;
  by: string;
  likes: number;
}
export interface SoundX {
  key: string;
  k: 'p' | 's';
  au: string;
  id: string;
  asset: string;
  start: number;
  dur: number;
  cover?: string;
  track?: Track;
  posts: string[];
  recent: number;
}
export interface TagX {
  tag: string;
  posts: string[];
  views: number;
  recent: number;
}

interface Agg {
  ver: number;
  posts: Map<string, PostX>;
  comments: Map<string, CommentX[]>; // post key -> comments
  commentByKey: Map<string, CommentX>;
  followers: Map<string, string[]>;
  following: Map<string, string[]>;
  requests: Map<string, string[]>;
  sounds: Map<string, SoundX>;
  tags: Map<string, TagX>;
  byName: Map<string, string>;
  stories: Map<string, Story[]>;
}

let cache: Agg | null = null;

export const banned = (uid: string): boolean => !!S.mod.bans?.[uid];
export const removed = (key: string): boolean => !!S.mod.removed?.[key];
export const profile = (uid: string | null | undefined): Profile | undefined => (uid ? S.u[uid] : undefined);
export const activeUser = (uid: string): boolean => !!S.u[uid] && !S.u[uid].del && !banned(uid);

export function soundKeyOf(p: Post): string | null {
  if (p.snd) return `${p.snd.k}:${p.snd.au}~${p.snd.id}`;
  if (p.t === 'video' && p.clips && p.clips.length && !p.duet) return `p:${p.by}~${p.id}`;
  return null;
}

export function agg(): Agg {
  if (cache && cache.ver === S.ver) return cache;
  const posts = new Map<string, PostX>();
  const t = now();
  const addPost = (p: Post): void => {
    if (!p || !p.id || !activeUser(p.by)) return;
    const key = pkey(p.by, p.id);
    if (removed(key)) return;
    posts.set(key, {
      ...p,
      key,
      likes: 0,
      comments: 0,
      saves: 0,
      reposts: 0,
      shares: 0,
      views: 0,
      watch: 0,
      compl: 0,
      soundKey: soundKeyOf(p),
    });
  };
  for (const uid in S.p) for (const [, p] of live(S.p[uid].posts)) addPost(p);
  if (S.uid) for (const [, p] of live(S.priv.posts)) addPost({ ...p, by: S.uid });

  const followers = new Map<string, string[]>();
  const following = new Map<string, string[]>();
  const requests = new Map<string, string[]>();
  for (const a in S.g) {
    if (!activeUser(a)) continue;
    const g = S.g[a];
    for (const [k] of live(g.lk)) {
      const p = posts.get(k);
      if (p) p.likes++;
    }
    for (const [k] of live(g.sv)) {
      const p = posts.get(k);
      if (p) p.saves++;
    }
    for (const [k] of live(g.rp)) {
      const p = posts.get(k);
      if (p) p.reposts++;
    }
    for (const [k, n] of live(g.sh)) {
      const p = posts.get(k);
      if (p) p.shares += n;
    }
    for (const [b] of live(g.fol)) {
      if (!activeUser(b) || b === a) continue;
      const st = followState(a, b);
      if (st === 'yes') {
        push(followers, b, a);
        push(following, a, b);
      } else if (st === 'requested') push(requests, b, a);
    }
  }

  const comments = new Map<string, CommentX[]>();
  const commentByKey = new Map<string, CommentX>();
  for (const by in S.c) {
    if (!activeUser(by)) continue;
    for (const [cid, c] of live(S.c[by].cm)) {
      if (c.del) continue;
      const key = pkey(by, cid);
      if (removed(key)) continue;
      const pk = pkey(c.pa, c.p);
      const post = posts.get(pk);
      if (!post || post.hc?.[key]) continue;
      const cx: CommentX = { ...c, key, by, likes: 0 };
      push(comments, pk, cx);
      commentByKey.set(key, cx);
      post.comments++;
    }
  }
  for (const a in S.g) {
    if (!activeUser(a)) continue;
    for (const [k] of live(S.g[a].cl)) {
      const c = commentByKey.get(k);
      if (c) c.likes++;
    }
  }
  for (const viewer in S.v) {
    for (const [k, v] of live(S.v[viewer].pv)) {
      const p = posts.get(k);
      if (!p) continue;
      p.views += v.n;
      p.watch += v.w;
      p.compl += v.c;
    }
  }

  const sounds = new Map<string, SoundX>();
  const tags = new Map<string, TagX>();
  for (const uid in S.p) {
    if (!activeUser(uid)) continue;
    for (const [, tr] of live(S.p[uid].tracks)) {
      const key = `s:${uid}~${tr.id}`;
      sounds.set(key, { key, k: 's', au: uid, id: tr.id, asset: tr.a, start: 0, dur: tr.d, cover: tr.cover, track: tr, posts: [], recent: 0 });
    }
  }
  for (const p of posts.values()) {
    if (p.priv !== 'all' || (p.at && p.at > t)) continue;
    if (p.soundKey) {
      let s = sounds.get(p.soundKey);
      if (!s && p.soundKey.startsWith('p:')) {
        const origin = posts.get(p.soundKey.slice(2));
        if (origin && origin.clips && origin.clips[0]) {
          s = {
            key: p.soundKey,
            k: 'p',
            au: origin.by,
            id: origin.id,
            asset: origin.clips[0].a,
            start: origin.clips[0].s,
            dur: origin.dur || origin.clips[0].e - origin.clips[0].s,
            cover: origin.poster,
            posts: [],
            recent: 0,
          };
          sounds.set(p.soundKey, s);
        }
      }
      if (s) {
        s.posts.push(p.key);
        if (t - p.ts < 7 * DAY) s.recent++;
      }
    }
    for (const tag of p.ht || []) {
      let x = tags.get(tag);
      if (!x) tags.set(tag, (x = { tag, posts: [], views: 0, recent: 0 }));
      x.posts.push(p.key);
      x.views += p.views;
      if (t - p.ts < 7 * DAY) x.recent += 1 + p.views / 50;
    }
  }

  const byName = new Map<string, string>();
  for (const uid in S.u) if (S.u[uid].un) byName.set(S.u[uid].un, uid);

  const stories = new Map<string, Story[]>();
  for (const uid in S.s) {
    if (!activeUser(uid)) continue;
    const list = live(S.s[uid].st)
      .map(([, s]) => s)
      .filter((s) => t - s.ts < DAY && !removed(pkey(uid, s.id)))
      .sort((a, b) => a.ts - b.ts);
    if (list.length) stories.set(uid, list);
  }

  cache = { ver: S.ver, posts, comments, commentByKey, followers, following, requests, sounds, tags, byName, stories };
  return cache;
}

function push<K, V>(m: Map<K, V[]>, k: K, v: V): void {
  const a = m.get(k);
  if (a) a.push(v);
  else m.set(k, [v]);
}

// ---------- relationships ----------
export function followState(a: string, b: string): 'yes' | 'requested' | 'no' {
  const t = S.g[a]?.fol?.[b];
  if (!t) return 'no';
  const gb = S.g[b];
  if (gb?.rmv?.[a] && gb.rmv[a] >= t) return 'no';
  if (S.u[b]?.priv && !(gb?.acc?.[a] && gb.acc[a] > 0)) return 'requested';
  return 'yes';
}
export const follows = (a: string | null, b: string): boolean => !!a && followState(a, b) === 'yes';
export const friends = (a: string | null, b: string): boolean => !!a && follows(a, b) && follows(b, a);
export function blockedEither(a: string | null, b: string): boolean {
  if (!a) return false;
  return !!(S.g[a]?.blk?.[b] || S.g[b]?.blk?.[a]);
}
export const iBlocked = (b: string): boolean => !!(S.uid && S.g[S.uid]?.blk?.[b]);
export function audienceOk(aud: 'all' | 'friends' | 'none' | undefined, owner: string): boolean {
  const me = S.uid;
  if (!me) return false;
  if (me === owner) return true;
  if (!aud || aud === 'all') return true;
  if (aud === 'friends') return friends(me, owner);
  return false;
}

export function canSeeProfileContent(uid: string): boolean {
  const me = S.uid;
  if (me === uid) return true;
  if (blockedEither(me, uid)) return false;
  if (S.u[uid]?.priv) return follows(me, uid);
  return true;
}

export function canSee(p: Post): boolean {
  const me = S.uid;
  if (me && p.by === me) return true;
  if (!activeUser(p.by)) return false;
  if (blockedEither(me, p.by)) return false;
  if (p.at && p.at > now()) return false;
  if (p.priv === 'me') return false;
  if (p.priv === 'friends' && !friends(me, p.by)) return false;
  if (S.u[p.by]?.priv && !follows(me, p.by)) return false;
  return true;
}

function kwBlocked(p: Post): boolean {
  const kw = S.me.set?.kw;
  if (!kw || !kw.length) return false;
  const text = (p.cap + ' ' + (p.ht || []).join(' ')).toLowerCase();
  return kw.some((w) => w && text.includes(w.toLowerCase()));
}

export const getPost = (key: string): PostX | undefined => agg().posts.get(key);
export const uidByName = (un: string): string | undefined => agg().byName.get(un.toLowerCase());

// ---------- interests & ranking ----------
export function interestProfile(): Rec<number> {
  const w: Rec<number> = {};
  const me = S.uid;
  if (!me) return w;
  const A = agg();
  const add = (p: Post | undefined, x: number): void => {
    if (!p) return;
    const tags = p.ht || [];
    for (const t of tags) w['h:' + t] = (w['h:' + t] || 0) + x / Math.sqrt(tags.length || 1);
    const sk = soundKeyOf(p);
    if (sk) w['s:' + sk] = (w['s:' + sk] || 0) + x * 0.6;
    w['a:' + p.by] = (w['a:' + p.by] || 0) + x * 0.8;
  };
  for (const [tag, x] of live(S.me.int)) w['h:' + tag] = (w['h:' + tag] || 0) + 2 * x;
  for (const [k, v] of live(S.v[me]?.pv)) {
    const p = A.posts.get(k);
    if (!p || p.by === me) continue;
    const dur = Math.max(1, p.dur || 8);
    const ratio = Math.min(1.5, v.w / 1000 / v.n / dur);
    let x = (ratio - 0.35) * 2 + Math.min(3, v.n - 1) * 0.35 + v.c * 0.2;
    if (v.w / v.n < 1500 && dur > 4) x -= 0.6;
    add(p, x);
  }
  const g = S.g[me] || {};
  for (const [k] of live(g.lk)) add(A.posts.get(k), 1.5);
  for (const [k] of live(g.sv)) add(A.posts.get(k), 2);
  for (const [k] of live(g.rp)) add(A.posts.get(k), 2);
  for (const [k] of live(g.sh)) add(A.posts.get(k), 1.5);
  for (const [b] of live(g.fol)) w['a:' + b] = (w['a:' + b] || 0) + 3;
  for (const [, c] of live(S.c[me]?.cm)) add(A.posts.get(pkey(c.pa, c.p)), 2);
  for (const [k] of live(S.me.ni)) add(A.posts.get(k), -4);
  for (const [a] of live(S.me.nia)) w['a:' + a] = (w['a:' + a] || 0) - 8;
  return w;
}

function interestScore(p: PostX, w: Rec<number>): number {
  let s = 0;
  const tags = p.ht || [];
  for (const t of tags) s += w['h:' + t] || 0;
  if (tags.length) s /= Math.sqrt(tags.length);
  if (p.soundKey) s += w['s:' + p.soundKey] || 0;
  s += (w['a:' + p.by] || 0) * 1.2;
  return s;
}
export function popularity(p: PostX): number {
  const eng = (p.likes + 2 * p.comments + 3 * p.reposts + 2 * p.saves + p.shares) / (p.views + 5);
  const age = (now() - (p.at || p.ts)) / DAY;
  const avgRatio = p.views ? Math.min(1.2, p.watch / 1000 / p.views / Math.max(1, p.dur || 8)) : 0.4;
  return (eng * 3 + Math.log10(p.views + 1) * 0.5 + avgRatio) / (1 + age / 7);
}

export function forYou(seed: number): string[] {
  const me = S.uid;
  const A = agg();
  const viewed = (me && S.v[me]?.pv) || {};
  const ni = S.me.ni || {};
  const nia = S.me.nia || {};
  const all = [...A.posts.values()].filter(
    (p) => p.by !== me && p.priv === 'all' && canSee(p) && !ni[p.key] && !nia[p.by] && !kwBlocked(p),
  );
  const fresh = all.filter((p) => !viewed[p.key]);
  const seen = all.filter((p) => viewed[p.key]);
  const w = interestProfile();
  const hasProfile = Object.keys(w).length > 0;
  let rnd = seed || 7;
  const rand = (): number => {
    rnd = (rnd * 16807) % 2147483647;
    return rnd / 2147483647;
  };
  const jitter = new Map(all.map((p) => [p.key, rand() * 0.15]));
  const byInterest = fresh
    .slice()
    .sort((a, b) => interestScore(b, w) + popularity(b) * 0.3 + jitter.get(b.key)! - (interestScore(a, w) + popularity(a) * 0.3 + jitter.get(a.key)!));
  const byPop = fresh.slice().sort((a, b) => popularity(b) + jitter.get(b.key)! - (popularity(a) + jitter.get(a.key)!));
  const byNew = fresh
    .filter((p) => now() - (p.at || p.ts) < 3 * DAY && p.views < 80)
    .sort((a, b) => (b.at || b.ts) - (a.at || a.ts));
  const used = new Set<string>();
  const out: PostX[] = [];
  const pickFrom = (list: PostX[]): PostX | null => {
    const last2 = out.slice(-2);
    const sameTwice = last2.length === 2 && last2[0].by === last2[1].by ? last2[0].by : null;
    for (const p of list) {
      if (used.has(p.key)) continue;
      if (sameTwice && p.by === sameTwice) continue;
      return p;
    }
    return null;
  };
  while (out.length < fresh.length) {
    const r = rand();
    const order = !hasProfile
      ? [byPop, byNew, byInterest]
      : r < 0.7
        ? [byInterest, byPop, byNew]
        : r < 0.9
          ? [byPop, byInterest, byNew]
          : [byNew, byInterest, byPop];
    let p: PostX | null = null;
    for (const l of order) if ((p = pickFrom(l))) break;
    if (!p) p = fresh.find((x) => !used.has(x.key)) || null;
    if (!p) break;
    used.add(p.key);
    out.push(p);
  }
  // Already-watched videos come last, best first, so the feed never runs dry.
  seen.sort((a, b) => interestScore(b, w) + popularity(b) - (interestScore(a, w) + popularity(a)));
  return [...out, ...seen].map((p) => p.key);
}

export function followingFeed(): string[] {
  const me = S.uid;
  if (!me) return [];
  const A = agg();
  const fol = new Set(A.following.get(me) || []);
  return [...A.posts.values()]
    .filter((p) => fol.has(p.by) && canSee(p) && !kwBlocked(p))
    .sort((a, b) => (b.at || b.ts) - (a.at || a.ts))
    .map((p) => p.key);
}

export interface FriendItem {
  key: string;
  via?: string; // reposted by
}
export function friendsFeed(): FriendItem[] {
  const me = S.uid;
  if (!me) return [];
  const A = agg();
  const fr = (A.following.get(me) || []).filter((b) => follows(b, me));
  const frSet = new Set(fr);
  const items: (FriendItem & { ts: number })[] = [];
  for (const p of A.posts.values()) if (frSet.has(p.by) && canSee(p)) items.push({ key: p.key, ts: p.at || p.ts });
  const seen = new Set(items.map((i) => i.key));
  for (const f of fr)
    for (const [k, ts] of live(S.g[f]?.rp)) {
      const p = A.posts.get(k);
      if (p && !seen.has(k) && canSee(p) && p.by !== me) {
        seen.add(k);
        items.push({ key: k, via: f, ts });
      }
    }
  return items.sort((a, b) => b.ts - a.ts);
}

export function friendsOf(uid: string): string[] {
  const A = agg();
  return (A.following.get(uid) || []).filter((b) => follows(b, uid));
}

export function profilePosts(uid: string): string[] {
  const A = agg();
  const pins = S.u[uid]?.pins || [];
  const list = [...A.posts.values()].filter((p) => p.by === uid && canSee(p) && (uid === S.uid || !(p.at && p.at > now())));
  list.sort((a, b) => {
    const pa = pins.indexOf(a.id);
    const pb = pins.indexOf(b.id);
    if (pa >= 0 || pb >= 0) return (pa < 0 ? 99 : pa) - (pb < 0 ? 99 : pb);
    return (b.at || b.ts) - (a.at || a.ts);
  });
  return list.map((p) => p.key);
}
export function userKeys(uid: string, field: 'lk' | 'sv' | 'rp'): string[] {
  const A = agg();
  return live(S.g[uid]?.[field])
    .sort((a, b) => b[1] - a[1])
    .map(([k]) => k)
    .filter((k) => {
      const p = A.posts.get(k);
      return p && canSee(p);
    });
}

// ---------- comments ----------
export function commentsFor(postKey: string): CommentX[] {
  const list = agg().comments.get(postKey) || [];
  const post = getPost(postKey);
  const sw = (post && S.u[post.by]?.sw) || [];
  const me = S.uid;
  return list.filter((c) => {
    if (blockedEither(me, c.by)) return false;
    if (c.by !== me && sw.length) {
      const t = c.t.toLowerCase();
      if (sw.some((w) => w && t.includes(w.toLowerCase()))) return false;
    }
    return true;
  });
}

// ---------- suggestions ----------
export function suggestions(limit = 12): string[] {
  const me = S.uid;
  if (!me) return [];
  const A = agg();
  const myFol = new Set(A.following.get(me) || []);
  const w = interestProfile();
  const score = new Map<string, number>();
  for (const f of myFol) for (const x of A.following.get(f) || []) score.set(x, (score.get(x) || 0) + 3);
  for (const x of A.followers.get(me) || []) score.set(x, (score.get(x) || 0) + 6);
  for (const p of A.posts.values()) {
    if (p.priv !== 'all') continue;
    let s = 0;
    for (const t of p.ht || []) s += Math.max(0, w['h:' + t] || 0);
    if (s) score.set(p.by, (score.get(p.by) || 0) + Math.min(4, s * 0.3));
  }
  for (const uid in S.u) {
    if (!activeUser(uid)) continue;
    score.set(uid, (score.get(uid) || 0) + Math.log10(1 + (A.followers.get(uid) || []).length) + 0.01);
  }
  return [...score.entries()]
    .filter(([u]) => u !== me && !myFol.has(u) && followState(me, u) !== 'requested' && !blockedEither(me, u) && activeUser(u))
    .sort((a, b) => b[1] - a[1])
    .slice(0, limit)
    .map(([u]) => u);
}

// ---------- notifications ----------
export function notifications(): Notif[] {
  const me = S.uid;
  if (!me) return [];
  const A = agg();
  const out: Notif[] = [];
  const myUn = S.u[me]?.un;
  const mine = (k: string): boolean => splitKey(k)[0] === me && A.posts.has(k);
  for (const a in S.g) {
    if (a === me || !activeUser(a) || blockedEither(me, a)) continue;
    const g = S.g[a];
    for (const [k, ts] of live(g.lk)) if (mine(k)) out.push({ type: 'like', by: a, ts, post: k });
    for (const [k, ts] of live(g.rp)) if (mine(k)) out.push({ type: 'repost', by: a, ts, post: k });
    for (const [k, ts] of live(g.cl)) {
      const c = A.commentByKey.get(k);
      if (c && c.by === me) out.push({ type: 'clike', by: a, ts, post: pkey(c.pa, c.p), ckey: k, text: c.t });
    }
    const fts = g.fol?.[me];
    if (fts) {
      const st = followState(a, me);
      if (st === 'yes') out.push({ type: 'follow', by: a, ts: fts });
      else if (st === 'requested') out.push({ type: 'request', by: a, ts: fts });
    }
  }
  for (const c of A.commentByKey.values()) {
    if (c.by === me || blockedEither(me, c.by)) continue;
    const pk = pkey(c.pa, c.p);
    const parent = c.r ? A.commentByKey.get(c.r) : undefined;
    if (parent && parent.by === me) out.push({ type: 'reply', by: c.by, ts: c.ts, post: pk, text: c.t, ckey: c.key });
    else if (c.pa === me) out.push({ type: 'comment', by: c.by, ts: c.ts, post: pk, text: c.t, ckey: c.key });
    else if (myUn && c.t.toLowerCase().includes('@' + myUn)) out.push({ type: 'mention', by: c.by, ts: c.ts, post: pk, text: c.t, ckey: c.key });
  }
  for (const p of A.posts.values()) {
    if (p.by === me || !canSee(p)) continue;
    const ts = p.at || p.ts;
    if (p.duet?.au === me) out.push({ type: 'duet', by: p.by, ts, post: p.key });
    else if (p.stitch?.au === me) out.push({ type: 'stitch', by: p.by, ts, post: p.key });
    if (p.tags?.includes(me)) out.push({ type: 'tag', by: p.by, ts, post: p.key });
    else if (myUn && p.cap.toLowerCase().includes('@' + myUn)) out.push({ type: 'mention', by: p.by, ts, post: p.key, text: p.cap });
  }
  const off = S.me.set?.nt || {};
  return out.filter((n) => off[n.type] !== false && n.ts <= now() + 60000).sort((a, b) => b.ts - a.ts);
}

export interface NotifGroup {
  type: NotifType;
  post?: string;
  items: Notif[];
  ts: number;
}
export function groupNotifs(list: Notif[]): NotifGroup[] {
  const groups: NotifGroup[] = [];
  const idx = new Map<string, NotifGroup>();
  for (const n of list) {
    const groupable = n.type === 'like' || n.type === 'repost' || n.type === 'follow' || n.type === 'clike';
    const day = Math.floor(n.ts / DAY);
    const k = groupable ? `${n.type}|${n.post || ''}|${n.ckey || ''}|${day}` : `${n.type}|${n.by}|${n.ts}|${n.ckey || n.post}`;
    const g = idx.get(k);
    if (g) g.items.push(n);
    else {
      const ng: NotifGroup = { type: n.type, post: n.post, items: [n], ts: n.ts };
      idx.set(k, ng);
      groups.push(ng);
    }
  }
  return groups;
}
export function unreadNotifs(): number {
  const seen = S.me.ns || 0;
  return notifications().filter((n) => n.ts > seen).length;
}

// ---------- search ----------
function scoreText(hay: string, q: string): number {
  const h = hay.toLowerCase();
  if (!q) return 0;
  if (h === q) return 10;
  if (h.startsWith(q)) return 6;
  const i = h.indexOf(q);
  if (i >= 0) return 3 - Math.min(2, i / 40);
  // loose subsequence match
  let j = 0;
  for (const ch of h) if (ch === q[j]) j++;
  return j === q.length ? 0.5 : 0;
}
export function searchUsers(q: string, limit = 30): string[] {
  const s = q.trim().toLowerCase().replace(/^@/, '');
  const A = agg();
  return Object.keys(S.u)
    .filter((u) => activeUser(u) && !blockedEither(S.uid, u))
    .map((u) => [u, Math.max(scoreText(S.u[u].un, s), scoreText(S.u[u].nm || '', s)) + (s ? 0 : Math.log10(1 + (A.followers.get(u) || []).length))] as const)
    .filter(([, sc]) => !s || sc > 0)
    .sort((a, b) => b[1] - a[1])
    .slice(0, limit)
    .map(([u]) => u);
}
export function searchPosts(q: string, limit = 60): string[] {
  const s = q.trim().toLowerCase();
  if (!s) return [];
  return [...agg().posts.values()]
    .filter((p) => p.priv === 'all' && canSee(p))
    .map((p) => [p, scoreText(p.cap, s) + (p.ht || []).reduce((m, t) => Math.max(m, scoreText(t, s.replace(/^#/, ''))), 0)] as const)
    .filter(([, sc]) => sc > 0)
    .sort((a, b) => b[1] + popularity(b[0]) - (a[1] + popularity(a[0])))
    .slice(0, limit)
    .map(([p]) => p.key);
}
export function searchTags(q: string, limit = 30): TagX[] {
  const s = q.trim().toLowerCase().replace(/^#/, '');
  return [...agg().tags.values()]
    .filter((t) => !s || scoreText(t.tag, s) > 0)
    .sort((a, b) => (s ? scoreText(b.tag, s) - scoreText(a.tag, s) : 0) || b.views + b.posts.length * 10 - (a.views + a.posts.length * 10))
    .slice(0, limit);
}
export function soundName(s: SoundX, origLabel: string): string {
  if (s.track) return s.track.n;
  return `${origLabel} — @${S.u[s.au]?.un || '…'}`;
}
export function searchSounds(q: string, origLabel: string, limit = 30): SoundX[] {
  const s = q.trim().toLowerCase();
  return [...agg().sounds.values()]
    .filter((x) => activeUser(x.au) && (!s || scoreText(soundName(x, origLabel), s) > 0 || scoreText(S.u[x.au]?.un || '', s) > 0))
    .sort((a, b) => b.recent * 3 + b.posts.length - (a.recent * 3 + a.posts.length))
    .slice(0, limit);
}
export function trendingTags(limit = 10): TagX[] {
  const A = agg();
  const pinned = (S.mod.trends || []).map((t) => A.tags.get(t) || { tag: t, posts: [], views: 0, recent: 0 });
  const rest = [...A.tags.values()].filter((t) => !(S.mod.trends || []).includes(t.tag)).sort((a, b) => b.recent - a.recent || b.views - a.views);
  return [...pinned, ...rest].slice(0, limit);
}

// ---------- stories ----------
export function storyUsers(): string[] {
  const me = S.uid;
  const A = agg();
  const fol = new Set(me ? A.following.get(me) || [] : []);
  const seenMap = (me && S.v[me]?.sv) || {};
  const list = [...A.stories.keys()].filter((u) => u === me || (fol.has(u) && canSeeProfileContent(u)));
  const unseen = (u: string): boolean => (A.stories.get(u) || []).some((s) => !seenMap[pkey(u, s.id)]);
  return list.sort((a, b) => (a === me ? -1 : b === me ? 1 : Number(unseen(b)) - Number(unseen(a))));
}
export function hasUnseenStory(uid: string): boolean {
  const list = agg().stories.get(uid);
  if (!list || !canSeeProfileContent(uid)) return false;
  const seenMap = (S.uid && S.v[S.uid]?.sv) || {};
  return list.some((s) => !seenMap[pkey(uid, s.id)]);
}
export function storyViewers(uid: string, sid: string): string[] {
  const k = pkey(uid, sid);
  return Object.keys(S.v).filter((v) => v !== uid && S.v[v]?.sv?.[k]);
}

// ---------- analytics ----------
export interface Overview {
  days: number[];
  views: number[];
  likes: number[];
  comments: number[];
  reposts: number[];
  followers: number[];
  profileViews: number[];
  totals: Rec<number>;
}
export function overview(uid: string, nDays: number): Overview {
  const A = agg();
  const start = Math.floor((now() - (nDays - 1) * DAY) / DAY) * DAY;
  const idx = (ts: number): number => Math.floor((ts - start) / DAY);
  const mk = (): number[] => new Array(nDays).fill(0);
  const o: Overview = { days: mk().map((_, i) => start + i * DAY), views: mk(), likes: mk(), comments: mk(), reposts: mk(), followers: mk(), profileViews: mk(), totals: {} };
  const inc = (arr: number[], ts: number, n = 1): void => {
    const i = idx(ts);
    if (i >= 0 && i < nDays) arr[i] += n;
  };
  const myPosts = new Set([...A.posts.values()].filter((p) => p.by === uid).map((p) => p.key));
  for (const v in S.v) {
    for (const [k, x] of live(S.v[v].pv)) if (myPosts.has(k)) inc(o.views, x.l, x.n);
    const pv = S.v[v].prof?.[uid];
    if (pv && v !== uid) inc(o.profileViews, pv);
  }
  for (const a in S.g) {
    if (a === uid) continue;
    for (const [k, ts] of live(S.g[a].lk)) if (myPosts.has(k)) inc(o.likes, ts);
    for (const [k, ts] of live(S.g[a].rp)) if (myPosts.has(k)) inc(o.reposts, ts);
  }
  for (const k of myPosts) for (const c of A.comments.get(k) || []) if (c.by !== uid) inc(o.comments, c.ts);
  for (const f of A.followers.get(uid) || []) inc(o.followers, S.g[f]?.fol?.[uid] || 0);
  for (const key of ['views', 'likes', 'comments', 'reposts', 'followers', 'profileViews'] as const) o.totals[key] = o[key].reduce((a, b) => a + b, 0);
  return o;
}
export interface PostStats {
  views: number;
  avgWatch: number;
  completion: number;
  retention: number[];
  sources: Rec<number>;
  hours: number[];
  langs: Rec<number>;
}
export function postStats(key: string): PostStats {
  const p = getPost(key);
  const dur = Math.max(1, Math.ceil(p?.dur || 1));
  const maxes: number[] = [];
  const sources: Rec<number> = {};
  const hours = new Array(24).fill(0);
  const langs: Rec<number> = {};
  for (const v in S.v) {
    const x = S.v[v].pv?.[key];
    if (!x || !x.n) continue;
    for (const m of x.m || []) maxes.push(m);
    sources[x.s || 'fy'] = (sources[x.s || 'fy'] || 0) + x.n;
    hours[new Date(x.l).getHours()] += 1;
    const lang = (S.u[v]?.lang || '?').slice(0, 2);
    langs[lang] = (langs[lang] || 0) + 1;
  }
  const retention: number[] = [];
  for (let s = 0; s <= Math.min(dur, 600); s++) retention.push(maxes.length ? maxes.filter((m) => m >= s).length / maxes.length : 0);
  return {
    views: p?.views || 0,
    avgWatch: p && p.views ? p.watch / 1000 / p.views : 0,
    completion: p && p.views ? Math.min(1, p.compl / p.views) : 0,
    retention,
    sources,
    hours,
    langs,
  };
}
export function audience(uid: string): { hours: number[]; langs: Rec<number>; total: number } {
  const hours = new Array(24).fill(0);
  const langs: Rec<number> = {};
  const fol = agg().followers.get(uid) || [];
  for (const f of fol) {
    const lang = (S.u[f]?.lang || '?').slice(0, 2);
    langs[lang] = (langs[lang] || 0) + 1;
    for (const [, x] of live(S.v[f]?.pv)) hours[new Date(x.l).getHours()] += 1;
  }
  return { hours, langs, total: fol.length };
}
