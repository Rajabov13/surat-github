import type { Rec } from './types';

const ALPH = 'abcdefghijkmnopqrstuvwxyz23456789';
export function rid(n = 12): string {
  const a = crypto.getRandomValues(new Uint8Array(n));
  let s = '';
  for (const b of a) s += ALPH[b % ALPH.length];
  return s;
}
export const now = (): number => Date.now();
export const DAY = 86400000;

export const pkey = (by: string, id: string): string => `${by}~${id}`;
export function splitKey(k: string): [string, string] {
  const i = k.indexOf('~');
  return [k.slice(0, i), k.slice(i + 1)];
}
export const blob = (id?: string | null): string => (id ? '/_blob/' + id : '');

function trimNum(x: number): string {
  if (x >= 100) return String(Math.floor(x));
  return String(Math.floor(x * 10) / 10);
}
export function fmtCount(n: number): string {
  if (!isFinite(n) || n < 0) return '0';
  if (n < 1000) return String(Math.round(n));
  if (n < 1e6) return trimNum(n / 1e3) + 'K';
  if (n < 1e9) return trimNum(n / 1e6) + 'M';
  return trimNum(n / 1e9) + 'B';
}
export function fmtDur(sec: number): string {
  const s = Math.max(0, Math.round(sec));
  const m = Math.floor(s / 60);
  return `${m}:${String(s % 60).padStart(2, '0')}`;
}

export const TAG_RE = /#([\p{L}\p{N}_]{1,40})/gu;
export const MENTION_RE = /@([a-z0-9_]{2,24})/gi;
export function parseTags(text: string): string[] {
  const out = new Set<string>();
  for (const m of text.matchAll(TAG_RE)) out.add(m[1].toLowerCase());
  return [...out].slice(0, 30);
}
export function parseMentions(text: string): string[] {
  const out = new Set<string>();
  for (const m of text.matchAll(MENTION_RE)) out.add(m[1].toLowerCase());
  return [...out];
}

/** Entries of a map whose value is truthy (0 marks a removed entry). */
export function live<T>(r: Rec<T> | undefined): [string, T][] {
  if (!r) return [];
  const out: [string, T][] = [];
  for (const k in r) if (r[k]) out.push([k, r[k]]);
  return out;
}
export function has(r: Rec<unknown> | undefined, k: string): boolean {
  return !!(r && r[k]);
}

export function clamp(x: number, a: number, b: number): number {
  return Math.min(b, Math.max(a, x));
}

export function haptic(ms = 12): void {
  try {
    if (navigator.vibrate) navigator.vibrate(ms);
  } catch {
    /* not supported */
  }
}

export function lsGet<T>(key: string, def: T): T {
  try {
    const v = localStorage.getItem(key);
    return v ? (JSON.parse(v) as T) : def;
  } catch {
    return def;
  }
}
export function lsSet(key: string, v: unknown): void {
  try {
    localStorage.setItem(key, JSON.stringify(v));
  } catch {
    /* storage blocked */
  }
}

export function cx(...a: (string | false | null | undefined)[]): string {
  return a.filter(Boolean).join(' ');
}

export function b64(buf: ArrayBuffer | Uint8Array): string {
  const u = buf instanceof Uint8Array ? buf : new Uint8Array(buf);
  let s = '';
  for (let i = 0; i < u.length; i += 0x8000) s += String.fromCharCode(...u.subarray(i, i + 0x8000));
  return btoa(s);
}
export function unb64(s: string): Uint8Array<ArrayBuffer> {
  const bin = atob(s);
  const u = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
  return u;
}

export async function sha(s: string): Promise<string> {
  const d = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(s));
  return Array.from(new Uint8Array(d).slice(0, 12), (b) => b.toString(16).padStart(2, '0')).join('');
}

export function errMsg(e: unknown): string {
  if (e && typeof e === 'object') {
    const o = e as { code?: string; message?: string };
    if (o.code === 'quota_exceeded') return 'quota';
    if (o.code === 'resource_exhausted' || o.code === 'rate_limited') return 'rate';
    if (o.code === 'invalid_argument') return 'denied';
    if (o.code === 'too_large') return 'too_large';
    if (o.code === 'unsupported_type') return 'bad_type';
    return o.code || o.message || 'error';
  }
  return String(e);
}

export const sleep = (ms: number): Promise<void> => new Promise((r) => setTimeout(r, ms));

/** Simple client-side rate limiter: max `n` actions per `win` ms per bucket. */
const buckets: Rec<number[]> = {};
export function allow(bucket: string, n: number, win: number): boolean {
  const t = now();
  const arr = (buckets[bucket] = (buckets[bucket] || []).filter((x) => t - x < win));
  if (arr.length >= n) return false;
  arr.push(t);
  return true;
}

export function shuffleSeeded<T>(arr: T[], seed: number): T[] {
  const a = arr.slice();
  let s = seed || 1;
  for (let i = a.length - 1; i > 0; i--) {
    s = (s * 16807) % 2147483647;
    const j = s % (i + 1);
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

export function normalizeUsername(s: string): string {
  return s
    .toLowerCase()
    .replace(/[^a-z0-9_]/g, '')
    .slice(0, 24);
}
export const unToHash = (un: string): string => un.replace(/_/g, '-');
export const hashToUn = (h: string): string => h.replace(/-/g, '_');
