// Tiny navigation store: a stack of full-screen layers over the tab view, plus one sheet at a time.
import type React from 'react';
import { bump } from '../core/store';

export interface Screen {
  id: number;
  name: string;
  props: Record<string, unknown>;
}
export interface SheetSpec {
  id: number;
  render: () => React.ReactNode;
  tall?: boolean;
}

let seq = 1;
export const nav = {
  tab: 'home',
  stack: [] as Screen[],
  sheets: [] as SheetSpec[],
  toasts: [] as { id: number; text: string; act?: { label: string; fn: () => void } }[],
  dialog: null as null | { title: string; text?: string; ok: string; danger?: boolean; resolve: (v: boolean) => void },
};

export function go(name: string, props: Record<string, unknown> = {}): void {
  nav.stack.push({ id: seq++, name, props });
  bump();
}
export function back(): void {
  if (nav.sheets.length) nav.sheets.pop();
  else nav.stack.pop();
  bump();
}
export function popScreen(): void {
  nav.stack.pop();
  bump();
}
export function setTab(tab: string): void {
  nav.tab = tab;
  nav.stack = [];
  nav.sheets = [];
  bump();
}
export function sheet(render: () => React.ReactNode, tall = false): void {
  nav.sheets.push({ id: seq++, render, tall });
  bump();
}
export function closeSheet(): void {
  nav.sheets.pop();
  bump();
}
export function closeAllSheets(): void {
  nav.sheets = [];
  bump();
}
export function toast(text: string, act?: { label: string; fn: () => void }): void {
  const id = seq++;
  nav.toasts.push({ id, text, act });
  bump();
  setTimeout(() => {
    nav.toasts = nav.toasts.filter((x) => x.id !== id);
    bump();
  }, act ? 5000 : 2600);
}
export function confirmDialog(title: string, ok: string, text?: string, danger = true): Promise<boolean> {
  return new Promise((resolve) => {
    nav.dialog = { title, text, ok, danger, resolve };
    bump();
  });
}
export function answerDialog(v: boolean): void {
  const d = nav.dialog;
  nav.dialog = null;
  bump();
  d?.resolve(v);
}
