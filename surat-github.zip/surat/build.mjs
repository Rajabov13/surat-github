// Bundles src/surat into one self-contained page: dist/surat.html
import { build } from 'esbuild';
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';

const r = await build({
  entryPoints: ['src/surat/main.tsx'],
  bundle: true,
  write: false,
  format: 'iife',
  target: 'es2020',
  minify: true,
  jsxFactory: 'React.createElement',
  jsxFragment: 'React.Fragment',
  legalComments: 'none',
  logLevel: 'warning',
  alias: { react: './src/shim/react.ts', 'react-dom/client': './src/shim/react-dom.ts', 'react-dom': './src/shim/react-dom.ts' },
});
const js = r.outputFiles[0].text.replace(/<\/script/gi, '<\\/script');
const css = readFileSync('src/ui/base.css', 'utf8') + '\n' + readFileSync('src/surat/app.css', 'utf8');
const html = readFileSync('src/surat/index.html', 'utf8')
  .replace('/*CSS*/', () => css)
  .replace('/*JS*/', () => js);
mkdirSync('dist', { recursive: true });
writeFileSync('dist/surat.html', html);
console.log(`dist/surat.html ${(html.length / 1024).toFixed(0)} KB`);
