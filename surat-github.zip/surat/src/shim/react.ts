// React is loaded from cdnjs as a UMD global; this shim lets the bundle import it.
const R = (window as unknown as { React: typeof import('react') }).React;
export default R;
export const { useState, useEffect, useRef, useMemo, useCallback, useLayoutEffect, useReducer, useContext, createContext, Fragment, memo, forwardRef } = R;
