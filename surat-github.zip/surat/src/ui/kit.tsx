import React, { useEffect, useRef, useState } from 'react';
import { follow, AppError } from '../core/actions';
import { canSeeProfileContent, followState, follows, hasUnseenStory, profile, uidByName } from '../core/derive';
import { S, useStore } from '../core/store';
import { blob, cx, errMsg, TAG_RE } from '../core/util';
import { t } from './i18n';
import { Icon } from './icons';
import { answerDialog, back, closeSheet, go, nav, toast } from './nav';

export function errToast(e: unknown): void {
  const code = e instanceof AppError ? e.code : errMsg(e);
  const map: Record<string, string> = {
    readonly: t('Только просмотр: у вас нет прав на запись в этом приложении'),
    rate: t('Слишком часто. Подождите немного и попробуйте снова'),
    quota: t('Хранилище заполнено. Удалите старые публикации'),
    denied: t('Действие недоступно'),
    taken: t('Этот ник уже занят'),
    bad_un: t('Ник: 3–24 символа, латиница, цифры и _'),
    un_wait: t('Ник можно менять раз в 30 дней'),
    age: t('Регистрация доступна с 13 лет'),
    too_large: t('Файл больше 20 МБ'),
    bad_type: t('Этот формат не поддерживается'),
    pins: t('Можно закрепить не больше 3 постов'),
    dm_closed: t('Пользователь ограничил личные сообщения'),
    nokeys: t('Ключ шифрования ещё не готов, попробуйте через минуту'),
    nokeys_other: t('Собеседник ещё не настроил сообщения'),
    group_small: t('В группе должно быть минимум 3 человека'),
    empty: t('Пустое сообщение'),
    not_granted: t('Загрузка файлов недоступна для вашего уровня доступа'),
  };
  toast(map[code] || t('Ошибка: {e}', { e: code }));
}

export async function act(fn: () => Promise<unknown>, ok?: string): Promise<boolean> {
  try {
    await fn();
    if (ok) toast(ok);
    return true;
  } catch (e) {
    errToast(e);
    return false;
  }
}

export function Avatar({ uid, size = 40, ring, onClick }: { uid: string | null | undefined; size?: number; ring?: boolean; onClick?: () => void }): React.ReactElement {
  const p = profile(uid);
  const showRing = ring && uid ? hasUnseenStory(uid) : false;
  const letter = (p?.nm || p?.un || '?').slice(0, 1).toUpperCase();
  const style = { width: size, height: size, fontSize: size * 0.42 };
  const inner = p?.av ? (
    p.avv ? (
      <video className="av-img" src={blob(p.av)} muted autoPlay loop playsInline />
    ) : (
      <img className="av-img" src={blob(p.av)} alt="" loading="lazy" />
    )
  ) : (
    <span className="av-letter" style={{ background: hue(uid || '') }}>
      {letter}
    </span>
  );
  return (
    <span className={cx('av', showRing && 'av-ring', onClick && 'tap')} style={style} onClick={onClick}>
      {inner}
    </span>
  );
}
export function hue(s: string): string {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) % 360;
  return `hsl(${h} 55% 45%)`;
}

export function Spinner({ size = 22 }: { size?: number }): React.ReactElement {
  return <span className="spin" style={{ width: size, height: size }} />;
}

export function Empty({ icon, title, text, children }: { icon?: string; title: string; text?: string; children?: React.ReactNode }): React.ReactElement {
  return (
    <div className="empty">
      {icon && <Icon n={icon} size={44} sw={1.5} />}
      <b>{title}</b>
      {text && <p>{text}</p>}
      {children}
    </div>
  );
}

export function Toggle({ on, onChange, label, sub, id }: { on: boolean; onChange: (v: boolean) => void; label: string; sub?: string; id: string }): React.ReactElement {
  return (
    <label className="row toggle-row" htmlFor={id}>
      <span className="grow">
        <span className="row-title">{label}</span>
        {sub && <span className="row-sub">{sub}</span>}
      </span>
      <input id={id} type="checkbox" className="switch" checked={on} onChange={(e) => onChange(e.target.checked)} />
    </label>
  );
}

export function Tabs<T extends string>({ value, onChange, items, className }: { value: T; onChange: (v: T) => void; items: [T, React.ReactNode][]; className?: string }): React.ReactElement {
  return (
    <div className={cx('tabs', className)} role="tablist">
      {items.map(([k, label]) => (
        <button key={k} role="tab" aria-selected={value === k} className={cx('tab', value === k && 'on')} onClick={() => onChange(k)}>
          {label}
        </button>
      ))}
    </div>
  );
}

export function Header({ title, right, onBack, sub }: { title: React.ReactNode; right?: React.ReactNode; onBack?: () => void; sub?: React.ReactNode }): React.ReactElement {
  return (
    <header className="hdr">
      <button className="icon-btn" onClick={onBack || back} aria-label={t('Назад')}>
        <Icon n="back" />
      </button>
      <div className="hdr-title">
        <b>{title}</b>
        {sub && <small>{sub}</small>}
      </div>
      <div className="hdr-right">{right}</div>
    </header>
  );
}

/** Caption text with clickable #hashtags, @mentions and links. */
export function RichText({ text, className }: { text: string; className?: string }): React.ReactElement {
  const parts: React.ReactNode[] = [];
  const re = new RegExp(`${TAG_RE.source}|@([a-z0-9_]{2,24})|(https?://[^\\s]+)`, 'giu');
  let last = 0;
  let m: RegExpExecArray | null;
  let i = 0;
  while ((m = re.exec(text))) {
    if (m.index > last) parts.push(text.slice(last, m.index));
    const tok = m[0];
    if (m[1]) {
      const tag = m[1].toLowerCase();
      parts.push(
        <a key={i++} className="rt-tag" onClick={(e) => (e.stopPropagation(), go('tag', { tag }))}>
          {tok}
        </a>,
      );
    } else if (m[2]) {
      const uid = uidByName(m[2]);
      parts.push(
        uid ? (
          <a key={i++} className="rt-tag" onClick={(e) => (e.stopPropagation(), go('profile', { uid }))}>
            {tok}
          </a>
        ) : (
          tok
        ),
      );
    } else if (m[3]) {
      parts.push(
        <a key={i++} className="rt-tag" href={m[3]} target="_blank" rel="noopener noreferrer" onClick={(e) => e.stopPropagation()}>
          {m[3].replace(/^https?:\/\//, '').slice(0, 40)}
        </a>,
      );
    }
    last = m.index + tok.length;
  }
  if (last < text.length) parts.push(text.slice(last));
  return <span className={className}>{parts}</span>;
}

export function Name({ uid, at = false }: { uid: string; at?: boolean }): React.ReactElement {
  const p = profile(uid);
  return <>{at ? '@' + (p?.un || '…') : p?.nm || p?.un || '…'}</>;
}

export function FollowButton({ uid, small, className }: { uid: string; small?: boolean; className?: string }): React.ReactElement | null {
  useStore();
  const me = S.uid;
  if (!me || me === uid) return null;
  const st = followState(me, uid);
  const back2 = follows(uid, me);
  const label = st === 'yes' ? (back2 ? t('Друзья') : t('Вы подписаны')) : st === 'requested' ? t('Запрошено') : back2 ? t('Подписаться в ответ') : t('Подписаться');
  return (
    <button
      className={cx('btn', st === 'no' ? 'btn-primary' : 'btn-muted', small && 'btn-sm', className)}
      onClick={(e) => {
        e.stopPropagation();
        void act(() => follow(uid, st === 'no'));
      }}
    >
      {label}
    </button>
  );
}

export function UserRow({ uid, right, sub, onClick }: { uid: string; right?: React.ReactNode; sub?: React.ReactNode; onClick?: () => void }): React.ReactElement {
  const p = profile(uid);
  return (
    <div className="row user-row tap" onClick={onClick || (() => go('profile', { uid }))}>
      <Avatar uid={uid} size={44} ring />
      <div className="grow min0">
        <div className="row-title ell">{p?.nm || p?.un}</div>
        <div className="row-sub ell">{sub ?? '@' + (p?.un || '')}</div>
      </div>
      {right ?? <FollowButton uid={uid} small />}
    </div>
  );
}

/** Bottom sheet host: swipe down on the handle area to close. */
export function SheetHost(): React.ReactElement | null {
  useStore();
  if (!nav.sheets.length) return null;
  const top = nav.sheets[nav.sheets.length - 1];
  return <Sheet key={top.id} tall={top.tall}>{top.render()}</Sheet>;
}
function Sheet({ children, tall }: { children: React.ReactNode; tall?: boolean }): React.ReactElement {
  const [dy, setDy] = useState(0);
  const start = useRef<number | null>(null);
  const onDown = (e: React.PointerEvent): void => {
    start.current = e.clientY;
    (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
  };
  const onMove = (e: React.PointerEvent): void => {
    if (start.current !== null) setDy(Math.max(0, e.clientY - start.current));
  };
  const onUp = (): void => {
    if (dy > 90) closeSheet();
    start.current = null;
    setDy(0);
  };
  return (
    <div className="sheet-wrap" onClick={closeSheet}>
      <div className={cx('sheet', tall && 'sheet-tall')} style={{ transform: dy ? `translateY(${dy}px)` : undefined }} onClick={(e) => e.stopPropagation()}>
        <div className="sheet-grab" onPointerDown={onDown} onPointerMove={onMove} onPointerUp={onUp} onPointerCancel={onUp}>
          <span />
        </div>
        {children}
      </div>
    </div>
  );
}

export function Toasts(): React.ReactElement {
  useStore();
  return (
    <div className="toasts" aria-live="polite">
      {nav.toasts.map((x) => (
        <div key={x.id} className="toast">
          <span>{x.text}</span>
          {x.act && (
            <button className="toast-act" onClick={x.act.fn}>
              {x.act.label}
            </button>
          )}
        </div>
      ))}
    </div>
  );
}

export function DialogHost(): React.ReactElement | null {
  useStore();
  const d = nav.dialog;
  if (!d) return null;
  return (
    <div className="dialog-wrap" onClick={() => answerDialog(false)}>
      <div className="dialog" role="dialog" onClick={(e) => e.stopPropagation()}>
        <b>{d.title}</b>
        {d.text && <p>{d.text}</p>}
        <div className="dialog-btns">
          <button className="btn btn-muted" onClick={() => answerDialog(false)}>
            {t('Отмена')}
          </button>
          <button className={cx('btn', d.danger ? 'btn-danger' : 'btn-primary')} onClick={() => answerDialog(true)}>
            {d.ok}
          </button>
        </div>
      </div>
    </div>
  );
}

export function MenuItem({ icon, label, onClick, danger, right }: { icon?: string; label: string; onClick: () => void; danger?: boolean; right?: React.ReactNode }): React.ReactElement {
  return (
    <button className={cx('menu-item', danger && 'danger')} onClick={onClick}>
      {icon && <Icon n={icon} size={22} />}
      <span className="grow">{label}</span>
      {right}
    </button>
  );
}

export function useInterval(fn: () => void, ms: number): void {
  const r = useRef(fn);
  r.current = fn;
  useEffect(() => {
    const id = setInterval(() => r.current(), ms);
    return () => clearInterval(id);
  }, [ms]);
}

export function FilePick({ accept, multiple, capture, onFiles, children, className, id }: { accept: string; multiple?: boolean; capture?: 'user' | 'environment'; onFiles: (f: File[]) => void; children: React.ReactNode; className?: string; id: string }): React.ReactElement {
  return (
    <label className={className} htmlFor={id}>
      {children}
      <input
        id={id}
        type="file"
        hidden
        accept={accept}
        multiple={multiple}
        {...(capture ? { capture } : {})}
        onChange={(e) => {
          const files = Array.from(e.target.files || []);
          e.target.value = '';
          if (files.length) onFiles(files);
        }}
      />
    </label>
  );
}

export function ReadOnlyNote(): React.ReactElement | null {
  useStore();
  if (!S.readOnly || !S.uid) return null;
  return <div className="ro-note">{t('Режим просмотра: попросите владельца дать вам доступ «Редактор», чтобы публиковать и общаться.')}</div>;
}

export function PrivateNote({ uid }: { uid: string }): React.ReactElement | null {
  if (canSeeProfileContent(uid)) return null;
  return <Empty icon="lock" title={t('Это закрытый аккаунт')} text={t('Подпишитесь, чтобы видеть публикации')} />;
}
