# Surat

Rasm va videolar uchun kichik ijtimoiy tarmoq: lenta, hikoyalar, rilslar, layklar, izohlar, obunalar va shifrlangan shaxsiy xabarlar. Ilova claude.ai artefakti sifatida ishlaydi, shuning uchun alohida server kerak emas. Interfeys tillari: oʻzbek (asosiy), rus va ingliz.

**Jonli versiya:** https://claude.ai/artifact/DT3kT8v1XgaPyZZgNjMYDW

> **English.** Surat is a small photo and video social app (feed, stories, reels, likes, comments, follows, end-to-end encrypted DMs) that runs as a claude.ai artifact, with no server of its own. The UI is in Uzbek, Russian and English. Build with `npm ci && npm run build`; the result is `dist/surat.html`.

## Imkoniyatlar

- Nik bilan roʻyxatdan oʻtish, 13 yoshdan boshlab.
- Obunalar lentasi va tavsiyalar. Ikki marta bosib layk qoʻyish, rasm karusellari, ovozli videolar.
- 24 soatlik hikoyalar: javob va reaksiyalar bilan.
- Rilslar (vertikal video lenta), mashhur postlar toʻri va qidiruv.
- Rasm, video va matnli postlar. Muharrirda matn, stikerlar, soʻrovnomalar, filtrlar va ovoz bor. Odamlarni belgilash, joy qoʻshish, qoralamalar, kechiktirilgan joylash.
- Layklar, javobli izohlar, saqlanganlar, obunalar. Yopiq akkauntlar soʻrov orqali ishlaydi. Bloklash mumkin.
- Bildirishnomalar, shaxsiy va guruh chatlari. Xabarlar ECDH + AES-GCM bilan qurilmada shifrlanadi.
- Muallif analitikasi, maxfiylik sozlamalari, shikoyatlar, ilova egasi uchun admin panel.

## Qanday ishlaydi

Maʼlumotlar bazasi, fayllar, foydalanuvchi va onlayn holat claude.ai muhitidan olinadi (`window.claude.use("db" | "user" | "assets" | "room" | "downloads")`). Har bir foydalanuvchi bazada faqat oʻz hujjatlariga yoza oladi. Ilova egasi kontentni moderatsiya qiladi. Ruxsatlar qoidalari [`artifact-capabilities.json`](artifact-capabilities.json) faylida.

`dist/surat.html` faylini oddiy brauzerda ochsangiz, sahifa uni claude.ai da ochishni soʻraydi: bazasiz ilova ishlamaydi.

## Tuzilma

```
src/core/      maʼlumotlar modeli, ombor va obunalar, lenta algoritmi, bildirishnomalar,
               qidiruv, analitika, yozish amallari, media, xabarlarni shifrlash
src/ui/        ekranlar va komponentlar: pleer, lenta, muharrir, izohlar, chatlar, hikoyalar,
               profil, qidiruv, sozlamalar, admin panel, tarjimalar (dict.ts)
src/surat/     ilova qobigʻi: main.tsx, index.html, app.css
src/types/     claude.ai muhiti API turlari
src/shim/      React cdnjs dan global oʻzgaruvchi sifatida ulanadi
dist/          yigʻilgan sahifa surat.html
test/          claude.ai muhitining mahalliy oʻrnini bosuvchi server va brauzer testi
```

## Yigʻish

Node.js 18 yoki yangiroq versiya kerak.

```bash
npm ci
```

```bash
npm test
```

`npm test` turlarni tekshiradi va `dist/surat.html` faylini yigʻadi. Faqat yigʻish uchun `npm run build` buyrugʻi yetarli.

## Brauzer testi

Test ikki foydalanuvchini yaratadi. Ular post joylaydi, layk va izoh qoldiradi, obuna boʻladi va shifrlangan xabar almashadi. Test claude.ai oʻrniga mahalliy serverdan foydalanadi, unga Playwright kerak:

```bash
npm i -D playwright
```

```bash
npx playwright install chromium
```

```bash
npm run test:e2e
```

Ilovani mahalliy serverda qoʻlda koʻrish uchun:

```bash
node test/server.mjs
```

Keyin brauzerda `http://localhost:8765/?uid=u_alice&owner=1` manzilini oching. `uid` foydalanuvchini tanlaydi, `owner=1` uni ilova egasi qiladi.

## claude.ai da joylash

1. `npm run build` buyrugʻini bajaring.
2. `dist/surat.html` faylini claude.ai da artefakt sifatida joylang va [`artifact-capabilities.json`](artifact-capabilities.json) dagi imkoniyatlarni bering.
3. Ulashish havolalari va QR-kodlar toʻgʻri ishlashi uchun artefakt havolasini `src/surat/index.html` dagi `window.APP_URL` ga yozing va qayta yigʻing.

Boshqalar ham post joylashi va yozishishi uchun:

- **Shaxsiy tarif:** odamlarni email orqali “Muharrir” huquqi bilan taklif qiling va ommaviy havolani yoqmang.
- **Team yoki Enterprise:** “Foydalanish mumkin” huquqi yetarli.

## Cheklovlar

- Fayl hajmi 20 MB gacha. Kattaroq videolar yuklashdan oldin brauzerda 720p gacha siqiladi.
- Ichki kamera yoʻq: “Suratga olish” tugmasi fayl tanlash orqali telefon kamerasini ochadi.
- Jonli efir va push-bildirishnomalar yoʻq.
- “Faqat doʻstlar” postlarini interfeys yashiradi. “Faqat men” postlari esa foydalanuvchining shaxsiy maʼlumotlarida saqlanadi.
