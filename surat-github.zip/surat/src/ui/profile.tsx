import React, { useEffect, useState } from 'react';
import { answerRequest, block, recordProfileView, removeFollower, setCollections, updateProfile } from '../core/actions';
import { agg, blockedEither, canSeeProfileContent, follows, friendsOf, getPost, iBlocked, profilePosts, suggestions, userKeys } from '../core/derive';
import { openDirect, messagePolicyOk } from '../core/dm';
import { S, useStore } from '../core/store';
import type { Profile } from '../core/types';
import { cx, DAY, fmtCount, unToHash } from '../core/util';
import { shareLink } from './config';
import { t, timeAgo } from './i18n';
import { Icon } from './icons';
import { act, Avatar, Empty, errToast, FilePick, FollowButton, Header, MenuItem, RichText, Tabs, UserRow } from './kit';
import { back as navBack, closeSheet, confirmDialog, go, sheet, toast } from './nav';
import { Thumb } from './player';
import { copyText, QrSheet, ReportSheet } from './share';

export function PostGrid({ keys, src, pins, empty, onLong }: { keys: string[]; src: string; pins?: string[]; empty?: React.ReactNode; onLong?: (k: string) => void }): React.ReactElement {
  if (!keys.length) return <>{empty}</>;
  return (
    <div className="grid3">
      {keys.map((k) => {
        const p = getPost(k);
        if (!p) return null;
        return (
          <Thumb key={k} post={p} onClick={() => go('post', { postKey: k, list: keys, src })}>
            {pins?.includes(p.id) && <span className="thumb-badge accent-bg">{t('Закреплено')}</span>}
            {p.priv !== 'all' && (
              <span className="thumb-lock">
                <Icon n={p.priv === 'me' ? 'lock' : 'users'} size={14} />
              </span>
            )}
            {p.at && p.at > Date.now() && (
              <span className="thumb-lock">
                <Icon n="clock" size={14} />
              </span>
            )}
            {p.t === 'photo' && (p.ph?.length || 0) > 1 && (
              <span className="thumb-multi">
                <Icon n="layers" size={14} />
              </span>
            )}
            <span className="thumb-views">
              <Icon n={p.t === 'video' ? 'play' : 'eye'} size={12} fill={p.t === 'video'} /> {fmtCount(p.views)}
            </span>
            {onLong && (
              <button className="thumb-del" onClick={(e) => (e.stopPropagation(), onLong(k))} aria-label={t('Коллекции')}>
                <Icon n="more" size={16} />
              </button>
            )}
          </Thumb>
        );
      })}
    </div>
  );
}

export function ProfileScreen({ uid, isTab }: { uid: string; isTab?: boolean }): React.ReactElement {
  useStore();
  const me = S.uid;
  const own = uid === me;
  const p = S.u[uid];
  const [tab, setTab] = useState<'posts' | 'reposts' | 'saved' | 'liked'>('posts');
  const [col, setCol] = useState<string | null>(null);
  useEffect(() => {
    if (!own) void recordProfileView(uid);
  }, [uid]);
  if (!p || p.del) return <div className="screen">{!isTab && <Header title="" />}<Empty icon="user" title={t('Аккаунт не найден')} /></div>;
  const A = agg();
  const followers = A.followers.get(uid) || [];
  const following = A.following.get(uid) || [];
  const likes = [...A.posts.values()].filter((x) => x.by === uid).reduce((s, x) => s + x.likes, 0);
  const visible = canSeeProfileContent(uid);
  const blocked = blockedEither(me, uid);
  const posts = visible ? profilePosts(uid) : [];
  const theyFollowMe = me ? follows(uid, me) : false;
  const requests = own ? A.requests.get(uid) || [] : [];

  const menu = (): void =>
    sheet(() => (
      <div>
        <MenuItem icon="link" label={t('Скопировать ссылку на профиль')} onClick={() => (void copyText(shareLink('user-' + unToHash(p.un))), closeSheet())} />
        <MenuItem icon="qr" label={t('QR-код профиля')} onClick={() => sheet(() => <QrSheet text={shareLink('user-' + unToHash(p.un))} title={'@' + p.un} />)} />
        {!own && me && theyFollowMe && (
          <MenuItem icon="users" label={t('Удалить из подписчиков')} onClick={async () => (closeSheet(), (await confirmDialog(t('Удалить подписчика?'), t('Удалить'))) && void act(() => removeFollower(uid), t('Подписчик удалён')))} />
        )}
        {!own && me && (
          <MenuItem
            icon="shield"
            danger={!iBlocked(uid)}
            label={iBlocked(uid) ? t('Разблокировать') : t('Заблокировать')}
            onClick={async () => {
              closeSheet();
              if (iBlocked(uid)) void act(() => block(uid, false), t('Пользователь разблокирован'));
              else if (await confirmDialog(t('Заблокировать @{u}?', { u: p.un }), t('Заблокировать'), t('Пользователь не сможет видеть ваш профиль, публикации и писать вам.'))) void act(() => block(uid, true), t('Пользователь заблокирован'));
            }}
          />
        )}
        {!own && me && <MenuItem icon="flag" label={t('Пожаловаться')} onClick={() => sheet(() => <ReportSheet k="user" id={uid} />)} />}
        {own && <MenuItem icon="settings" label={t('Настройки и конфиденциальность')} onClick={() => (closeSheet(), go('settings'))} />}
      </div>
    ));

  const saved = own ? userKeys(uid, 'sv') : [];
  const cols = S.me.cols || {};
  const savedShown = col ? saved.filter((k) => (cols[col] || []).includes(k)) : saved;
  const showLiked = own || !p.hideLikes;

  return (
    <div className="screen profile">
      <header className="hdr">
        {!isTab ? (
          <button className="icon-btn" onClick={import_back} aria-label={t('Назад')}>
            <Icon n="back" />
          </button>
        ) : own ? (
          <button className="icon-btn" onClick={() => go('find-people')} aria-label={t('Найти друзей')}>
            <Icon n="users" />
          </button>
        ) : (
          <span />
        )}
        <div className="hdr-title">
          <b>
            {p.priv && <Icon n="lock" size={14} />} {p.nm}
          </b>
        </div>
        <div className="hdr-right">
          {own && (
            <button className="icon-btn" onClick={() => go('analytics')} aria-label={t('Аналитика')}>
              <Icon n="chart" />
            </button>
          )}
          <button className="icon-btn" onClick={menu} aria-label={t('Меню')}>
            <Icon n={own ? 'settings' : 'more'} />
          </button>
        </div>
      </header>
      <div className="scroll">
        <div className="prof-head">
          <Avatar uid={uid} size={96} ring onClick={() => (A.stories.has(uid) && visible ? go('stories', { start: uid, only: true }) : undefined)} />
          <div className="prof-un">@{p.un}</div>
          <div className="prof-stats">
            <button onClick={() => visible && (!p.hideFollowing || own) && go('follows', { uid, tab: 'following' })}>
              <b>{fmtCount(following.length)}</b>
              <small>{t('Подписки')}</small>
            </button>
            <button onClick={() => visible && go('follows', { uid, tab: 'followers' })}>
              <b>{fmtCount(followers.length)}</b>
              <small>{t('Подписчики')}</small>
            </button>
            <div>
              <b>{fmtCount(likes)}</b>
              <small>{t('Лайки')}</small>
            </div>
          </div>
          {own ? (
            <div className="prof-btns">
              <button className="btn btn-muted" onClick={() => go('editprofile')}>
                {t('Редактировать профиль')}
              </button>
              <button className="btn btn-muted" onClick={() => void copyText(shareLink('user-' + unToHash(p.un)))}>
                {t('Поделиться')}
              </button>
              <button className="btn btn-muted btn-icon" onClick={() => go('drafts')} aria-label={t('Черновики')}>
                <Icon n="file" size={18} />
              </button>
            </div>
          ) : blocked ? (
            <div className="prof-btns">
              {iBlocked(uid) && (
                <button className="btn btn-muted" onClick={() => void act(() => block(uid, false))}>
                  {t('Разблокировать')}
                </button>
              )}
            </div>
          ) : (
            <div className="prof-btns">
              <FollowButton uid={uid} />
              {me && messagePolicyOk(uid) && (
                <button
                  className="btn btn-muted"
                  onClick={async () => {
                    try {
                      const cid = await openDirect(uid);
                      go('chat', { cid });
                    } catch (e) {
                      errToast(e);
                    }
                  }}
                >
                  {t('Сообщение')}
                </button>
              )}
            </div>
          )}
          {p.bio && <RichText className="prof-bio" text={p.bio} />}
          <div className="prof-links">
            {p.link && (
              <a href={/^https?:/.test(p.link) ? p.link : 'https://' + p.link} target="_blank" rel="noopener noreferrer">
                <Icon n="link" size={14} /> {p.link.replace(/^https?:\/\//, '')}
              </a>
            )}
            {p.ig && (
              <a href={'https://instagram.com/' + p.ig.replace('@', '')} target="_blank" rel="noopener noreferrer">
                IG @{p.ig.replace('@', '')}
              </a>
            )}
            {p.yt && (
              <a href={'https://youtube.com/@' + p.yt.replace('@', '')} target="_blank" rel="noopener noreferrer">
                YouTube @{p.yt.replace('@', '')}
              </a>
            )}
          </div>
          {own && requests.length > 0 && (
            <button className="req-banner" onClick={() => go('follows', { uid, tab: 'requests' })}>
              <Icon n="users" size={18} /> {t('Заявки на подписку')}: <b>{requests.length}</b>
            </button>
          )}
          {own && !p.pvOff && (
            <button className="link-btn" onClick={() => go('profileviews')}>
              <Icon n="eye" size={14} /> {t('Кто смотрел ваш профиль')}
            </button>
          )}
        </div>
        {blocked ? (
          <Empty icon="shield" title={iBlocked(uid) ? t('Вы заблокировали этого пользователя') : t('Профиль недоступен')} />
        ) : !visible ? (
          <Empty icon="lock" title={t('Это закрытый аккаунт')} text={t('Подпишитесь, чтобы видеть публикации')} />
        ) : (
          <>
            <Tabs
              className="prof-tabs"
              value={tab}
              onChange={setTab}
              items={[
                ['posts', <Icon key="a" n="grid" size={20} />],
                ['reposts', <Icon key="b" n="repost" size={20} />],
                ...(own ? ([['saved', <Icon key="c" n="bookmark" size={20} />]] as [typeof tab, React.ReactNode][]) : []),
                ...(showLiked ? ([['liked', <Icon key="d" n="heart" size={20} />]] as [typeof tab, React.ReactNode][]) : []),
              ]}
            />
            {tab === 'posts' && <PostGrid keys={posts} src="profile" pins={p.pins} empty={<Empty icon="video" title={own ? t('Пока нет видео — снимите первое!') : t('Пока нет публикаций')} />} />}
            {tab === 'reposts' && <PostGrid keys={userKeys(uid, 'rp')} src="profile" empty={<Empty icon="repost" title={t('Репостов пока нет')} />} />}
            {tab === 'saved' && own && (
              <>
                <div className="hscroll chips pad-x">
                  <button className={cx('chip', !col && 'on')} onClick={() => setCol(null)}>
                    {t('Все')}
                  </button>
                  {Object.keys(cols).map((c) => (
                    <button key={c} className={cx('chip', col === c && 'on')} onClick={() => setCol(c)}>
                      {c} · {(cols[c] || []).length}
                    </button>
                  ))}
                  <button className="chip" onClick={() => sheet(() => <NewCollection />)}>
                    + {t('Коллекция')}
                  </button>
                </div>
                <small className="muted pad-x">{t('Избранное видно только вам')}</small>
                <PostGrid keys={savedShown} src="profile" onLong={(k) => sheet(() => <CollectionsFor postKey={k} />)} empty={<Empty icon="bookmark" title={t('Здесь появится сохранённое')} />} />
              </>
            )}
            {tab === 'liked' && showLiked && (
              <>
                {own && p.hideLikes && <small className="muted pad-x">{t('Понравившееся скрыто от других')}</small>}
                <PostGrid keys={userKeys(uid, 'lk')} src="profile" empty={<Empty icon="heart" title={t('Понравившихся пока нет')} />} />
              </>
            )}
          </>
        )}
      </div>
    </div>
  );
}
function import_back(): void {
  navBack();
}

function NewCollection(): React.ReactElement {
  const [name, setName] = useState('');
  return (
    <div className="pad col gap">
      <b>{t('Новая коллекция')}</b>
      <input id="col-name" className="input" maxLength={30} value={name} onChange={(e) => setName(e.target.value)} placeholder={t('Название')} autoFocus />
      <button className="btn btn-primary" disabled={!name.trim()} onClick={() => void act(() => setCollections({ ...(S.me.cols || {}), [name.trim()]: S.me.cols?.[name.trim()] || [] })).then(closeSheet)}>
        {t('Создать')}
      </button>
    </div>
  );
}
function CollectionsFor({ postKey }: { postKey: string }): React.ReactElement {
  useStore();
  const cols = S.me.cols || {};
  const [name, setName] = useState('');
  const toggle = (c: string): void => {
    const cur = cols[c] || [];
    const next = cur.includes(postKey) ? cur.filter((x) => x !== postKey) : [...cur, postKey];
    void act(() => setCollections({ ...cols, [c]: next }));
  };
  return (
    <div className="pad col gap">
      <b>{t('Добавить в коллекцию')}</b>
      {Object.keys(cols).map((c) => (
        <label key={c} className="row" htmlFor={'col-' + c}>
          <span className="grow">{c}</span>
          <input id={'col-' + c} type="checkbox" checked={(cols[c] || []).includes(postKey)} onChange={() => toggle(c)} />
        </label>
      ))}
      <div className="row gap-s">
        <input id="col-new" className="input grow" placeholder={t('Новая коллекция')} value={name} onChange={(e) => setName(e.target.value)} />
        <button className="btn btn-primary btn-sm" disabled={!name.trim()} onClick={() => (void act(() => setCollections({ ...cols, [name.trim()]: [...(cols[name.trim()] || []), postKey] })), setName(''))}>
          {t('Создать')}
        </button>
      </div>
    </div>
  );
}

export function FollowsScreen({ uid, tab: tab0 }: { uid: string; tab: 'following' | 'followers' | 'friends' | 'requests' | 'suggested' }): React.ReactElement {
  useStore();
  const own = uid === S.uid;
  const [tab, setTab] = useState(tab0);
  const [q, setQ] = useState('');
  const A = agg();
  const lists: Record<string, string[]> = {
    following: A.following.get(uid) || [],
    followers: A.followers.get(uid) || [],
    friends: friendsOf(uid),
    requests: own ? A.requests.get(uid) || [] : [],
    suggested: own ? suggestions(30) : [],
  };
  const items: [typeof tab, React.ReactNode][] = [
    ['following', t('Подписки')],
    ['followers', t('Подписчики')],
    ['friends', t('Друзья')],
  ];
  if (own) items.push(['requests', t('Заявки')], ['suggested', t('Рекомендуемые')]);
  const list = lists[tab].filter((u) => !q || S.u[u]?.un.includes(q.toLowerCase()) || S.u[u]?.nm.toLowerCase().includes(q.toLowerCase()));
  return (
    <div className="screen">
      <Header title={'@' + (S.u[uid]?.un || '')} />
      <Tabs value={tab} onChange={setTab} items={items} className="tabs-scroll" />
      <div className="pad-x">
        <input id="follows-q" className="input" placeholder={t('Поиск')} value={q} onChange={(e) => setQ(e.target.value)} />
      </div>
      <div className="scroll">
        {list.length === 0 && <Empty icon="users" title={tab === 'requests' ? t('Новых заявок нет') : t('Здесь пока никого')} />}
        {list.map((u) =>
          tab === 'requests' ? (
            <UserRow
              key={u}
              uid={u}
              right={
                <div className="row gap-s">
                  <button className="btn btn-primary btn-sm" onClick={() => void act(() => answerRequest(u, true), t('Заявка принята'))}>
                    {t('Принять')}
                  </button>
                  <button className="btn btn-muted btn-sm" onClick={() => void act(() => answerRequest(u, false))}>
                    {t('Отклонить')}
                  </button>
                </div>
              }
            />
          ) : tab === 'followers' && own ? (
            <UserRow
              key={u}
              uid={u}
              right={
                <div className="row gap-s">
                  <FollowButton uid={u} small />
                  <button className="icon-btn" onClick={async () => (await confirmDialog(t('Удалить подписчика?'), t('Удалить'))) && void act(() => removeFollower(u))} aria-label={t('Удалить')}>
                    <Icon n="close" size={18} />
                  </button>
                </div>
              }
            />
          ) : (
            <UserRow key={u} uid={u} sub={tab === 'suggested' ? suggestReason(u) : undefined} />
          ),
        )}
      </div>
    </div>
  );
}

export function suggestReason(u: string): string {
  const me = S.uid;
  if (!me) return '';
  if (follows(u, me)) return t('Подписан(а) на вас');
  const A = agg();
  const mutual = (A.following.get(me) || []).filter((f) => (A.following.get(f) || []).includes(u));
  if (mutual.length) return t('Подписаны: {u}', { u: S.u[mutual[0]]?.un + (mutual.length > 1 ? ` +${mutual.length - 1}` : '') });
  return t('Популярный автор');
}

export function FindPeopleScreen(): React.ReactElement {
  useStore();
  const sug = suggestions(40);
  return (
    <div className="screen">
      <Header title={t('Вы можете знать')} />
      <div className="scroll">
        {sug.length === 0 && <Empty icon="users" title={t('Пока некого предложить')} text={t('Позовите друзей — поделитесь ссылкой на свой профиль')} />}
        {sug.map((u) => (
          <UserRow key={u} uid={u} sub={suggestReason(u)} />
        ))}
      </div>
    </div>
  );
}

export function ProfileViewsScreen(): React.ReactElement {
  useStore();
  const me = S.uid!;
  const list = Object.keys(S.v)
    .map((v) => [v, S.v[v]?.prof?.[me] || 0] as const)
    .filter(([v, ts]) => v !== me && ts && Date.now() - ts < 30 * DAY && S.u[v] && !S.u[v].pvOff)
    .sort((a, b) => b[1] - a[1]);
  return (
    <div className="screen">
      <Header title={t('Просмотры профиля')} sub={t('За последние 30 дней')} />
      <div className="scroll">
        {S.u[me]?.pvOff ? (
          <Empty icon="eyeoff" title={t('История просмотров отключена')} text={t('Включите её в настройках конфиденциальности')} />
        ) : list.length === 0 ? (
          <Empty icon="eye" title={t('Пока никто не заходил')} />
        ) : (
          list.map(([v, ts]) => <UserRow key={v} uid={v} sub={timeAgo(ts)} />)
        )}
      </div>
    </div>
  );
}

export function EditProfileScreen(): React.ReactElement {
  useStore();
  const me = S.uid!;
  const p = S.u[me];
  const [f, setF] = useState<Partial<Profile>>({ nm: p?.nm, un: p?.un, bio: p?.bio || '', link: p?.link || '', ig: p?.ig || '', yt: p?.yt || '' });
  const [av, setAv] = useState<File | null>(null);
  const [busy, setBusy] = useState(false);
  if (!p) return <div className="screen" />;
  const nextChange = (p.unAt || 0) + 30 * DAY;
  const save = async (): Promise<void> => {
    setBusy(true);
    try {
      await updateProfile({ ...f, nm: (f.nm || '').trim().slice(0, 30) || p.un, bio: (f.bio || '').slice(0, 160) }, av);
      toast(t('Профиль обновлён'));
      import_back();
    } catch (e) {
      errToast(e);
    } finally {
      setBusy(false);
    }
  };
  const field = (k: keyof Profile, label: string, max: number, ph?: string): React.ReactElement => (
    <label className="field" htmlFor={'ep-' + k}>
      <span>{label}</span>
      <input id={'ep-' + k} className="input" maxLength={max} placeholder={ph} value={String(f[k] ?? '')} onChange={(e) => setF({ ...f, [k]: e.target.value })} />
    </label>
  );
  return (
    <div className="screen">
      <Header title={t('Редактировать профиль')} right={<button className="btn btn-primary btn-sm" disabled={busy} onClick={() => void save()}>{busy ? '…' : t('Сохранить')}</button>} />
      <div className="scroll pad col gap">
        <div className="center col gap-s">
          {av ? av.type.startsWith('video') ? <video className="av-preview" src={URL.createObjectURL(av)} autoPlay muted loop playsInline /> : <img className="av-preview" src={URL.createObjectURL(av)} alt="" /> : <Avatar uid={me} size={96} />}
          {S.canUpload && (
            <FilePick id="ep-av" accept="image/*,video/mp4,video/webm" onFiles={([file]) => setAv(file)} className="link-btn">
              {t('Сменить фото или видео')}
            </FilePick>
          )}
        </div>
        {field('nm', t('Имя'), 30)}
        <label className="field" htmlFor="ep-un">
          <span>{t('Ник')}</span>
          <input id="ep-un" className="input" maxLength={24} value={f.un || ''} disabled={Date.now() < nextChange} onChange={(e) => setF({ ...f, un: e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, '') })} />
          <small className="muted">{Date.now() < nextChange ? t('Сменить ник можно {d}', { d: new Date(nextChange).toLocaleDateString() }) : t('Ник можно менять раз в 30 дней')}</small>
        </label>
        <label className="field" htmlFor="ep-bio">
          <span>{t('О себе')}</span>
          <textarea id="ep-bio" className="input" rows={3} maxLength={160} value={f.bio || ''} onChange={(e) => setF({ ...f, bio: e.target.value })} />
        </label>
        {field('link', t('Ссылка'), 100, 'example.com')}
        {field('ig', 'Instagram', 40, '@')}
        {field('yt', 'YouTube', 40, '@')}
      </div>
    </div>
  );
}

