import React, { useEffect, useMemo, useRef, useState } from 'react';
import { deleteDraft, newPost, updatePost } from '../core/actions';
import { getPost, searchTags, searchUsers } from '../core/derive';
import { captureFrame, fileKind, upload, videoMeta } from '../core/media';
import { S, useStore } from '../core/store';
import type { Clip, Overlay, Post, SoundRef, Story } from '../core/types';
import { clamp, cx, fmtCount, fmtDur, rid, splitKey } from '../core/util';
import { saveFile } from '../core/caps';
import { t } from './i18n';
import { Icon } from './icons';
import { Avatar, Empty, FilePick, Header, Tabs, Toggle, errToast } from './kit';
import { closeSheet, confirmDialog, go, popScreen, sheet, toast } from './nav';
import { FILTERS, FONT_NAMES, FONTS, OverlayView, PostMedia, clipLen, filterCss, msrc, soundTitle, totalLen } from './player';
import { SoundPicker } from './sounds';
import { startJob, type LocalMedia } from './upload';

const DURS = [15, 60, 180, 600];
const SPEEDS = [0.3, 0.5, 1, 2, 3];
const COLORS = ['#ffffff', '#111111', '#ff5a36', '#ffb800', '#2bd576', '#25b4ff', '#8b5cf6', '#ff4fa3'];
export const BGS = ['#1f1f2e', '#ff5a36', '#0f766e', '#7c3aed', '#e11d48', '#f59e0b', 'linear-gradient(135deg,#ff5a36,#8b5cf6)', 'linear-gradient(135deg,#0ea5e9,#22c55e)', 'linear-gradient(135deg,#f59e0b,#ef4444)', 'linear-gradient(135deg,#111827,#4b5563)', 'linear-gradient(135deg,#ec4899,#f97316)', 'linear-gradient(135deg,#14b8a6,#6366f1)'];
const EMOJIS = ['😂', '🔥', '❤️', '😍', '🥹', '😎', '🤯', '🎉', '✨', '💯', '👀', '🙌', '🍕', '☕', '🌙', '⭐', '🎵', '📍', '🌸', '🐱'];

type Step = 'source' | 'edit' | 'publish';

interface Props {
  duet?: string;
  stitch?: string;
  vreply?: Post['vreply'];
  sound?: string;
  tag?: string;
  draft?: string;
  story?: boolean;
}

function soundRefFromKey(key?: string): SoundRef | undefined {
  if (!key) return undefined;
  const [k, rest] = [key.slice(0, 1) as 'p' | 's', key.slice(2)];
  const [au, id] = splitKey(rest);
  return { k, au, id, st: 0, v: 1 };
}

export function CreateScreen(props: Props): React.ReactElement {
  useStore();
  const draft = props.draft ? S.me.drafts?.[props.draft] : undefined;
  const [mode, setMode] = useState<'video' | 'photo' | 'text' | 'story'>(props.story ? 'story' : draft ? draft.post.t : 'video');
  const [step, setStep] = useState<Step>(draft ? 'edit' : 'source');
  const [maxDur, setMaxDur] = useState(600);
  const [speed, setSpeed] = useState(1);
  const media = useRef<Record<string, LocalMedia>>({});
  const [hist, setHist] = useState<{ list: Post[]; i: number }>(() => {
    const p = draft ? draft.post : newPost('video');
    if (!draft) {
      if (props.tag) p.cap = `#${props.tag} `;
      if (props.sound) {
        p.snd = soundRefFromKey(props.sound);
        p.ovol = 0;
      }
      if (props.duet) {
        const [au, pid] = splitKey(props.duet);
        p.duet = { au, pid, lay: 'lr' };
        p.ovol = 1;
      }
      if (props.stitch) {
        const [au, pid] = splitKey(props.stitch);
        p.stitch = { au, pid, s: 0, e: 5 };
      }
      if (props.vreply) p.vreply = props.vreply;
    }
    return { list: [p], i: 0 };
  });
  const post = hist.list[hist.i];
  const [cover, setCover] = useState<{ time: number; text: string }>({ time: 0.2, text: '' });
  const [busy, setBusy] = useState(false);

  const handed = useRef(new Set<string>());
  useEffect(
    () => () => {
      // URLs handed to a background upload are released by the upload job itself
      for (const m of Object.values(media.current)) if (m.url.startsWith('blob:') && !handed.current.has(m.url)) URL.revokeObjectURL(m.url);
    },
    [],
  );

  const update = (p: Post, record = true): void => {
    setHist((h) => {
      if (!record) {
        const list = h.list.slice();
        list[h.i] = p;
        return { list, i: h.i };
      }
      const list = [...h.list.slice(0, h.i + 1), p].slice(-60);
      return { list, i: list.length - 1 };
    });
  };
  const patch = (ch: Partial<Post>, record = true): void => update({ ...post, ...ch }, record);
  const undo = (): void => setHist((h) => ({ ...h, i: Math.max(0, h.i - 1) }));
  const redo = (): void => setHist((h) => ({ ...h, i: Math.min(h.list.length - 1, h.i + 1) }));

  const addFiles = async (files: File[], forceKind?: 'video' | 'photo'): Promise<void> => {
    setBusy(true);
    try {
      const vids = files.filter((f) => fileKind(f) === 'video');
      const imgs = files.filter((f) => fileKind(f) === 'image');
      const asStoryOrPhoto = mode === 'story';
      if (asStoryOrPhoto) {
        const f = files[0];
        const url = URL.createObjectURL(f);
        const kind = fileKind(f) === 'video' ? 'video' : 'image';
        media.current = { [url]: { url, file: f, kind } };
        if (kind === 'video') {
          const m = await videoMeta(url);
          update({ ...post, t: 'video', clips: [{ a: url, s: 0, e: Math.min(m.dur, 60), r: 1, d: m.dur }], dur: Math.min(m.dur, 60), ar: m.w / Math.max(1, m.h) });
        } else update({ ...post, t: 'photo', ph: [url], clips: undefined });
        setStep('edit');
        return;
      }
      if ((forceKind === 'photo' || (!vids.length && imgs.length)) && !post.duet && !post.stitch) {
        const cur = post.t === 'photo' ? post.ph || [] : [];
        const room = 35 - cur.length;
        if (imgs.length > room) toast(t('В карусели не больше 35 фото'));
        const urls = imgs.slice(0, room).map((f) => {
          const url = URL.createObjectURL(f);
          media.current[url] = { url, file: f, kind: 'image' };
          return url;
        });
        update({ ...post, t: 'photo', ph: [...cur, ...urls], clips: undefined });
        setMode('photo');
        setStep('edit');
        return;
      }
      if (imgs.length) toast(t('Фото пропущены: видео и фото нельзя смешивать в одном посте'));
      const clips: Clip[] = post.t === 'video' ? [...(post.clips || [])] : [];
      for (const f of vids) {
        const url = URL.createObjectURL(f);
        let m;
        try {
          m = await videoMeta(url);
        } catch {
          toast(t('Не удалось прочитать видео {n}', { n: f.name }));
          continue;
        }
        if (m.dur < 1) {
          toast(t('Видео короче 1 секунды'));
          continue;
        }
        media.current[url] = { url, file: f, kind: 'video' };
        clips.push({ a: url, s: 0, e: m.dur, r: speed, d: m.dur });
        if (!post.ar) post.ar = m.w / Math.max(1, m.h);
      }
      // fit to the chosen maximum length
      let total = 0;
      const fitted: Clip[] = [];
      for (const c of clips) {
        const len = clipLen(c);
        if (total + len <= maxDur) {
          fitted.push(c);
          total += len;
        } else {
          const left = maxDur - total;
          if (left >= 0.5) fitted.push({ ...c, e: c.s + left * c.r });
          total = maxDur;
          toast(t('Видео обрезано до {d}', { d: fmtDur(maxDur) }));
          break;
        }
      }
      if (!fitted.length) return;
      update({ ...post, t: 'video', clips: fitted, ph: undefined, dur: totalLen(fitted) });
      setMode('video');
      setStep('edit');
    } catch (e) {
      errToast(e);
    } finally {
      setBusy(false);
    }
  };

  const close = async (): Promise<void> => {
    if (step !== 'source' && hist.list.length > 1 && !(await confirmDialog(t('Выйти без сохранения?'), t('Выйти'), t('Изменения будут потеряны')))) return;
    popScreen();
  };

  const publish = (asDraft: boolean): void => {
    const p: Post = { ...post, by: S.uid || '', ts: Date.now() };
    if (p.t === 'video') p.dur = totalLen(p.clips || []) + (p.stitch ? p.stitch.e - p.stitch.s : 0);
    if (p.t === 'video' && !p.clips?.length) return toast(t('Добавьте видео'));
    if (p.t === 'photo' && !p.ph?.length) return toast(t('Добавьте фото'));
    if (p.t === 'text' && !p.cap.trim()) return toast(t('Напишите текст'));
    if (p.cap.length > 4000) return toast(t('Описание длиннее 4000 символов'));
    const used: Record<string, LocalMedia> = {};
    for (const c of p.clips || []) if (media.current[c.a]) used[c.a] = media.current[c.a];
    for (const a of p.ph || []) if (media.current[a]) used[a] = media.current[a];
    const thumb = p.t === 'photo' ? p.ph?.[0] : undefined;
    Object.keys(used).forEach((u) => handed.current.add(u));
    startJob({ post: p, media: used, cover: p.t === 'video' ? { time: (p.clips?.[0]?.s || 0) + cover.time, text: cover.text || undefined } : cover.text ? { time: 0, text: cover.text } : undefined, mode: asDraft ? 'draft' : 'post', thumb: thumb ? msrc(thumb) : undefined });
    if (draft && !asDraft) void deleteDraft(draft.id).catch(() => undefined);
    popScreen();
  };

  const publishStoryNow = (): void => {
    const st: Story = { id: rid(10), t: post.t === 'video' ? 'video' : post.t === 'photo' ? 'photo' : 'text', ts: Date.now() };
    const used: Record<string, LocalMedia> = {};
    if (post.t === 'video' && post.clips?.[0]) {
      st.m = post.clips[0].a;
      st.dur = Math.min(60, clipLen(post.clips[0]));
      used[st.m] = media.current[st.m];
    } else if (post.t === 'photo' && post.ph?.[0]) {
      st.m = post.ph[0];
      used[st.m] = media.current[st.m];
    } else {
      st.bg = post.txt?.bg || BGS[0];
      st.c = post.txt?.c || '#fff';
      if (!post.cap.trim()) return toast(t('Напишите текст'));
    }
    if (post.cap.trim()) st.txt = post.cap.trim().slice(0, 200);
    if (post.snd) st.snd = post.snd;
    Object.keys(used).forEach((u) => handed.current.add(u));
    startJob({ post, media: used, mode: 'story', story: st });
    popScreen();
  };

  if (S.readOnly) {
    return (
      <div className="screen create dark-screen">
        <Header title={t('Создать')} />
        <Empty icon="lock" title={t('Публикация недоступна')} text={t('Режим просмотра: попросите владельца дать вам доступ «Редактор», чтобы публиковать и общаться.')} />
      </div>
    );
  }
  if (!S.canUpload && mode !== 'text') {
    // Text posts work without file uploads.
  }

  // ---------- step: source ----------
  if (step === 'source') {
    const origKey = props.duet || props.stitch;
    const orig = origKey ? getPost(origKey) : undefined;
    return (
      <div className="screen create dark-screen">
        <div className="create-top">
          <button className="icon-btn" onClick={() => void close()} aria-label={t('Закрыть')}>
            <Icon n="close" />
          </button>
          {mode !== 'text' && (
            <button className="chip chip-sound" onClick={() => sheet(() => <SoundPicker onPick={(snd) => (patch({ snd, ovol: post.duet ? 1 : 0 }), closeSheet())} />, true)}>
              <Icon n="music" size={16} /> {post.snd ? soundTitle(`${post.snd.k}:${post.snd.au}~${post.snd.id}`) : t('Добавить звук')}
            </button>
          )}
          <span />
        </div>
        <div className="create-center">
          {orig && (
            <div className="orig-preview">
              <PostMedia post={orig} active fit="contain" overlays={false} />
              <small>{props.duet ? t('Дуэт с @{u}', { u: S.u[orig.by]?.un || '' }) : t('Стежок с @{u}', { u: S.u[orig.by]?.un || '' })}</small>
            </div>
          )}
          {props.stitch && orig && (
            <div className="stitch-range pad">
              <b>{t('Фрагмент оригинала (до 5 сек)')}</b>
              <label className="range-label">
                {t('Начало')}: {fmtDur(post.stitch?.s || 0)}
                <input id="stitch-start" type="range" min={0} max={Math.max(0, (orig.dur || 5) - 1)} step={0.1} value={post.stitch?.s || 0} onChange={(e) => {
                  const s = Number(e.target.value);
                  patch({ stitch: { ...post.stitch!, s, e: Math.min(s + 5, orig.dur || s + 5) } }, false);
                }} />
              </label>
              <label className="range-label">
                {t('Длина')}: {((post.stitch?.e || 5) - (post.stitch?.s || 0)).toFixed(1)} {t('сек')}
                <input id="stitch-len" type="range" min={1} max={5} step={0.1} value={(post.stitch?.e || 5) - (post.stitch?.s || 0)} onChange={(e) => patch({ stitch: { ...post.stitch!, e: Math.min((post.stitch?.s || 0) + Number(e.target.value), orig.dur || 99) } }, false)} />
              </label>
            </div>
          )}
          {mode === 'text' ? (
            <TextComposer post={post} patch={patch} onNext={() => (update({ ...post, t: 'text', clips: undefined, ph: undefined, txt: post.txt || { bg: BGS[6], f: 1, c: '#ffffff' } }), setStep('edit'))} />
          ) : (
            <div className="source-btns">
              {!S.canUpload && <p className="muted center">{t('Загрузка файлов недоступна для вашего уровня доступа')}</p>}
              {S.canUpload && mode !== 'photo' && (
                <FilePick id="cap-video" accept="video/*" capture="environment" onFiles={(f) => void addFiles(f)} className="big-src">
                  <span className="rec-dot" />
                  <b>{t('Снять видео')}</b>
                  <small>{t('Откроется камера телефона')}</small>
                </FilePick>
              )}
              {S.canUpload && (mode === 'photo' || mode === 'story') && (
                <FilePick id="cap-photo" accept="image/*" capture="environment" onFiles={(f) => void addFiles(f, 'photo')} className="big-src">
                  <Icon n="camera" size={30} />
                  <b>{t('Снять фото')}</b>
                </FilePick>
              )}
              {S.canUpload && (
                <FilePick id="pick-gallery" accept={mode === 'photo' ? 'image/*' : mode === 'video' && (props.duet || props.stitch) ? 'video/*' : 'video/*,image/*'} multiple={mode !== 'story'} onFiles={(f) => void addFiles(f, mode === 'photo' ? 'photo' : undefined)} className="big-src alt">
                  <Icon n="image" size={30} />
                  <b>{t('Загрузить')}</b>
                  <small>{mode === 'photo' ? t('До 35 фото') : mode === 'story' ? t('Фото или видео') : t('Несколько видео — склеим по порядку')}</small>
                </FilePick>
              )}
              {busy && <p className="muted center">{t('Читаем файлы…')}</p>}
            </div>
          )}
          {mode === 'video' && (
            <>
              <div className="chips center-chips">
                {DURS.map((d) => (
                  <button key={d} className={cx('chip', maxDur === d && 'on')} onClick={() => setMaxDur(d)}>
                    {d < 60 ? `${d} ${t('сек')}` : `${d / 60} ${t('мин')}`}
                  </button>
                ))}
              </div>
              <div className="chips center-chips">
                <small className="muted">{t('Скорость')}</small>
                {SPEEDS.map((s) => (
                  <button key={s} className={cx('chip', speed === s && 'on')} onClick={() => setSpeed(s)}>
                    {s}x
                  </button>
                ))}
              </div>
            </>
          )}
        </div>
        {!props.duet && !props.stitch && !props.vreply && (
          <div className="mode-tabs">
            {(['story', 'video', 'photo', 'text'] as const).map((m) => (
              <button key={m} className={cx(mode === m && 'on')} onClick={() => setMode(m)}>
                {m === 'video' ? t('Видео') : m === 'photo' ? t('Фото') : m === 'text' ? t('Текст') : t('История')}
              </button>
            ))}
          </div>
        )}
      </div>
    );
  }

  // ---------- step: publish ----------
  if (step === 'publish') return <PublishStep post={post} patch={patch} cover={cover} setCover={setCover} onBack={() => setStep('edit')} onPublish={publish} media={media.current} />;

  // ---------- step: edit ----------
  return <Editor post={post} patch={patch} update={update} undo={undo} redo={redo} canUndo={hist.i > 0} canRedo={hist.i < hist.list.length - 1} isStory={mode === 'story'} onBack={() => setStep('source')} onNext={() => (mode === 'story' ? publishStoryNow() : setStep('publish'))} addFiles={addFiles} />;
}

function TextComposer({ post, patch, onNext }: { post: Post; patch: (c: Partial<Post>, r?: boolean) => void; onNext: () => void }): React.ReactElement {
  const st = post.txt || { bg: BGS[6], f: 1, c: '#ffffff' };
  return (
    <div className="text-composer">
      <div className="textpost tc-preview" style={{ background: st.bg, color: st.c, fontFamily: FONTS[st.f] }}>
        <textarea id="text-post" className="tc-input" placeholder={t('Напишите что-нибудь…')} maxLength={4000} value={post.cap} onChange={(e) => patch({ cap: e.target.value, txt: st }, false)} style={{ color: st.c, fontFamily: FONTS[st.f] }} />
      </div>
      <div className="hscroll chips">
        {BGS.map((b) => (
          <button key={b} className={cx('swatch', st.bg === b && 'on')} style={{ background: b }} onClick={() => patch({ txt: { ...st, bg: b } })} aria-label={b} />
        ))}
      </div>
      <div className="hscroll chips">
        {FONTS.map((f, i) => (
          <button key={i} className={cx('chip', st.f === i && 'on')} style={{ fontFamily: f }} onClick={() => patch({ txt: { ...st, f: i } })}>
            {FONT_NAMES[i]}
          </button>
        ))}
      </div>
      <div className="hscroll chips">
        {COLORS.map((c) => (
          <button key={c} className={cx('swatch sm', st.c === c && 'on')} style={{ background: c }} onClick={() => patch({ txt: { ...st, c } })} aria-label={c} />
        ))}
      </div>
      <button className="btn btn-primary wide" disabled={!post.cap.trim()} onClick={onNext}>
        {t('Далее')}
      </button>
    </div>
  );
}

// ---------- editor ----------
interface EditorProps {
  post: Post;
  patch: (c: Partial<Post>, record?: boolean) => void;
  update: (p: Post, record?: boolean) => void;
  undo: () => void;
  redo: () => void;
  canUndo: boolean;
  canRedo: boolean;
  isStory: boolean;
  onBack: () => void;
  onNext: () => void;
  addFiles: (f: File[], k?: 'video' | 'photo') => Promise<void>;
}

function Editor({ post, patch, update, undo, redo, canUndo, canRedo, isStory, onBack, onNext, addFiles }: EditorProps): React.ReactElement {
  const [playing, setPlaying] = useState(true);
  const [sel, setSel] = useState(0);
  const [selOv, setSelOv] = useState<string | null>(null);
  const [panel, setPanel] = useState<'' | 'clips' | 'filters' | 'volume' | 'layout'>(post.t === 'video' && !isStory ? 'clips' : '');
  const [cur, setCur] = useState(0);
  const [seek, setSeek] = useState<{ t: number; n: number } | null>(null);
  const stage = useRef<HTMLDivElement | null>(null);
  const clips = post.clips || [];
  const total = totalLen(clips);
  const key = 'draft';

  const setOverlays = (ov: Overlay[], record = true): void => patch({ ov }, record);
  const addOverlay = (o: Omit<Overlay, 'id' | 'x' | 'y' | 'sc' | 'rot'>): void => {
    const ov: Overlay = { id: rid(6), x: 0.5, y: 0.42, sc: 1, rot: 0, ...o };
    setOverlays([...(post.ov || []), ov]);
    setSelOv(ov.id);
  };

  // drag / pinch / rotate overlays
  const gesture = useRef<{ id: string; pts: Map<number, { x: number; y: number }>; start: Overlay; d0: number; a0: number; c0: { x: number; y: number } } | null>(null);
  const onOvDown = (e: React.PointerEvent, o: Overlay): void => {
    e.stopPropagation();
    setSelOv(o.id);
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    const g = gesture.current && gesture.current.id === o.id ? gesture.current : { id: o.id, pts: new Map(), start: o, d0: 0, a0: 0, c0: { x: e.clientX, y: e.clientY } };
    g.pts.set(e.pointerId, { x: e.clientX, y: e.clientY });
    g.start = o;
    if (g.pts.size === 2) {
      const [a, b] = [...g.pts.values()];
      g.d0 = Math.hypot(b.x - a.x, b.y - a.y);
      g.a0 = Math.atan2(b.y - a.y, b.x - a.x);
    } else g.c0 = { x: e.clientX, y: e.clientY };
    gesture.current = g;
  };
  const onOvMove = (e: React.PointerEvent): void => {
    const g = gesture.current;
    const box = stage.current?.getBoundingClientRect();
    if (!g || !box || !g.pts.has(e.pointerId)) return;
    g.pts.set(e.pointerId, { x: e.clientX, y: e.clientY });
    const ov = (post.ov || []).map((o) => {
      if (o.id !== g.id) return o;
      if (g.pts.size >= 2) {
        const [a, b] = [...g.pts.values()];
        const d = Math.hypot(b.x - a.x, b.y - a.y);
        const ang = Math.atan2(b.y - a.y, b.x - a.x);
        return { ...o, sc: clamp(g.start.sc * (d / (g.d0 || d)), 0.3, 5), rot: g.start.rot + ((ang - g.a0) * 180) / Math.PI };
      }
      return { ...o, x: clamp(g.start.x + (e.clientX - g.c0.x) / box.width, 0.02, 0.98), y: clamp(g.start.y + (e.clientY - g.c0.y) / box.height, 0.02, 0.98) };
    });
    setOverlays(ov, false);
  };
  const onOvUp = (e: React.PointerEvent): void => {
    const g = gesture.current;
    if (!g) return;
    g.pts.delete(e.pointerId);
    if (g.pts.size === 0) {
      gesture.current = null;
      setOverlays(post.ov || [], true);
    } else {
      const o = (post.ov || []).find((x) => x.id === g.id);
      if (o) {
        g.start = o;
        const [p] = [...g.pts.values()];
        g.c0 = p;
      }
    }
  };
  const selected = (post.ov || []).find((o) => o.id === selOv) || null;
  const changeOv = (ch: Partial<Overlay>, record = true): void => setOverlays((post.ov || []).map((o) => (o.id === selOv ? { ...o, ...ch } : o)), record);

  const c = clips[sel];
  const setClip = (ch: Partial<Clip>, record = true): void => {
    const next = clips.map((x, i) => (i === sel ? { ...x, ...ch } : x));
    patch({ clips: next, dur: totalLen(next) }, record);
  };
  const offsetOf = (i: number): number => clips.slice(0, i).reduce((a, x) => a + clipLen(x), 0);
  const split = (): void => {
    if (!c) return;
    const local = cur - offsetOf(sel);
    const at = c.s + local * c.r;
    if (at <= c.s + 0.3 || at >= c.e - 0.3) return toast(t('Поставьте курсор внутрь клипа'));
    const next = [...clips.slice(0, sel), { ...c, e: at }, { ...c, s: at }, ...clips.slice(sel + 1)];
    patch({ clips: next, dur: totalLen(next) });
  };
  const move = (dir: -1 | 1): void => {
    const j = sel + dir;
    if (j < 0 || j >= clips.length) return;
    const next = clips.slice();
    [next[sel], next[j]] = [next[j], next[sel]];
    patch({ clips: next });
    setSel(j);
  };
  const removeClip = (): void => {
    if (clips.length <= 1) return toast(t('Нужен хотя бы один клип'));
    const next = clips.filter((_, i) => i !== sel);
    patch({ clips: next, dur: totalLen(next) });
    setSel(Math.max(0, sel - 1));
  };

  const previewPost = useMemo(() => ({ ...post, ov: [] }), [post]);

  return (
    <div className="screen editor dark-screen">
      <div className="ed-top">
        <button className="icon-btn" onClick={onBack} aria-label={t('Назад')}>
          <Icon n="back" />
        </button>
        <div className="row gap-s">
          <button className="icon-btn" disabled={!canUndo} onClick={undo} aria-label={t('Отменить')}>
            <Icon n="undo" />
          </button>
          <button className="icon-btn" disabled={!canRedo} onClick={redo} aria-label={t('Повторить')}>
            <Icon n="redo" />
          </button>
        </div>
        <button className="btn btn-primary btn-sm" onClick={onNext}>
          {isStory ? t('Опубликовать') : t('Далее')}
        </button>
      </div>
      <div className="ed-stage" ref={stage} onClick={() => (selOv ? setSelOv(null) : setPlaying(!playing))}>
        <PostMedia post={previewPost} active paused={!playing} onTime={(x) => setCur(x)} seek={seek} eager overlays={false} fit="contain" />
        <div className="overlays">
          {(post.ov || []).map((o) => (
            <div key={o.id} className={cx('ov-edit', selOv === o.id && 'sel')} onPointerDown={(e) => onOvDown(e, o)} onPointerMove={onOvMove} onPointerUp={onOvUp} onPointerCancel={onOvUp} onClick={(e) => e.stopPropagation()}>
              <OverlayView o={o} postKey={key} editing />
            </div>
          ))}
        </div>
        {!playing && (
          <div className="paused-ic">
            <Icon n="play" size={56} fill />
          </div>
        )}
        <div className="ed-tools" onClick={(e) => e.stopPropagation()}>
          <ToolBtn icon="text" label={t('Текст')} onClick={() => sheet(() => <TextTool onAdd={(o) => (addOverlay(o), closeSheet())} total={total} />, true)} />
          <ToolBtn icon="sticker" label={t('Стикеры')} onClick={() => sheet(() => <StickerTool onAdd={(o) => (addOverlay(o), closeSheet())} />, true)} />
          {post.t !== 'text' && <ToolBtn icon="filter" label={t('Фильтры')} on={panel === 'filters'} onClick={() => setPanel(panel === 'filters' ? '' : 'filters')} />}
          <ToolBtn icon="music" label={t('Звук')} onClick={() => sheet(() => <SoundPicker withTrim current={post.snd} onPick={(snd) => (patch({ snd, ovol: post.t === 'video' && !post.duet ? 0.3 : post.ovol }), closeSheet())} />, true)} />
          {(post.t === 'video' || post.snd) && <ToolBtn icon="volume" label={t('Громкость')} on={panel === 'volume'} onClick={() => setPanel(panel === 'volume' ? '' : 'volume')} />}
          {post.t === 'video' && !isStory && <ToolBtn icon="scissors" label={t('Клипы')} on={panel === 'clips'} onClick={() => setPanel(panel === 'clips' ? '' : 'clips')} />}
          {post.duet && <ToolBtn icon="duet" label={t('Макет')} on={panel === 'layout'} onClick={() => setPanel(panel === 'layout' ? '' : 'layout')} />}
        </div>
      </div>

      {selected && (
        <div className="ed-panel">
          <div className="row gap-s wrap">
            <b className="grow ell">{selected.k === 'poll' ? t('Опрос') : selected.t}</b>
            {selected.k === 'text' && (
              <button className="chip" onClick={() => sheet(() => <TextTool init={selected} total={total} onAdd={(o) => (changeOv(o), closeSheet())} />, true)}>
                <Icon n="edit" size={14} /> {t('Изменить')}
              </button>
            )}
            <button className="chip danger" onClick={() => (setOverlays((post.ov || []).filter((o) => o.id !== selOv)), setSelOv(null))}>
              <Icon n="trash" size={14} /> {t('Удалить')}
            </button>
          </div>
          <label className="range-label">
            {t('Размер')}
            <input id="ov-size" type="range" min={0.3} max={4} step={0.05} value={selected.sc} onChange={(e) => changeOv({ sc: Number(e.target.value) }, false)} onPointerUp={() => changeOv({}, true)} />
          </label>
          <label className="range-label">
            {t('Поворот')}
            <input id="ov-rot" type="range" min={-180} max={180} step={1} value={selected.rot} onChange={(e) => changeOv({ rot: Number(e.target.value) }, false)} onPointerUp={() => changeOv({}, true)} />
          </label>
          {post.t === 'video' && total > 0 && (
            <div className="row gap-s">
              <label className="range-label grow">
                {t('Показ с')} {fmtDur(selected.from ?? 0)}
                <input id="ov-from" type="range" min={0} max={total} step={0.1} value={selected.from ?? 0} onChange={(e) => changeOv({ from: Number(e.target.value) }, false)} onPointerUp={() => changeOv({}, true)} />
              </label>
              <label className="range-label grow">
                {t('до')} {fmtDur(selected.to ?? total)}
                <input id="ov-to" type="range" min={0} max={total} step={0.1} value={selected.to ?? total} onChange={(e) => changeOv({ to: Number(e.target.value) }, false)} onPointerUp={() => changeOv({}, true)} />
              </label>
            </div>
          )}
        </div>
      )}

      {!selected && panel === 'filters' && (
        <div className="ed-panel">
          <div className="hscroll chips">
            {Object.keys(FILTERS).map((f) => (
              <button key={f} className={cx('filter-chip', (post.adj?.f || 'none') === f && 'on')} onClick={() => patch({ adj: { ...(post.adj || {}), f } })}>
                <span className="filter-sw" style={{ filter: FILTERS[f] || undefined }} />
                <small>{t(FILTER_LABELS[f] || f)}</small>
              </button>
            ))}
          </div>
          {(['b', 'c', 's', 'w'] as const).map((k) => (
            <label key={k} className="range-label">
              {k === 'b' ? t('Яркость') : k === 'c' ? t('Контраст') : k === 's' ? t('Насыщенность') : t('Теплота')} {post.adj?.[k] || 0}
              <input id={'adj-' + k} type="range" min={-50} max={50} step={1} value={post.adj?.[k] || 0} onChange={(e) => patch({ adj: { ...(post.adj || {}), [k]: Number(e.target.value) } }, false)} onPointerUp={() => patch({}, true)} />
            </label>
          ))}
        </div>
      )}

      {!selected && panel === 'volume' && (
        <div className="ed-panel">
          {post.t === 'video' && (
            <label className="range-label">
              {t('Оригинальный звук')} {Math.round((post.ovol ?? (post.snd ? 0 : 1)) * 100)}%
              <input id="vol-orig" type="range" min={0} max={1} step={0.05} value={post.ovol ?? (post.snd ? 0 : 1)} onChange={(e) => patch({ ovol: Number(e.target.value) }, false)} onPointerUp={() => patch({}, true)} />
            </label>
          )}
          {post.snd && (
            <label className="range-label">
              {t('Добавленный звук')} {Math.round((post.snd.v ?? 1) * 100)}%
              <input id="vol-snd" type="range" min={0} max={1} step={0.05} value={post.snd.v ?? 1} onChange={(e) => patch({ snd: { ...post.snd!, v: Number(e.target.value) } }, false)} onPointerUp={() => patch({}, true)} />
            </label>
          )}
          {post.snd && (
            <button className="chip danger" onClick={() => patch({ snd: undefined, ovol: 1 })}>
              <Icon n="trash" size={14} /> {t('Убрать звук')}
            </button>
          )}
        </div>
      )}

      {!selected && panel === 'layout' && post.duet && (
        <div className="ed-panel chips">
          {(['lr', 'rl', 'tb', 'pip'] as const).map((l) => (
            <button key={l} className={cx('chip', post.duet!.lay === l && 'on')} onClick={() => patch({ duet: { ...post.duet!, lay: l } })}>
              {l === 'lr' ? t('Слева') : l === 'rl' ? t('Справа') : l === 'tb' ? t('Сверху/снизу') : t('Картинка в картинке')}
            </button>
          ))}
        </div>
      )}

      {!selected && panel === 'clips' && post.t === 'video' && (
        <div className="ed-panel">
          <div className="timeline hscroll">
            {clips.map((x, i) => (
              <button key={i} className={cx('tl-clip', i === sel && 'on')} style={{ flexGrow: clipLen(x) }} onClick={() => (setSel(i), setSeek({ t: offsetOf(i), n: Date.now() }))}>
                <video src={msrc(x.a) + `#t=${x.s}`} muted preload="metadata" playsInline />
                <small>
                  {fmtDur(clipLen(x))}
                  {x.r !== 1 ? ` · ${x.r}x` : ''}
                </small>
              </button>
            ))}
            {!post.duet && S.canUpload && (
              <FilePick id="add-clip" accept="video/*" multiple onFiles={(f) => void addFiles(f, 'video')} className="tl-add">
                <Icon n="plus" />
              </FilePick>
            )}
          </div>
          <div className="tl-cursor">
            <input id="tl-seek" type="range" min={0} max={total || 1} step={0.05} value={Math.min(cur, total)} onChange={(e) => setSeek({ t: Number(e.target.value), n: Date.now() })} />
            <small>
              {fmtDur(cur)} / {fmtDur(total)}
            </small>
          </div>
          {c && (
            <>
              <div className="row gap-s">
                <label className="range-label grow">
                  {t('Начало')} {fmtDur(c.s)}
                  <input id="clip-s" type="range" min={0} max={Math.max(0, c.e - 0.5)} step={0.05} value={c.s} onChange={(e) => setClip({ s: Number(e.target.value) }, false)} onPointerUp={() => setClip({}, true)} />
                </label>
                <label className="range-label grow">
                  {t('Конец')} {fmtDur(c.e)}
                  <input id="clip-e" type="range" min={c.s + 0.5} max={c.d} step={0.05} value={c.e} onChange={(e) => setClip({ e: Number(e.target.value) }, false)} onPointerUp={() => setClip({}, true)} />
                </label>
              </div>
              <div className="chips">
                {SPEEDS.map((s) => (
                  <button key={s} className={cx('chip', c.r === s && 'on')} onClick={() => setClip({ r: s })}>
                    {s}x
                  </button>
                ))}
              </div>
              <div className="chips">
                <button className="chip" onClick={split}>
                  <Icon n="scissors" size={14} /> {t('Разделить')}
                </button>
                <button className="chip" onClick={() => move(-1)} disabled={sel === 0}>
                  ← {t('Влево')}
                </button>
                <button className="chip" onClick={() => move(1)} disabled={sel === clips.length - 1}>
                  {t('Вправо')} →
                </button>
                <button className="chip danger" onClick={removeClip}>
                  <Icon n="trash" size={14} /> {t('Удалить клип')}
                </button>
              </div>
            </>
          )}
        </div>
      )}

      {post.t === 'photo' && !selected && panel === '' && !isStory && (
        <div className="ed-panel">
          <div className="hscroll photo-strip">
            {(post.ph || []).map((a, i) => (
              <div key={a + i} className="strip-item">
                <img src={msrc(a)} alt="" />
                <div className="strip-btns">
                  <button onClick={() => i > 0 && update({ ...post, ph: swapArr(post.ph!, i, i - 1) })} aria-label={t('Влево')}>
                    ‹
                  </button>
                  <button onClick={() => (post.ph!.length > 1 ? update({ ...post, ph: post.ph!.filter((_, j) => j !== i) }) : toast(t('Нужно хотя бы одно фото')))} aria-label={t('Удалить')}>
                    ×
                  </button>
                  <button onClick={() => i < post.ph!.length - 1 && update({ ...post, ph: swapArr(post.ph!, i, i + 1) })} aria-label={t('Вправо')}>
                    ›
                  </button>
                </div>
              </div>
            ))}
            {(post.ph || []).length < 35 && S.canUpload && (
              <FilePick id="add-photo" accept="image/*" multiple onFiles={(f) => void addFiles(f, 'photo')} className="tl-add">
                <Icon n="plus" />
              </FilePick>
            )}
          </div>
        </div>
      )}
      {isStory && (
        <div className="ed-panel">
          <input id="story-caption" className="input" placeholder={t('Подпись к истории')} maxLength={200} value={post.cap} onChange={(e) => patch({ cap: e.target.value }, false)} />
        </div>
      )}
    </div>
  );
}

const FILTER_LABELS: Record<string, string> = { none: 'Без фильтра', vivid: 'Яркий', warm: 'Тёплый', cool: 'Холодный', mono: 'Ч/Б', noir: 'Нуар', vintage: 'Винтаж', fade: 'Пастель', pop: 'Поп', dusk: 'Закат' };

function swapArr<T>(a: T[], i: number, j: number): T[] {
  const b = a.slice();
  [b[i], b[j]] = [b[j], b[i]];
  return b;
}

function ToolBtn({ icon, label, onClick, on }: { icon: string; label: string; onClick: () => void; on?: boolean }): React.ReactElement {
  return (
    <button className={cx('tool-btn', on && 'on')} onClick={onClick}>
      <Icon n={icon} size={22} />
      <small>{label}</small>
    </button>
  );
}

function TextTool({ onAdd, init, total }: { onAdd: (o: Omit<Overlay, 'id' | 'x' | 'y' | 'sc' | 'rot'>) => void; init?: Overlay; total: number }): React.ReactElement {
  const [txt, setTxt] = useState(init?.t || '');
  const [f, setF] = useState(init?.f ?? 1);
  const [c, setC] = useState(init?.c || '#ffffff');
  const [bg, setBg] = useState(init?.bg ?? 0);
  const [al, setAl] = useState<Overlay['al']>(init?.al || 'c');
  const [an, setAn] = useState<Overlay['an']>(init?.an || 'none');
  return (
    <div className="pad col gap">
      <b>{t('Текст')}</b>
      <textarea id="tool-text" className="input" rows={2} maxLength={200} value={txt} onChange={(e) => setTxt(e.target.value)} autoFocus placeholder={t('Введите текст')} style={{ fontFamily: FONTS[f] }} />
      <div className="hscroll chips">
        {FONTS.map((ff, i) => (
          <button key={i} className={cx('chip', f === i && 'on')} style={{ fontFamily: ff }} onClick={() => setF(i)}>
            {FONT_NAMES[i]}
          </button>
        ))}
      </div>
      <div className="hscroll chips">
        {COLORS.map((col) => (
          <button key={col} className={cx('swatch sm', c === col && 'on')} style={{ background: col }} onClick={() => setC(col)} aria-label={col} />
        ))}
      </div>
      <div className="chips">
        {[0, 1, 2].map((b) => (
          <button key={b} className={cx('chip', bg === b && 'on')} onClick={() => setBg(b)}>
            {b === 0 ? t('Без подложки') : b === 1 ? t('Подложка') : t('Полупрозрачная')}
          </button>
        ))}
      </div>
      <div className="chips">
        {(['l', 'c', 'r'] as const).map((a) => (
          <button key={a} className={cx('chip', al === a && 'on')} onClick={() => setAl(a)}>
            {a === 'l' ? t('Слева') : a === 'c' ? t('По центру') : t('Справа')}
          </button>
        ))}
      </div>
      <div className="chips">
        {(['none', 'fade', 'pop', 'slide', 'type'] as const).map((a) => (
          <button key={a} className={cx('chip', an === a && 'on')} onClick={() => setAn(a)}>
            {a === 'none' ? t('Без анимации') : a === 'fade' ? t('Проявление') : a === 'pop' ? t('Всплытие') : a === 'slide' ? t('Выезд') : t('Печать')}
          </button>
        ))}
      </div>
      {total > 0 && <small className="muted">{t('Время показа можно настроить после добавления')}</small>}
      <button className="btn btn-primary" disabled={!txt.trim()} onClick={() => onAdd({ k: 'text', t: txt.trim(), f, c, bg, al, an })}>
        {init ? t('Сохранить') : t('Добавить')}
      </button>
    </div>
  );
}

function StickerTool({ onAdd }: { onAdd: (o: Omit<Overlay, 'id' | 'x' | 'y' | 'sc' | 'rot'>) => void }): React.ReactElement {
  const [tab, setTab] = useState<'emoji' | 'mention' | 'tag' | 'poll'>('emoji');
  const [q, setQ] = useState('');
  const [opts, setOpts] = useState(['', '']);
  return (
    <div className="pad col gap">
      <Tabs value={tab} onChange={setTab} items={[['emoji', t('Эмодзи')], ['mention', '@'], ['tag', '#'], ['poll', t('Опрос')]]} />
      {tab === 'emoji' && (
        <div className="emoji-grid">
          {EMOJIS.map((e) => (
            <button key={e} onClick={() => onAdd({ k: 'emoji', t: e })}>
              {e}
            </button>
          ))}
        </div>
      )}
      {tab === 'mention' && (
        <>
          <input id="st-mention" className="input" placeholder={t('Поиск пользователя')} value={q} onChange={(e) => setQ(e.target.value)} />
          {searchUsers(q, 8).map((u) => (
            <button key={u} className="mention-item" onClick={() => onAdd({ k: 'mention', t: '@' + S.u[u].un, u })}>
              <Avatar uid={u} size={28} /> <span>{S.u[u].nm}</span> <small className="muted">@{S.u[u].un}</small>
            </button>
          ))}
        </>
      )}
      {tab === 'tag' && (
        <>
          <input id="st-tag" className="input" placeholder="#" value={q} onChange={(e) => setQ(e.target.value.replace(/\s/g, ''))} />
          <button className="btn btn-primary" disabled={!q.replace('#', '')} onClick={() => onAdd({ k: 'tag', t: '#' + q.replace(/^#/, '') })}>
            {t('Добавить')}
          </button>
          {searchTags(q, 6).map((x) => (
            <button key={x.tag} className="menu-item" onClick={() => onAdd({ k: 'tag', t: '#' + x.tag })}>
              #{x.tag} <small className="muted">{fmtCount(x.views)} {t('просмотров')}</small>
            </button>
          ))}
        </>
      )}
      {tab === 'poll' && (
        <>
          <input id="st-poll-q" className="input" placeholder={t('Вопрос')} maxLength={80} value={q} onChange={(e) => setQ(e.target.value)} />
          {opts.map((o, i) => (
            <input key={i} id={'st-poll-' + i} className="input" placeholder={t('Вариант {n}', { n: i + 1 })} maxLength={40} value={o} onChange={(e) => setOpts(opts.map((x, j) => (j === i ? e.target.value : x)))} />
          ))}
          {opts.length < 4 && (
            <button className="chip" onClick={() => setOpts([...opts, ''])}>
              + {t('Вариант')}
            </button>
          )}
          <button className="btn btn-primary" disabled={!q.trim() || opts.filter((o) => o.trim()).length < 2} onClick={() => onAdd({ k: 'poll', t: q.trim(), o: opts.map((o) => o.trim()).filter(Boolean) })}>
            {t('Добавить опрос')}
          </button>
        </>
      )}
    </div>
  );
}

// ---------- publish ----------
function PublishStep({ post, patch, cover, setCover, onBack, onPublish, media }: { post: Post; patch: (c: Partial<Post>, r?: boolean) => void; cover: { time: number; text: string }; setCover: (c: { time: number; text: string }) => void; onBack: () => void; onPublish: (draft: boolean) => void; media: Record<string, LocalMedia> }): React.ReactElement {
  const ta = useRef<HTMLTextAreaElement | null>(null);
  const [caret, setCaret] = useState(0);
  const [schedule, setSchedule] = useState(!!post.at);
  const before = post.cap.slice(0, caret);
  const m = /([#@])([\p{L}\p{N}_]*)$/u.exec(before);
  const c0 = post.clips?.[0];
  const coverMax = c0 ? Math.max(0.1, c0.e - c0.s) : 0;
  const insert = (token: string): void => {
    if (!m) return;
    const start = caret - m[0].length;
    const cap = post.cap.slice(0, start) + token + ' ' + post.cap.slice(caret);
    patch({ cap: cap.slice(0, 4000) }, false);
    setTimeout(() => {
      ta.current?.focus();
      const pos = start + token.length + 1;
      ta.current?.setSelectionRange(pos, pos);
      setCaret(pos);
    }, 0);
  };
  const saveLocal = async (): Promise<void> => {
    const files = Object.values(media).filter((x) => x.file);
    if (!files.length) return toast(t('Нет локальных файлов для сохранения'));
    for (const f of files) if (!(await saveFile(f.file!.name || 'media', f.file!))) break;
  };
  return (
    <div className="screen publish">
      <Header title={t('Публикация')} onBack={onBack} />
      <div className="scroll pad col gap">
        <div className="pub-top">
          <div className="pub-caption">
            <textarea
              ref={ta}
              id="pub-caption"
              className="input"
              rows={5}
              maxLength={4000}
              placeholder={t('Опишите публикацию… #хэштеги @упоминания')}
              value={post.cap}
              onChange={(e) => (patch({ cap: e.target.value }, false), setCaret(e.target.selectionStart))}
              onSelect={(e) => setCaret(e.currentTarget.selectionStart)}
            />
            <small className="muted right">{post.cap.length}/4000</small>
          </div>
          <div className="pub-cover">
            {post.t === 'video' && c0 ? (
              <CoverFrame src={msrc(c0.a)} time={c0.s + cover.time} text={cover.text} filter={filterCss(post.adj)} />
            ) : post.t === 'photo' ? (
              <img src={msrc(post.ph?.[0])} alt="" style={{ filter: filterCss(post.adj) || undefined }} />
            ) : (
              <div className="thumb-text" style={{ background: post.txt?.bg, color: post.txt?.c, fontFamily: FONTS[post.txt?.f || 0] }}>
                {post.cap.slice(0, 60)}
              </div>
            )}
          </div>
        </div>
        {m && (
          <div className="suggest">
            {m[1] === '#'
              ? searchTags(m[2], 6).map((x) => (
                  <button key={x.tag} className="menu-item" onClick={() => insert('#' + x.tag)}>
                    <Icon n="hash" size={18} /> <span className="grow">#{x.tag}</span> <small className="muted">{fmtCount(x.views)} {t('просмотров')}</small>
                  </button>
                ))
              : searchUsers(m[2], 6).map((u) => (
                  <button key={u} className="menu-item" onClick={() => insert('@' + S.u[u].un)}>
                    <Avatar uid={u} size={28} /> <span className="grow">{S.u[u].nm}</span> <small className="muted">@{S.u[u].un}</small>
                  </button>
                ))}
          </div>
        )}
        {post.t === 'video' && c0 && (
          <div className="card col gap-s">
            <b>{t('Обложка')}</b>
            <input id="cover-time" type="range" min={0} max={coverMax} step={0.05} value={cover.time} onChange={(e) => setCover({ ...cover, time: Number(e.target.value) })} />
            <input id="cover-text" className="input" placeholder={t('Текст на обложке')} maxLength={60} value={cover.text} onChange={(e) => setCover({ ...cover, text: e.target.value })} />
          </div>
        )}
        {post.t === 'photo' && (
          <div className="card col gap-s">
            <b>{t('Текст на обложке')}</b>
            <input id="cover-text-p" className="input" placeholder={t('Необязательно')} maxLength={60} value={cover.text} onChange={(e) => setCover({ ...cover, text: e.target.value })} />
          </div>
        )}
        <div className="card">
          <div className="row">
            <Icon n="globe" size={20} />
            <span className="grow">{t('Кто может смотреть')}</span>
            <select id="pub-priv" className="select" value={post.priv} onChange={(e) => patch({ priv: e.target.value as Post['priv'] })}>
              <option value="all">{t('Все')}</option>
              <option value="friends">{t('Друзья')}</option>
              <option value="me">{t('Только я')}</option>
            </select>
          </div>
          <Toggle id="pub-cm" label={t('Разрешить комментарии')} on={post.cm} onChange={(v) => patch({ cm: v })} />
          {post.t === 'video' && <Toggle id="pub-du" label={t('Разрешить дуэт')} on={post.du} onChange={(v) => patch({ du: v })} />}
          {post.t === 'video' && <Toggle id="pub-stc" label={t('Разрешить стежок')} on={post.stc} onChange={(v) => patch({ stc: v })} />}
          <Toggle id="pub-dl" label={t('Разрешить скачивание')} on={post.dl} onChange={(v) => patch({ dl: v })} />
        </div>
        <div className="card col gap-s">
          <label className="row" htmlFor="pub-loc">
            <Icon n="location" size={20} />
            <input id="pub-loc" className="input grow" placeholder={t('Добавить место')} maxLength={60} value={post.loc || ''} onChange={(e) => patch({ loc: e.target.value }, false)} />
          </label>
          <TagPeople value={post.tags || []} onChange={(tags) => patch({ tags })} />
        </div>
        <div className="card col gap-s">
          <Toggle id="pub-sched" label={t('Отложенная публикация')} on={schedule} onChange={(v) => (setSchedule(v), patch({ at: v ? Date.now() + 3600000 : undefined }))} />
          {schedule && (
            <input
              id="pub-at"
              type="datetime-local"
              className="input"
              value={toLocalInput(post.at || Date.now() + 3600000)}
              min={toLocalInput(Date.now() + 60000)}
              onChange={(e) => patch({ at: new Date(e.target.value).getTime() })}
            />
          )}
        </div>
        <button className="btn btn-muted" onClick={() => void saveLocal()}>
          <Icon n="download" size={18} /> {t('Сохранить на устройство')}
        </button>
      </div>
      <div className="pub-bar">
        <button className="btn btn-muted grow" onClick={() => onPublish(true)}>
          {t('Черновик')}
        </button>
        <button className="btn btn-primary grow" onClick={() => onPublish(false)}>
          {post.at && post.at > Date.now() ? t('Запланировать') : t('Опубликовать')}
        </button>
      </div>
    </div>
  );
}

function toLocalInput(ts: number): string {
  const d = new Date(ts - new Date().getTimezoneOffset() * 60000);
  return d.toISOString().slice(0, 16);
}

function CoverFrame({ src, time, text, filter }: { src: string; time: number; text: string; filter: string }): React.ReactElement {
  const v = useRef<HTMLVideoElement | null>(null);
  useEffect(() => {
    if (v.current) v.current.currentTime = time;
  }, [time]);
  return (
    <div className="cover-frame">
      <video ref={v} src={src} muted playsInline preload="auto" style={{ filter: filter || undefined }} />
      {text && <span className="cover-text">{text}</span>}
    </div>
  );
}

function TagPeople({ value, onChange }: { value: string[]; onChange: (v: string[]) => void }): React.ReactElement {
  const [q, setQ] = useState('');
  return (
    <div className="col gap-s">
      <label className="row" htmlFor="pub-tag">
        <Icon n="user" size={20} />
        <input id="pub-tag" className="input grow" placeholder={t('Отметить людей')} value={q} onChange={(e) => setQ(e.target.value)} />
      </label>
      {value.length > 0 && (
        <div className="chips">
          {value.map((u) => (
            <button key={u} className="chip on" onClick={() => onChange(value.filter((x) => x !== u))}>
              @{S.u[u]?.un} ×
            </button>
          ))}
        </div>
      )}
      {q &&
        searchUsers(q, 5)
          .filter((u) => !value.includes(u) && u !== S.uid)
          .map((u) => (
            <button key={u} className="mention-item" onClick={() => (onChange([...value, u].slice(0, 20)), setQ(''))}>
              <Avatar uid={u} size={28} /> <span>{S.u[u].nm}</span> <small className="muted">@{S.u[u].un}</small>
            </button>
          ))}
    </div>
  );
}

/** Edit an existing post: caption, cover text, privacy and permissions. */
export function EditPostScreen({ postKey }: { postKey: string }): React.ReactElement {
  useStore();
  const p = getPost(postKey);
  const [cap, setCap] = useState(p?.cap || '');
  const [priv, setPriv] = useState<Post['priv']>(p?.priv || 'all');
  const [flags, setFlags] = useState({ cm: p?.cm ?? true, du: p?.du ?? true, stc: p?.stc ?? true, dl: p?.dl ?? true });
  const [coverT, setCoverT] = useState(0);
  const [coverText, setCoverText] = useState('');
  const [busy, setBusy] = useState(false);
  if (!p) return <div className="screen"><Header title={t('Редактировать')} /><Empty title={t('Публикация недоступна')} /></div>;
  const c0 = p.clips?.[0];
  const saveIt = async (): Promise<void> => {
    setBusy(true);
    try {
      const ch: Partial<Post> = { cap, priv, ...flags };
      if (c0 && (coverT > 0 || coverText)) {
        ch.poster = (await upload(await captureFrame(msrc(c0.a), c0.s + coverT, 720, coverText || undefined))).id;
      }
      await updatePost(p.id, ch);
      toast(t('Сохранено'));
      popScreen();
    } catch (e) {
      errToast(e);
    } finally {
      setBusy(false);
    }
  };
  return (
    <div className="screen publish">
      <Header title={t('Редактировать')} right={<button className="btn btn-primary btn-sm" disabled={busy} onClick={() => void saveIt()}>{t('Сохранить')}</button>} />
      <div className="scroll pad col gap">
        <textarea id="edit-cap" className="input" rows={5} maxLength={4000} value={cap} onChange={(e) => setCap(e.target.value)} />
        {c0 && S.canUpload && (
          <div className="card col gap-s">
            <b>{t('Новая обложка')}</b>
            <CoverFrame src={msrc(c0.a)} time={c0.s + coverT} text={coverText} filter={filterCss(p.adj)} />
            <input id="edit-cover-t" type="range" min={0} max={Math.max(0.1, c0.e - c0.s)} step={0.05} value={coverT} onChange={(e) => setCoverT(Number(e.target.value))} />
            <input id="edit-cover-text" className="input" placeholder={t('Текст на обложке')} value={coverText} onChange={(e) => setCoverText(e.target.value)} />
          </div>
        )}
        <div className="card">
          <div className="row">
            <span className="grow">{t('Кто может смотреть')}</span>
            <select id="edit-priv" className="select" value={priv} onChange={(e) => setPriv(e.target.value as Post['priv'])}>
              <option value="all">{t('Все')}</option>
              <option value="friends">{t('Друзья')}</option>
              <option value="me">{t('Только я')}</option>
            </select>
          </div>
          <Toggle id="edit-cm" label={t('Разрешить комментарии')} on={flags.cm} onChange={(v) => setFlags({ ...flags, cm: v })} />
          {p.t === 'video' && <Toggle id="edit-du" label={t('Разрешить дуэт')} on={flags.du} onChange={(v) => setFlags({ ...flags, du: v })} />}
          {p.t === 'video' && <Toggle id="edit-stc" label={t('Разрешить стежок')} on={flags.stc} onChange={(v) => setFlags({ ...flags, stc: v })} />}
          <Toggle id="edit-dl" label={t('Разрешить скачивание')} on={flags.dl} onChange={(v) => setFlags({ ...flags, dl: v })} />
        </div>
      </div>
    </div>
  );
}

export function DraftsScreen(): React.ReactElement {
  useStore();
  const drafts = Object.values(S.me.drafts || {}).filter(Boolean).sort((a, b) => b.ts - a.ts);
  return (
    <div className="screen">
      <Header title={t('Черновики')} />
      <div className="scroll">
        {drafts.length === 0 && <Empty icon="file" title={t('Черновиков нет')} text={t('Сохраняйте публикации в черновики на экране публикации')} />}
        <div className="grid3">
          {drafts.map((d) => (
            <div key={d.id} className="thumb tap" onClick={() => go('create', { draft: d.id })}>
              {d.post.poster || d.post.ph?.[0] ? <img src={msrc(d.post.poster || d.post.ph?.[0])} alt="" /> : <div className="thumb-text" style={{ background: d.post.txt?.bg }}>{d.post.cap.slice(0, 40) || t('Видео')}</div>}
              <span className="thumb-badge">{new Date(d.ts).toLocaleDateString()}</span>
              <button className="thumb-del" onClick={(e) => (e.stopPropagation(), void confirmDialog(t('Удалить черновик?'), t('Удалить')).then((ok) => ok && void deleteDraft(d.id)))} aria-label={t('Удалить')}>
                <Icon n="trash" size={16} />
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
