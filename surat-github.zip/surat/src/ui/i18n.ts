import { S } from '../core/store';
import type { Lang } from '../core/types';
import { lsGet } from '../core/util';
import { DICT } from './dict';

let override: Lang | null = null;
export function setLangOverride(l: Lang | null): void {
  override = l;
}
export function lang(): Lang {
  return override || S.me.set?.lang || lsGet<Lang | null>('lang', null) || defaultLang;
}
let defaultLang: Lang = 'ru';
export function setDefaultLang(l: Lang): void {
  defaultLang = l;
}

/** Translate a Russian source string. `{x}` placeholders are filled from vars. */
export function t(ru: string, vars?: Record<string, string | number>): string {
  const l = lang();
  let s = ru;
  if (l !== 'ru') {
    const e = DICT[ru];
    if (e) s = (l === 'en' ? e[0] : e[1] || e[0]) || ru;
  }
  if (vars) s = s.replace(/\{(\w+)\}/g, (_, k: string) => String(vars[k] ?? ''));
  return s;
}

export function plural(n: number, forms: [string, string, string]): string {
  const l = lang();
  if (l !== 'ru') return t(forms[0]);
  const a = Math.abs(n) % 100;
  const b = a % 10;
  if (a > 10 && a < 20) return forms[2];
  if (b > 1 && b < 5) return forms[1];
  if (b === 1) return forms[0];
  return forms[2];
}

export function timeAgo(ts: number): string {
  const d = (Date.now() - ts) / 1000;
  const l = lang();
  const u = (ru: string, en: string, uz: string): string => (l === 'en' ? en : l === 'uz' ? uz : ru);
  if (d < 0) return new Date(ts).toLocaleString(l);
  if (d < 60) return u('сейчас', 'now', 'hozir');
  if (d < 3600) return Math.floor(d / 60) + u(' мин', 'm', ' daq');
  if (d < 86400) return Math.floor(d / 3600) + u(' ч', 'h', ' soat');
  if (d < 86400 * 7) return Math.floor(d / 86400) + u(' д', 'd', ' kun');
  return new Date(ts).toLocaleDateString(l === 'uz' ? 'uz-UZ' : l, { day: 'numeric', month: 'short' });
}
