import React, { useEffect, useRef, useState } from 'react';
import { countShare, notInterested, report, repost, AppError } from '../core/actions';
import { agg, friendsOf, getPost, searchUsers, type PostX } from '../core/derive';
import { openDirect, send } from '../core/dm';
import { recorderSupported, transcode, watermarkImage } from '../core/media';
import { S, useStore } from '../core/store';
import { cx, has } from '../core/util';
import { saveFile } from '../core/caps';
import { cfg, shareLink } from './config';
import { t } from './i18n';
import { Icon } from './icons';
import { act, Avatar, errToast, MenuItem } from './kit';
import { closeAllSheets, closeSheet, sheet, toast } from './nav';
import { msrc, filterCss } from './player';

declare const QRCode: undefined | (new (el: HTMLElement, o: { text: string; width: number; height: number; colorDark?: string; colorLight?: string }) => unknown);

export async function copyText(text: string): Promise<void> {
  try {
    await navigator.clipboard.writeText(text);
    toast(t('Ссылка скопирована'));
  } catch {
    sheet(() => (
      <div className="pad">
        <b>{t('Скопируйте ссылку')}</b>
        <input className="input" readOnly value={text} onFocus={(e) => e.currentTarget.select()} autoFocus />
      </div>
    ));
  }
}

export function QrSheet({ text, title }: { text: string; title: string }): React.ReactElement {
  const box = useRef<HTMLDivElement | null>(null);
  useEffect(() => {
    if (box.current && typeof QRCode !== 'undefined') {
      box.current.innerHTML = '';
      new QRCode(box.current, { text, width: 220, height: 220, colorDark: '#111111', colorLight: '#ffffff' });
    }
  }, [text]);
  return (
    <div className="pad center col gap">
      <b>{title}</b>
      <div className="qr" ref={box} />
      <small className="muted ell" style={{ maxWidth: '100%' }}>{text}</small>
      <button className="btn btn-muted" onClick={() => void copyText(text)}>
        {t('Скопировать ссылку')}
      </button>
    </div>
  );
}

export async function downloadPost(p: PostX): Promise<void> {
  const mark = `${cfg.watermark} @${S.u[p.by]?.un || ''}`;
  if (p.t === 'video' && p.clips?.length) {
    if (!recorderSupported()) {
      toast(t('Ваш браузер не умеет сохранять видео с водяным знаком'));
      return;
    }
    toast(t('Готовим видео с водяным знаком… это займёт столько же, сколько длится видео'));
    try {
      const out = await transcode(
        p.clips.map((c) => ({ src: msrc(c.a), s: c.s, e: c.e, r: c.r })),
        { watermark: mark, filter: filterCss(p.adj) || undefined },
      );
      const ext = out.type.includes('mp4') ? 'mp4' : 'webm';
      if (await saveFile(`${cfg.name.toLowerCase()}-${p.id}.${ext}`, out)) toast(t('Видео сохранено'));
    } catch {
      toast(t('Не удалось подготовить видео'));
    }
    return;
  }
  const imgs = p.t === 'photo' ? p.ph || [] : p.poster ? [p.poster] : [];
  for (let i = 0; i < imgs.length; i++) {
    try {
      const b = await watermarkImage(msrc(imgs[i]), mark);
      if (!(await saveFile(`${cfg.name.toLowerCase()}-${p.id}-${i + 1}.jpg`, b))) break;
    } catch {
      toast(t('Не удалось сохранить фото'));
      break;
    }
  }
}

export function canDownload(p: PostX): boolean {
  return p.by === S.uid || (p.dl !== false && S.u[p.by]?.dl !== false);
}

export function ShareSheet({ postKey }: { postKey: string }): React.ReactElement {
  useStore();
  const p = getPost(postKey);
  const [q, setQ] = useState('');
  const [sent, setSent] = useState<Record<string, boolean>>({});
  if (!p) return <div className="pad">{t('Публикация недоступна')}</div>;
  const me = S.uid;
  const people = q ? searchUsers(q, 20).filter((u) => u !== me) : [...new Set([...friendsOf(me || ''), ...(me ? agg().following.get(me) || [] : [])])].slice(0, 20);
  const link = shareLink('post-' + p.id);
  const reposted = me ? has(S.g[me]?.rp, postKey) : false;
  const sendTo = async (uid: string): Promise<void> => {
    try {
      const cid = await openDirect(uid);
      await send(cid, { k: 'post', p: postKey });
      setSent((s) => ({ ...s, [uid]: true }));
      void countShare(postKey);
    } catch (e) {
      errToast(e);
    }
  };
  return (
    <div className="share">
      <div className="pad-x">
        <b className="sheet-title">{t('Отправить')}</b>
        <input className="input" placeholder={t('Поиск друзей')} value={q} onChange={(e) => setQ(e.target.value)} id="share-search" />
      </div>
      <div className="hscroll share-people">
        {people.length === 0 && <span className="muted pad-x">{t('Подпишитесь на кого-нибудь, чтобы делиться')}</span>}
        {people.map((uid) => (
          <button key={uid} className="share-person" onClick={() => !sent[uid] && void sendTo(uid)}>
            <Avatar uid={uid} size={52} />
            <span className="ell">{S.u[uid]?.nm || S.u[uid]?.un}</span>
            <small className={cx(sent[uid] && 'accent')}>{sent[uid] ? t('Отправлено') : t('Отправить')}</small>
          </button>
        ))}
      </div>
      <div className="share-actions hscroll">
        <ShareAct icon="link" label={t('Ссылка')} onClick={() => (void copyText(link), void countShare(postKey))} />
        <ShareAct icon="repost" label={reposted ? t('Убрать репост') : t('Репост')} on={reposted} onClick={() => void act(() => repost(postKey, !reposted), reposted ? t('Репост удалён') : t('Репост добавлен в профиль'))} />
        {canDownload(p) && <ShareAct icon="download" label={t('Скачать')} onClick={() => (closeSheet(), void downloadPost(p), void countShare(postKey))} />}
        <ShareAct icon="qr" label="QR" onClick={() => sheet(() => <QrSheet text={link} title={t('QR-код публикации')} />)} />
        {p.by !== me && <ShareAct icon="eyeoff" label={t('Не интересно')} onClick={() => void act(() => notInterested(postKey), t('Будем показывать меньше похожего')).then(closeAllSheets)} />}
        {p.by !== me && <ShareAct icon="flag" label={t('Пожаловаться')} onClick={() => sheet(() => <ReportSheet k="post" id={postKey} />)} />}
      </div>
    </div>
  );
}

function ShareAct({ icon, label, onClick, on }: { icon: string; label: string; onClick: () => void; on?: boolean }): React.ReactElement {
  return (
    <button className={cx('share-act', on && 'on')} onClick={onClick}>
      <span className="share-act-ic">
        <Icon n={icon} />
      </span>
      <small>{label}</small>
    </button>
  );
}

export const REASONS = ['Спам', 'Насилие или опасные действия', 'Оскорбления и травля', 'Нагота или откровенный контент', 'Ложная информация', 'Мошенничество', 'Нарушение авторских прав', 'Пропаганда ненависти', 'Вред несовершеннолетним', 'Другое'];

export function ReportSheet({ k, id }: { k: 'post' | 'comment' | 'user' | 'msg' | 'story'; id: string }): React.ReactElement {
  const [why, setWhy] = useState<string | null>(null);
  const [note, setNote] = useState('');
  if (!why)
    return (
      <div>
        <b className="sheet-title pad-x">{t('Причина жалобы')}</b>
        {REASONS.map((r) => (
          <MenuItem key={r} label={t(r)} onClick={() => setWhy(r)} />
        ))}
      </div>
    );
  return (
    <div className="pad col gap">
      <b>{t(why)}</b>
      <textarea className="input" rows={3} maxLength={400} placeholder={t('Подробности (необязательно)')} value={note} onChange={(e) => setNote(e.target.value)} id="report-note" />
      <button
        className="btn btn-primary"
        onClick={() =>
          void act(async () => {
            if (S.readOnly) throw new AppError('readonly');
            await report({ k, id, why, note: note.trim() || undefined });
          }, t('Жалоба отправлена. Спасибо!')).then((ok) => ok && closeAllSheets())
        }
      >
        {t('Отправить жалобу')}
      </button>
    </div>
  );
}
