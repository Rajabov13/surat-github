import { useEffect, useReducer } from 'react';
import { caps, loadCaps, type DocRef } from './caps';
import type {
  CommentsDoc,
  ConvDoc,
  Graph,
  Me,
  ModCfg,
  MsgIndexDoc,
  PostsDoc,
  PrivPosts,
  Profile,
  Rec,
  ReportsDoc,
  StoriesDoc,
  ViewsDoc,
} from './types';

export const COLLS = ['u', 'g', 'p', 'c', 'v', 's', 'cv', 'ms'] as const;
export type Coll = (typeof COLLS)[number];

export interface Peer {
  uid: string;
  typing?: string | null;
}

export interface State {
  phase: 'boot' | 'nocaps' | 'signedout' | 'loading' | 'ready';
  uid: string | null;
  isOwner: boolean;
  readOnly: boolean;
  canUpload: boolean;
  u: Rec<Profile>;
  g: Rec<Graph>;
  p: Rec<PostsDoc>;
  c: Rec<CommentsDoc>;
  v: Rec<ViewsDoc>;
  s: Rec<StoriesDoc>;
  cv: Rec<ConvDoc>;
  ms: Rec<MsgIndexDoc>;
  me: Me;
  priv: PrivPosts;
  mod: ModCfg;
  reports: Rec<ReportsDoc>;
  online: Rec<Peer>;
  loaded: Rec<boolean>;
  stale: boolean;
  ver: number;
}

export const S: State = {
  phase: 'boot',
  uid: null,
  isOwner: false,
  readOnly: true,
  canUpload: false,
  u: {},
  g: {},
  p: {},
  c: {},
  v: {},
  s: {},
  cv: {},
  ms: {},
  me: {},
  priv: {},
  mod: {},
  reports: {},
  online: {},
  loaded: {},
  stale: false,
  ver: 0,
};

const listeners = new Set<() => void>();
let scheduled = false;
export function bump(): void {
  S.ver++;
  if (scheduled) return;
  scheduled = true;
  requestAnimationFrame(() => {
    scheduled = false;
    listeners.forEach((l) => l());
  });
}
export function subscribe(fn: () => void): () => void {
  listeners.add(fn);
  return () => listeners.delete(fn);
}
/** Re-render the calling component on every store change. */
export function useStore(): State {
  const [, force] = useReducer((x: number) => x + 1, 0);
  useEffect(() => subscribe(force), []);
  return S;
}

// ---------- write queue: one write at a time per document ----------
const chains: Rec<Promise<unknown>> = {};
export function queued<T>(path: string, fn: () => Promise<T>): Promise<T> {
  const prev = chains[path] || Promise.resolve();
  const next = prev.catch(() => undefined).then(fn);
  chains[path] = next;
  return next;
}

export function ref(path: string): DocRef {
  if (!caps.db) throw new Error('no db');
  return caps.db.doc(path);
}
export function myRef(coll: Coll): DocRef {
  return ref(`${coll}/${S.uid}`);
}
export const mePath = (): string => `data/users/${S.uid}/me`;
export const privPath = (): string => `data/users/${S.uid}/priv`;

/** Merge-write into one of my per-user documents. */
export function patch(coll: Coll, data: Record<string, unknown>): Promise<void> {
  const path = `${coll}/${S.uid}`;
  return queued(path, () => ref(path).update(data));
}
export function setDoc(path: string, data: Record<string, unknown>): Promise<void> {
  return queued(path, () => ref(path).set(data));
}
export function patchMe(data: Record<string, unknown>): Promise<void> {
  const path = mePath();
  return queued(path, async () => {
    try {
      await ref(path).update(data);
    } catch {
      await ref(path).set({ ...(S.me as Record<string, unknown>), ...data });
    }
  });
}

// ---------- boot ----------
const unsubs: (() => void)[] = [];
let staleTimer = 0;

export async function boot(): Promise<void> {
  await loadCaps();
  if (!caps.db) {
    S.phase = window.claude ? 'signedout' : 'nocaps';
    bump();
    return;
  }
  const uid = caps.user ? await caps.user.id() : null;
  S.uid = uid;
  S.isOwner = caps.user ? await caps.user.isOwner() : false;
  S.canUpload = !!caps.assets;
  S.readOnly = !uid;
  S.phase = 'loading';
  bump();

  const db = caps.db;
  staleTimer = window.setTimeout(() => {
    S.stale = true;
    if (S.phase === 'loading') S.phase = 'ready';
    bump();
  }, 10000);

  const markLoaded = (k: string, fromCache: boolean): void => {
    if (!fromCache && !S.loaded[k]) {
      S.loaded[k] = true;
      const all = COLLS.every((c) => S.loaded[c]) && (!uid || S.loaded.me);
      if (all) {
        clearTimeout(staleTimer);
        S.stale = false;
        S.phase = 'ready';
      }
    }
  };

  for (const coll of COLLS) {
    unsubs.push(
      db.collection(coll).onSnapshot(
        (snap) => {
          const m: Rec<unknown> = {};
          for (const d of snap.docs) if (d.exists) m[d.id] = d.data();
          (S as unknown as Rec<unknown>)[coll] = m;
          markLoaded(coll, snap.metadata.fromCache);
          bump();
        },
        (e) => {
          console.warn('subscription', coll, e.code);
          S.loaded[coll] = true;
          bump();
        },
      ),
    );
  }
  unsubs.push(
    db.doc('mod/cfg').onSnapshot(
      (d) => {
        S.mod = (d.data() as ModCfg) || {};
        bump();
      },
      () => undefined,
    ),
  );
  if (uid) {
    unsubs.push(
      db.doc(`data/users/${uid}/me`).onSnapshot(
        (d) => {
          S.me = (d.data() as Me) || {};
          markLoaded('me', d.metadata.fromCache);
          bump();
        },
        () => {
          S.loaded.me = true;
          bump();
        },
      ),
    );
    unsubs.push(
      db.doc(`data/users/${uid}/priv`).onSnapshot(
        (d) => {
          S.priv = (d.data() as PrivPosts) || {};
          bump();
        },
        () => undefined,
      ),
    );
    if (S.isOwner) {
      unsubs.push(
        db.collection('rep').onSnapshot(
          (snap) => {
            const m: Rec<ReportsDoc> = {};
            for (const d of snap.docs) if (d.exists) m[d.id] = d.data() as ReportsDoc;
            S.reports = m;
            bump();
          },
          () => undefined,
        ),
      );
    }
  }
  startPresence();
}

// ---------- presence (online + typing) through the room capability ----------
function startPresence(): void {
  const room = caps.room;
  if (!room) return;
  try {
    room.onPeers((ch) => {
      const m: Rec<Peer> = {};
      for (const p of ch.peers) {
        const uid = p.by || (typeof p.presence.uid === 'string' ? p.presence.uid : null);
        if (!uid) continue;
        const typing = typeof p.presence.typing === 'string' ? p.presence.typing : null;
        const prev = m[uid];
        m[uid] = { uid, typing: typing || prev?.typing || null };
      }
      S.online = m;
      bump();
    });
    if (S.uid) void room.presence({ uid: S.uid }).catch(() => undefined);
  } catch {
    /* room unavailable */
  }
}
export function setTyping(cid: string | null): void {
  if (!caps.room) return;
  void caps.room.presence({ typing: cid }).catch(() => undefined);
}

// ---------- per-conversation subscriptions (messages) ----------
export const convDocs: Rec<Rec<import('./types').ConvMsgsDoc>> = {};
export function watchConv(cid: string, members: string[]): () => void {
  const db = caps.db;
  if (!db) return () => undefined;
  const offs = members.map((m) =>
    db.doc(`ms/${m}/c/${cid}`).onSnapshot(
      (d) => {
        (convDocs[cid] = convDocs[cid] || {})[m] = (d.data() as import('./types').ConvMsgsDoc) || {};
        bump();
      },
      () => undefined,
    ),
  );
  return () => offs.forEach((o) => o());
}
