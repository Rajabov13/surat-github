// Shared data model. Every shared collection holds ONE document per user (doc id = user id),
// writable only by that user (db rules use {self}); the artifact owner can moderate.

export type Ts = number;
export type Rec<T> = Record<string, T>;
export type Audience = 'all' | 'friends' | 'none';
export type Privacy = 'all' | 'friends' | 'me';

export interface Profile {
  un: string; // username, unique, [a-z0-9_]
  nm: string; // display name
  bio?: string;
  av?: string; // avatar asset id
  avv?: boolean; // avatar is a video
  link?: string;
  ig?: string;
  yt?: string;
  priv?: boolean; // private account
  pk?: JsonWebKey; // public ECDH key for encrypted messages
  ts: Ts; // joined
  unAt?: Ts; // last username change
  pins?: string[]; // pinned post ids (max 3)
  hideLikes?: boolean;
  hideFollowing?: boolean;
  dm?: Audience; // who can message me
  cmt?: Audience; // who can comment
  duet?: Audience; // who can duet / stitch
  dl?: boolean; // allow downloads of my videos
  pvOff?: boolean; // profile view history off
  actOff?: boolean; // hide activity status
  sw?: string[]; // comment stop-words
  lang?: string;
  del?: boolean; // account deleted
}

export interface Graph {
  fol?: Rec<Ts>; // following (0 = removed)
  acc?: Rec<Ts>; // approved follow requests (private accounts)
  rmv?: Rec<Ts>; // removed followers
  blk?: Rec<Ts>; // blocked users
  lk?: Rec<Ts>; // liked post keys "author~pid"
  sv?: Rec<Ts>; // saved post keys
  rp?: Rec<Ts>; // reposted post keys
  cl?: Rec<Ts>; // liked comment keys "author~cid"
  pl?: Rec<number>; // poll votes: "author~pid" -> option index + 1
  sh?: Rec<number>; // shares count per post key
}

export interface Clip {
  a: string; // asset id
  s: number; // trim start (s)
  e: number; // trim end (s)
  r: number; // playback rate
  d: number; // source duration
}

export type OverlayKind = 'text' | 'emoji' | 'mention' | 'tag' | 'poll';
export interface Overlay {
  id: string;
  k: OverlayKind;
  t: string;
  x: number; // 0..1 centre
  y: number;
  sc: number;
  rot: number; // degrees
  c?: string; // colour
  bg?: number; // 0 none, 1 solid, 2 translucent
  f?: number; // font index
  al?: 'l' | 'c' | 'r';
  an?: 'none' | 'fade' | 'pop' | 'slide' | 'type';
  from?: number; // show from (s), on the edited timeline
  to?: number;
  o?: string[]; // poll options
  u?: string; // mentioned user id
}

export interface Adjust {
  f?: string; // preset filter id
  b?: number; // brightness -50..50
  c?: number; // contrast
  s?: number; // saturation
  w?: number; // warmth
}

export interface SoundRef {
  k: 'p' | 's'; // origin: a post's original sound or an uploaded track
  id: string; // post id / track id
  au: string; // author uid of the origin
  st?: number; // start offset (s)
  v?: number; // volume 0..1
}

export type PostType = 'video' | 'photo' | 'text';
export interface Post {
  id: string;
  by: string;
  t: PostType;
  ts: Ts;
  at?: Ts; // scheduled publish time
  ed?: Ts;
  cap: string;
  clips?: Clip[];
  ph?: string[]; // photo asset ids
  poster?: string; // cover asset id
  ctext?: string; // text on cover
  txt?: { bg: string; f: number; c: string };
  ov?: Overlay[];
  adj?: Adjust;
  ovol?: number; // original sound volume
  snd?: SoundRef;
  priv: Privacy;
  cm: boolean;
  du: boolean;
  stc: boolean;
  dl: boolean;
  loc?: string;
  tags?: string[]; // tagged people (uids)
  ht?: string[]; // hashtags
  duet?: { pid: string; au: string; lay: 'lr' | 'rl' | 'tb' | 'pip' };
  stitch?: { pid: string; au: string; s: number; e: number };
  vreply?: { key: string; t: string; au: string };
  pc?: string; // pinned comment key
  hc?: Rec<number>; // hidden (deleted by author) comment keys
  dur?: number;
  ar?: number; // aspect ratio w/h
}

export interface Track {
  id: string;
  n: string; // name
  a: string; // asset (audio in mp4/webm)
  d: number;
  g?: string; // genre
  ts: Ts;
  cover?: string;
}

export interface PostsDoc {
  posts?: Rec<Post>;
  tracks?: Rec<Track>;
}

export interface Comment {
  p: string; // post id
  pa: string; // post author
  t: string;
  r?: string; // parent comment key
  ts: Ts;
  img?: string;
  del?: number;
}
export interface CommentsDoc {
  cm?: Rec<Comment>;
}

export interface View {
  n: number; // views
  w: number; // total watch ms
  c: number; // completions
  l: Ts; // last
  s: string; // last traffic source
  m?: number[]; // furthest second reached, last 5 views
}
export interface ViewsDoc {
  pv?: Rec<View>; // post key -> view
  prof?: Rec<Ts>; // profiles viewed
  sv?: Rec<Ts>; // stories viewed "author~sid"
}

export interface Story {
  id: string;
  t: 'photo' | 'video' | 'text';
  m?: string;
  ts: Ts;
  txt?: string;
  bg?: string;
  c?: string;
  snd?: SoundRef;
  dur?: number;
}
export interface StoriesDoc {
  st?: Rec<Story>;
}

export interface Enc {
  i: string; // iv b64
  d: string; // ciphertext b64
}
export interface Conv {
  m: string[];
  n?: string;
  by: string;
  w: Rec<Enc>;
  ts: Ts;
  g?: number;
  av?: string;
}
export interface ConvDoc {
  cv?: Rec<Conv>;
}
export interface MsgStored extends Enc {
  ts: Ts;
  kc: string; // conversation key creator
  del?: number;
}
export interface MsgIndexDoc {
  last?: Rec<MsgStored & { id: string }>;
  rd?: Rec<Ts>;
}
export interface ConvMsgsDoc {
  m?: Rec<MsgStored>;
  rx?: Rec<string>;
}
export type MsgKind = 'text' | 'img' | 'video' | 'audio' | 'post' | 'story' | 'profile';
export interface MsgBody {
  k: MsgKind;
  t?: string;
  a?: string;
  p?: string; // post key
  r?: string; // reply-to message key
  u?: string; // profile uid
}

export interface Report {
  k: 'post' | 'comment' | 'user' | 'msg' | 'story';
  id: string;
  why: string;
  ts: Ts;
  note?: string;
}
export interface ReportsDoc {
  r?: Rec<Report>;
}

export interface Banner {
  id: string;
  title: string;
  text: string;
  tag?: string;
  color: string;
}
export interface ModCfg {
  bans?: Rec<Ts>;
  removed?: Rec<Ts>; // removed content keys
  resolved?: Rec<Ts>; // resolved report keys
  trends?: string[];
  banners?: Banner[];
  tagDesc?: Rec<string>;
}

export interface Settings {
  theme?: 'dark' | 'light' | 'system';
  lang?: Lang;
  nt?: Rec<boolean>; // notification types off when false
  kw?: string[]; // filtered keywords
  brk?: number; // break reminder minutes
  lim?: number; // daily limit minutes
  saver?: boolean;
  auto?: boolean; // autoscroll
}
export type Lang = 'ru' | 'en' | 'uz';

export interface Draft {
  id: string;
  ts: Ts;
  post: Post;
}

export interface Me {
  sk?: JsonWebKey;
  cols?: Rec<string[]>;
  drafts?: Rec<Draft>;
  int?: Rec<number>; // onboarding interests
  ni?: Rec<Ts>; // not interested post keys
  nia?: Rec<Ts>; // not interested authors
  sh?: string[];
  ns?: Ts; // notifications seen at
  set?: Settings;
  fs?: Rec<Ts>; // favourite sounds
  hm?: Rec<number>; // messages hidden for me
  bd?: string;
}
export interface PrivPosts {
  posts?: Rec<Post>;
}

export type NotifType =
  | 'like'
  | 'comment'
  | 'reply'
  | 'mention'
  | 'follow'
  | 'request'
  | 'repost'
  | 'duet'
  | 'stitch'
  | 'clike'
  | 'tag';
export interface Notif {
  type: NotifType;
  by: string;
  ts: Ts;
  post?: string; // post key
  text?: string;
  ckey?: string;
}
