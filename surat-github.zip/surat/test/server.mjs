// Local stand-in for claude.ai: serves dist/surat.html with test/mock.js injected,
// and stores uploaded files in memory under /_blob/<id>.
import http from 'node:http';
import { readFileSync } from 'node:fs';
import { randomBytes } from 'node:crypto';
import { fileURLToPath } from 'node:url';

const root = new URL('../', import.meta.url);

function page() {
  const mock = readFileSync(new URL('test/mock.js', root), 'utf8');
  const body = readFileSync(new URL('dist/surat.html', root), 'utf8');
  return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><style>:root{color-scheme:light}body{margin:0;font:14px system-ui}img{max-width:100%}[hidden]{display:none!important}</style><script>${mock}</script></head><body>${body}</body></html>`;
}

export function startServer(port = 8765) {
  const blobs = new Map();
  const server = http.createServer((req, res) => {
    const url = new URL(req.url, 'http://localhost');
    if (req.method === 'POST' && url.pathname === '/_upload') {
      const chunks = [];
      req.on('data', (c) => chunks.push(c));
      req.on('end', () => {
        const id = randomBytes(16).toString('hex');
        blobs.set(id, { type: req.headers['content-type'], buf: Buffer.concat(chunks) });
        res.setHeader('content-type', 'application/json');
        res.end(JSON.stringify({ id }));
      });
      return;
    }
    if (url.pathname.startsWith('/_blob/')) {
      const b = blobs.get(url.pathname.slice(7));
      if (!b) {
        res.statusCode = 404;
        return res.end();
      }
      res.setHeader('content-type', b.type);
      res.setHeader('accept-ranges', 'bytes');
      const m = /bytes=(\d*)-(\d*)/.exec(req.headers.range || '');
      if (m) {
        const s = Number(m[1] || 0);
        const e = m[2] ? Number(m[2]) : b.buf.length - 1;
        res.statusCode = 206;
        res.setHeader('content-range', `bytes ${s}-${e}/${b.buf.length}`);
        return res.end(b.buf.subarray(s, e + 1));
      }
      return res.end(b.buf);
    }
    if (url.pathname === '/favicon.ico') {
      res.statusCode = 204;
      return res.end();
    }
    res.setHeader('content-type', 'text/html; charset=utf-8');
    res.end(page());
  });
  return new Promise((resolve) => server.listen(port, () => resolve(server)));
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const port = Number(process.env.PORT || 8765);
  await startServer(port);
  console.log(`Surat test server: http://localhost:${port}/?uid=u_alice&owner=1`);
}
