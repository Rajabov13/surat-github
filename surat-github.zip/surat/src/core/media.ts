// Client-side media processing: image resize, video metadata, cover frames,
// and real-time re-encoding (compression, watermark) with canvas + MediaRecorder.
import { caps } from './caps';

export const MAX_ASSET = 20 * 1024 * 1024;

export interface Uploaded {
  id: string;
  url: string;
}

export async function upload(blob: Blob, type?: string): Promise<Uploaded> {
  if (!caps.assets) throw { code: 'not_granted', message: 'uploads unavailable' };
  let t = type || blob.type;
  if (t.startsWith('audio/')) t = t.includes('webm') ? 'video/webm' : 'video/mp4';
  if (t === 'video/quicktime') t = 'video/mp4';
  if (t.includes(';')) t = t.split(';')[0];
  try {
    const r = await caps.assets.upload(blob, t ? { type: t } : undefined);
    return { id: r.id, url: r.url };
  } catch (e) {
    const code = (e as { code?: string }).code;
    if (code === 'store_unavailable') {
      await new Promise((r) => setTimeout(r, 800 + Math.random() * 600));
      const r = await caps.assets.upload(blob, t ? { type: t } : undefined);
      return { id: r.id, url: r.url };
    }
    throw e;
  }
}

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((res, rej) => {
    const img = new Image();
    img.onload = () => res(img);
    img.onerror = () => rej(new Error('image'));
    img.src = src;
  });
}

function canvasBlob(c: HTMLCanvasElement, type = 'image/jpeg', q = 0.86): Promise<Blob> {
  return new Promise((res, rej) => c.toBlob((b) => (b ? res(b) : rej(new Error('encode'))), type, q));
}

/** Downscale a photo to at most `max` px on the long side, as JPEG (GIFs keep their animation). */
export async function prepareImage(file: Blob, max = 1440): Promise<{ blob: Blob; w: number; h: number }> {
  const url = URL.createObjectURL(file);
  try {
    const img = await loadImage(url);
    const w0 = img.naturalWidth;
    const h0 = img.naturalHeight;
    if (file.type === 'image/gif' && file.size < MAX_ASSET) return { blob: file, w: w0, h: h0 };
    const k = Math.min(1, max / Math.max(w0, h0));
    const c = document.createElement('canvas');
    c.width = Math.round(w0 * k);
    c.height = Math.round(h0 * k);
    const ctx = c.getContext('2d')!;
    ctx.drawImage(img, 0, 0, c.width, c.height);
    return { blob: await canvasBlob(c), w: c.width, h: c.height };
  } finally {
    URL.revokeObjectURL(url);
  }
}

export interface VideoMeta {
  dur: number;
  w: number;
  h: number;
}
export function videoMeta(src: string): Promise<VideoMeta> {
  return new Promise((res, rej) => {
    const v = document.createElement('video');
    v.preload = 'metadata';
    v.muted = true;
    v.playsInline = true;
    const done = (): void => {
      if (!isFinite(v.duration)) {
        // some webm files report Infinity until seeked to the end
        v.currentTime = 1e7;
        v.ontimeupdate = () => {
          v.ontimeupdate = null;
          res({ dur: v.duration, w: v.videoWidth, h: v.videoHeight });
        };
        return;
      }
      res({ dur: v.duration, w: v.videoWidth, h: v.videoHeight });
    };
    v.onloadedmetadata = done;
    v.onerror = () => rej(new Error('video'));
    v.src = src;
  });
}

/** Grab one frame of a video as a JPEG, optionally with text drawn over it. */
export async function captureFrame(src: string, time: number, max = 720, text?: string): Promise<Blob> {
  const v = document.createElement('video');
  v.muted = true;
  v.playsInline = true;
  v.preload = 'auto';
  v.crossOrigin = 'anonymous';
  v.src = src;
  await new Promise<void>((res, rej) => {
    v.onloadeddata = () => res();
    v.onerror = () => rej(new Error('video'));
  });
  await new Promise<void>((res) => {
    v.onseeked = () => res();
    v.currentTime = Math.max(0.01, Math.min(time, (v.duration || 1) - 0.05));
  });
  const k = Math.min(1, max / Math.max(v.videoWidth, v.videoHeight));
  const c = document.createElement('canvas');
  c.width = Math.round(v.videoWidth * k) || 360;
  c.height = Math.round(v.videoHeight * k) || 640;
  const ctx = c.getContext('2d')!;
  ctx.drawImage(v, 0, 0, c.width, c.height);
  if (text) drawCoverText(ctx, c.width, c.height, text);
  v.removeAttribute('src');
  v.load();
  return canvasBlob(c, 'image/jpeg', 0.82);
}

export async function imageWithText(src: string, text: string, max = 1080): Promise<Blob> {
  const img = await loadImage(src);
  const k = Math.min(1, max / Math.max(img.naturalWidth, img.naturalHeight));
  const c = document.createElement('canvas');
  c.width = Math.round(img.naturalWidth * k);
  c.height = Math.round(img.naturalHeight * k);
  const ctx = c.getContext('2d')!;
  ctx.drawImage(img, 0, 0, c.width, c.height);
  drawCoverText(ctx, c.width, c.height, text);
  return canvasBlob(c);
}

function drawCoverText(ctx: CanvasRenderingContext2D, w: number, h: number, text: string): void {
  const size = Math.round(w / 11);
  ctx.font = `800 ${size}px system-ui, sans-serif`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.lineJoin = 'round';
  ctx.lineWidth = size / 5;
  ctx.strokeStyle = 'rgba(0,0,0,.75)';
  ctx.fillStyle = '#fff';
  const lines = wrap(ctx, text, w * 0.86);
  lines.forEach((l, i) => {
    const y = h * 0.5 + (i - (lines.length - 1) / 2) * size * 1.15;
    ctx.strokeText(l, w / 2, y);
    ctx.fillText(l, w / 2, y);
  });
}
function wrap(ctx: CanvasRenderingContext2D, text: string, maxW: number): string[] {
  const words = text.split(/\s+/);
  const lines: string[] = [];
  let cur = '';
  for (const w of words) {
    const t = cur ? cur + ' ' + w : w;
    if (ctx.measureText(t).width > maxW && cur) {
      lines.push(cur);
      cur = w;
    } else cur = t;
  }
  if (cur) lines.push(cur);
  return lines.slice(0, 5);
}

/** A rendered text post (coloured background) as an image, used as its cover. */
export async function textCover(text: string, bg: string, color: string, font: string): Promise<Blob> {
  const c = document.createElement('canvas');
  c.width = 540;
  c.height = 960;
  const ctx = c.getContext('2d')!;
  if (bg.startsWith('linear')) {
    const cols = bg.match(/#[0-9a-f]{3,8}/gi) || ['#333', '#111'];
    const g = ctx.createLinearGradient(0, 0, c.width, c.height);
    cols.forEach((col, i) => g.addColorStop(i / Math.max(1, cols.length - 1), col));
    ctx.fillStyle = g;
  } else ctx.fillStyle = bg;
  ctx.fillRect(0, 0, c.width, c.height);
  const size = text.length > 120 ? 30 : text.length > 50 ? 40 : 54;
  ctx.font = `700 ${size}px ${font}`;
  ctx.fillStyle = color;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  const lines = wrap(ctx, text, 460).slice(0, 9);
  lines.forEach((l, i) => ctx.fillText(l, 270, 480 + (i - (lines.length - 1) / 2) * size * 1.25));
  return canvasBlob(c, 'image/jpeg', 0.85);
}

export function recorderSupported(): boolean {
  return typeof MediaRecorder !== 'undefined' && typeof HTMLCanvasElement.prototype.captureStream === 'function';
}

function pickMime(): string {
  const opts = ['video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm', 'video/mp4;codecs=avc1,mp4a', 'video/mp4'];
  for (const o of opts) if (MediaRecorder.isTypeSupported(o)) return o;
  return '';
}

export interface Segment {
  src: string;
  s?: number;
  e?: number;
  r?: number;
}
export interface TranscodeOpts {
  maxSide?: number;
  bitrate?: number;
  watermark?: string;
  filter?: string;
  onProgress?: (f: number) => void;
}

function loadVideoEl(src: string): Promise<HTMLVideoElement> {
  return new Promise((res, rej) => {
    const v = document.createElement('video');
    v.src = src;
    v.playsInline = true;
    v.crossOrigin = 'anonymous';
    v.preload = 'auto';
    v.onloadedmetadata = () => res(v);
    v.onerror = () => rej(new Error('video'));
  });
}

/**
 * Re-encode one or more video segments in real time (canvas + MediaRecorder).
 * Used to shrink large uploads under the 20 MB limit and to burn a watermark into downloads.
 */
export async function transcode(segs: Segment[], o: TranscodeOpts = {}): Promise<Blob> {
  if (!recorderSupported()) throw new Error('recorder');
  const els = await Promise.all(segs.map((s) => loadVideoEl(s.src)));
  const first = els[0];
  const max = o.maxSide || 720;
  const k = Math.min(1, max / Math.max(first.videoWidth || 720, first.videoHeight || 1280));
  const c = document.createElement('canvas');
  c.width = Math.round(((first.videoWidth || 720) * k) / 2) * 2;
  c.height = Math.round(((first.videoHeight || 1280) * k) / 2) * 2;
  const ctx = c.getContext('2d')!;
  ctx.fillStyle = '#000';
  ctx.fillRect(0, 0, c.width, c.height);
  const stream = c.captureStream(30);
  let actx: AudioContext | null = null;
  try {
    actx = new AudioContext();
    const dest = actx.createMediaStreamDestination();
    for (const v of els) actx.createMediaElementSource(v).connect(dest);
    dest.stream.getAudioTracks().forEach((t) => stream.addTrack(t));
  } catch {
    /* no audio */
  }
  const mime = pickMime();
  const rec = new MediaRecorder(stream, { mimeType: mime || undefined, videoBitsPerSecond: o.bitrate || 1_800_000, audioBitsPerSecond: 96_000 });
  const chunks: Blob[] = [];
  rec.ondataavailable = (e) => e.data.size && chunks.push(e.data);
  const total = segs.reduce((a, s, i) => a + ((s.e ?? els[i].duration) - (s.s || 0)) / (s.r || 1), 0);
  let doneBefore = 0;
  const done = new Promise<Blob>((res) => {
    rec.onstop = () => {
      void actx?.close();
      res(new Blob(chunks, { type: (mime || 'video/webm').split(';')[0] }));
    };
  });
  rec.start(1000);
  let elapsed = 0;
  for (let i = 0; i < els.length; i++) {
    const v = els[i];
    const sg = segs[i];
    const start = sg.s || 0;
    const end = Math.min(sg.e ?? v.duration, v.duration);
    v.currentTime = start;
    await new Promise<void>((r) => (v.onseeked = () => r()));
    v.playbackRate = sg.r || 1;
    await v.play();
    await new Promise<void>((resolve) => {
      const draw = (): void => {
        const iw = v.videoWidth || c.width;
        const ih = v.videoHeight || c.height;
        const sc = Math.min(c.width / iw, c.height / ih);
        const dw = iw * sc;
        const dh = ih * sc;
        ctx.fillStyle = '#000';
        ctx.fillRect(0, 0, c.width, c.height);
        if (o.filter) ctx.filter = o.filter;
        ctx.drawImage(v, (c.width - dw) / 2, (c.height - dh) / 2, dw, dh);
        ctx.filter = 'none';
        elapsed = doneBefore + (v.currentTime - start) / (sg.r || 1);
        if (o.watermark) {
          const size = Math.max(14, Math.round(c.width / 22));
          ctx.font = `800 ${size}px system-ui, sans-serif`;
          ctx.fillStyle = 'rgba(255,255,255,.88)';
          ctx.shadowColor = 'rgba(0,0,0,.6)';
          ctx.shadowBlur = 6;
          const top = Math.floor(elapsed / 4) % 2 === 0;
          ctx.textAlign = top ? 'left' : 'right';
          ctx.fillText(o.watermark, top ? size : c.width - size, top ? size * 1.8 : c.height - size * 1.4);
          ctx.shadowBlur = 0;
        }
        o.onProgress?.(Math.min(1, elapsed / Math.max(0.1, total)));
        if (v.currentTime >= end - 0.03 || v.ended) {
          v.pause();
          resolve();
          return;
        }
        requestAnimationFrame(draw);
      };
      draw();
    });
    doneBefore += (end - start) / (sg.r || 1);
  }
  if (rec.state === 'recording') rec.stop();
  return done;
}

export async function watermarkImage(src: string, text: string): Promise<Blob> {
  const img = await loadImage(src);
  const c = document.createElement('canvas');
  c.width = img.naturalWidth;
  c.height = img.naturalHeight;
  const ctx = c.getContext('2d')!;
  ctx.drawImage(img, 0, 0);
  const size = Math.max(14, Math.round(c.width / 24));
  ctx.font = `800 ${size}px system-ui, sans-serif`;
  ctx.fillStyle = 'rgba(255,255,255,.88)';
  ctx.shadowColor = 'rgba(0,0,0,.6)';
  ctx.shadowBlur = 6;
  ctx.fillText(text, size, c.height - size * 1.2);
  return canvasBlob(c, 'image/jpeg', 0.9);
}

export function fileKind(f: File): 'video' | 'image' | 'audio' | 'other' {
  if (f.type.startsWith('video/')) return 'video';
  if (f.type.startsWith('image/')) return 'image';
  if (f.type.startsWith('audio/')) return 'audio';
  return 'other';
}

export async function blobFromUrl(url: string): Promise<Blob> {
  const r = await fetch(url);
  if (!r.ok) throw new Error('fetch');
  return r.blob();
}
