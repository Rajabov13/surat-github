// Direct messages: conversations, encryption keys, sending and reading.
import { AppError } from './actions';
import { decryptBytes, decryptJson, encryptBytes, encryptJson, importConvKey, newConvKey, pairKey } from './crypto';
import { blockedEither, follows, friends, activeUser } from './derive';
import { bump, convDocs, patch, patchMe, queued, ref, S } from './store';
import type { Conv, ConvMsgsDoc, Enc, MsgBody, MsgStored, Rec } from './types';
import { allow, now, pkey, rid, sha, splitKey } from './util';

export interface ConvX extends Conv {
  id: string;
  records: Conv[];
  lastTs: number;
  lastBy?: string;
  lastEnc?: MsgStored;
  unread: boolean;
  request: boolean;
}

/** All conversations I belong to, newest activity first. */
export function myConvs(): ConvX[] {
  const me = S.uid;
  if (!me) return [];
  const byId = new Map<string, Conv[]>();
  for (const creator in S.cv) {
    const cvs = S.cv[creator]?.cv;
    if (!cvs) continue;
    for (const cid in cvs) {
      const c = cvs[cid];
      if (!c || !Array.isArray(c.m) || !c.m.includes(me) || c.by !== creator) continue;
      const arr = byId.get(cid);
      if (arr) arr.push(c);
      else byId.set(cid, [c]);
    }
  }
  const out: ConvX[] = [];
  const hiddenConvs = S.me.hm || {};
  for (const [id, records] of byId) {
    records.sort((a, b) => a.ts - b.ts);
    const base = records[0];
    const others = base.m.filter((m) => m !== me);
    if (!base.g && others.some((o) => blockedEither(me, o) || !activeUser(o))) continue;
    let lastTs = base.ts;
    let lastBy: string | undefined;
    let lastEnc: MsgStored | undefined;
    for (const m of base.m) {
      const l = S.ms[m]?.last?.[id];
      if (l && l.ts > lastTs) {
        lastTs = l.ts;
        lastBy = m;
        lastEnc = l;
      }
    }
    if (hiddenConvs['c~' + id] && lastTs <= hiddenConvs['c~' + id]) continue;
    const myRead = S.ms[me]?.rd?.[id] || 0;
    const iSent = !!S.ms[me]?.last?.[id];
    const request = !iSent && base.by !== me && !follows(me, base.by);
    out.push({ ...base, n: records.find((r) => r.n)?.n || base.n, id, records, lastTs, lastBy, lastEnc, unread: !!lastBy && lastBy !== me && lastTs > myRead, request });
  }
  return out.sort((a, b) => b.lastTs - a.lastTs);
}

export function unreadChats(): number {
  return myConvs().filter((c) => c.unread && !c.request).length;
}

// ---------- keys ----------
const keyCache = new Map<string, Promise<CryptoKey | null>>();
export function convKey(cid: string, rec: Conv): Promise<CryptoKey | null> {
  const id = `${cid}|${rec.by}|${rec.ts}`;
  let p = keyCache.get(id);
  if (!p) {
    p = (async () => {
      const me = S.uid;
      const sk = S.me.sk;
      const creatorPub = S.u[rec.by]?.pk;
      const wrap = me ? rec.w?.[me] : undefined;
      if (!me || !sk || !creatorPub || !wrap) return null;
      try {
        const pk = await pairKey(sk, creatorPub);
        const raw = await decryptBytes(pk, wrap);
        return await importConvKey(raw);
      } catch {
        return null;
      }
    })();
    keyCache.set(id, p);
    void p.then((k) => {
      if (!k) keyCache.delete(id);
    });
  }
  return p;
}

function canMessage(other: string): boolean {
  const me = S.uid;
  if (!me) return false;
  const pol = S.u[other]?.dm || 'all';
  if (blockedEither(me, other)) return false;
  if (pol === 'none') return false;
  if (pol === 'friends') return friends(me, other);
  return true;
}
export function messagePolicyOk(other: string): boolean {
  return canMessage(other);
}

async function createConv(cid: string, members: string[], name?: string, group = false): Promise<void> {
  const me = S.uid!;
  const sk = S.me.sk;
  if (!sk) throw new AppError('nokeys');
  const { raw } = await newConvKey();
  const w: Rec<Enc> = {};
  for (const m of members) {
    const pub = S.u[m]?.pk;
    if (!pub) continue;
    w[m] = await encryptBytes(await pairKey(sk, pub), raw);
  }
  if (!w[me]) throw new AppError('nokeys');
  const conv: Conv = { m: members, by: me, w, ts: now() };
  if (name) conv.n = name.slice(0, 40);
  if (group) conv.g = 1;
  await patch('cv', { cv: { [cid]: conv } });
}

export async function openDirect(other: string): Promise<string> {
  const me = S.uid;
  if (!me || S.readOnly) throw new AppError('readonly');
  const cid = 'd' + (await sha([me, other].sort().join('|')));
  if (myConvs().some((c) => c.id === cid)) return cid;
  if (!canMessage(other)) throw new AppError('dm_closed');
  if (!S.u[other]?.pk) throw new AppError('nokeys_other');
  await createConv(cid, [me, other]);
  return cid;
}

export async function createGroup(members: string[], name: string): Promise<string> {
  const me = S.uid;
  if (!me || S.readOnly) throw new AppError('readonly');
  const all = [...new Set([me, ...members])].filter((m) => S.u[m]?.pk).slice(0, 32);
  if (all.length < 3) throw new AppError('group_small');
  const cid = 'g' + rid(14);
  await createConv(cid, all, name, true);
  return cid;
}

export async function renameGroup(cid: string, name: string): Promise<void> {
  const me = S.uid!;
  const rec = S.cv[me]?.cv?.[cid];
  if (!rec) throw new AppError('denied');
  await patch('cv', { cv: { [cid]: { n: name.slice(0, 40) } } });
}

// ---------- sending ----------
function canonical(c: ConvX): Promise<{ key: CryptoKey; kc: string } | null> {
  return (async () => {
    for (const r of c.records) {
      const k = await convKey(c.id, r);
      if (k) return { key: k, kc: `${r.by}@${r.ts}` };
    }
    return null;
  })();
}

export async function send(cid: string, body: MsgBody): Promise<void> {
  const me = S.uid;
  if (!me || S.readOnly) throw new AppError('readonly');
  if (!allow('msg', 20, 30000)) throw new AppError('rate');
  const c = myConvs().find((x) => x.id === cid);
  if (!c) throw new AppError('missing');
  if (!c.g) {
    const other = c.m.find((m) => m !== me);
    if (other && !canMessage(other)) throw new AppError('dm_closed');
  }
  const k = await canonical(c);
  if (!k) throw new AppError('nokeys');
  const enc = await encryptJson(k.key, body);
  const mid = rid(10);
  const ts = now();
  const msg: MsgStored = { ...enc, ts, kc: k.kc };
  const path = `ms/${me}/c/${cid}`;
  await queued(path, async () => {
    const cur = convDocs[cid]?.[me];
    const count = cur?.m ? Object.keys(cur.m).length : 0;
    if (count > 600) {
      const kept = Object.entries(cur!.m!)
        .sort((a, b) => b[1].ts - a[1].ts)
        .slice(0, 480);
      await ref(path).set({ ...cur, m: { ...Object.fromEntries(kept), [mid]: msg } });
      return;
    }
    try {
      await ref(path).update({ m: { [mid]: msg } });
    } catch {
      await ref(path).set({ m: { [mid]: msg } });
    }
  });
  await patch('ms', { last: { [cid]: { ...msg, id: mid } }, rd: { [cid]: ts } });
}

export async function markRead(cid: string): Promise<void> {
  const me = S.uid;
  if (!me || S.readOnly) return;
  const c = myConvs().find((x) => x.id === cid);
  if (!c || !c.unread) return;
  await patch('ms', { rd: { [cid]: now() } }).catch(() => undefined);
}

export async function deleteForAll(cid: string, mid: string): Promise<void> {
  const me = S.uid!;
  const path = `ms/${me}/c/${cid}`;
  await queued(path, () => ref(path).update({ m: { [mid]: { del: 1, i: '', d: '' } } }));
  if (S.ms[me]?.last?.[cid]?.id === mid) await patch('ms', { last: { [cid]: { id: mid, ts: now(), i: '', d: '', kc: '', del: 1 } } });
}
export async function hideForMe(msgKey: string): Promise<void> {
  await patchMe({ hm: { [msgKey]: 1 } });
}
/** Hide a whole conversation for me until a newer message arrives. */
export async function hideConv(cid: string): Promise<void> {
  await patchMe({ hm: { ['c~' + cid]: now() } });
}
export async function react(cid: string, msgKey: string, emoji: string): Promise<void> {
  const me = S.uid!;
  const path = `ms/${me}/c/${cid}`;
  await queued(path, async () => {
    try {
      await ref(path).update({ rx: { [msgKey]: emoji } });
    } catch {
      await ref(path).set({ rx: { [msgKey]: emoji } });
    }
  });
}

// ---------- reading ----------
export interface MsgX {
  key: string; // author~mid
  id: string;
  by: string;
  ts: number;
  body: MsgBody | null; // null = could not decrypt / deleted
  deleted: boolean;
  reactions: Rec<string>; // uid -> emoji
}

const plain = new Map<string, MsgBody | 'err'>();
const pending = new Set<string>();

function decryptLater(cid: string, conv: ConvX, cacheKey: string, m: MsgStored): void {
  if (pending.has(cacheKey)) return;
  pending.add(cacheKey);
  void (async () => {
    try {
      const rec = conv.records.find((r) => `${r.by}@${r.ts}` === m.kc) || conv.records[0];
      const key = await convKey(cid, rec);
      if (!key) throw new Error('nokey');
      plain.set(cacheKey, await decryptJson<MsgBody>(key, m));
    } catch {
      plain.set(cacheKey, 'err');
    } finally {
      pending.delete(cacheKey);
      bump();
    }
  })();
}

export function messages(conv: ConvX): MsgX[] {
  const docs: Rec<ConvMsgsDoc> = convDocs[conv.id] || {};
  const hidden = S.me.hm || {};
  const out: MsgX[] = [];
  const rx: Rec<Rec<string>> = {};
  for (const uid in docs) for (const [k, e] of Object.entries(docs[uid].rx || {})) if (e) (rx[k] = rx[k] || {})[uid] = e;
  for (const uid of conv.m) {
    const d = docs[uid];
    if (!d?.m) continue;
    for (const [mid, m] of Object.entries(d.m)) {
      const key = pkey(uid, mid);
      if (hidden[key]) continue;
      const deleted = !!m.del;
      let body: MsgBody | null = null;
      if (!deleted) {
        const ck = key + '|' + m.d.slice(0, 16);
        const p = plain.get(ck);
        if (p === undefined) decryptLater(conv.id, conv, ck, m);
        else if (p !== 'err') body = p;
      }
      out.push({ key, id: mid, by: uid, ts: m.ts, body, deleted, reactions: rx[key] || {} });
    }
  }
  return out.sort((a, b) => a.ts - b.ts);
}

/** Decrypted preview of a conversation's last message ('' while decrypting). */
export function lastPreview(conv: ConvX): MsgBody | null | 'deleted' {
  const m = conv.lastEnc;
  if (!m || !conv.lastBy) return null;
  if (m.del) return 'deleted';
  const ck = pkey(conv.lastBy, (m as MsgStored & { id?: string }).id || '') + '|' + m.d.slice(0, 16);
  const p = plain.get(ck);
  if (p === undefined) {
    decryptLater(conv.id, conv, ck, m);
    return null;
  }
  return p === 'err' ? null : p;
}

export function readBy(conv: ConvX, ts: number): string[] {
  return conv.m.filter((m) => m !== S.uid && (S.ms[m]?.rd?.[conv.id] || 0) >= ts);
}

export function convTitle(conv: ConvX): string {
  if (conv.n) return conv.n;
  const others = conv.m.filter((m) => m !== S.uid);
  return others.map((o) => S.u[o]?.nm || S.u[o]?.un || '…').join(', ');
}

export const msgAuthor = (key: string): string => splitKey(key)[0];
