import React, { useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { block, follow, like, recordProfileView, recordView, removeFollower, save } from '../core/actions';
import { agg, blockedEither, canSee, canSeeProfileContent, follows, followingFeed, forYou, getPost, iBlocked, popularity, profilePosts, suggestions, unreadNotifs, userKeys } from '../core/derive';
import { messagePolicyOk, openDirect, unreadChats } from '../core/dm';
import { boot, S, useStore } from '../core/store';
import { cx, fmtCount, has, haptic, now, rid, unToHash, DAY } from '../core/util';
import { ChatList } from '../ui/chat';
import { CommentsSheet } from '../ui/comments';
import { cfg, shareLink } from '../ui/config';
import { PostMenu, VerticalFeed } from '../ui/feed';
import { setDefaultLang, t, timeAgo } from '../ui/i18n';
import { Icon } from '../ui/icons';
import { act, Avatar, Empty, errToast, FollowButton, MenuItem, ReadOnlyNote, RichText, Tabs } from '../ui/kit';
import { back, closeSheet, confirmDialog, go, nav, setTab, sheet } from '../ui/nav';
import { Onboarding } from '../ui/onboarding';
import { audio, PostMedia, setMuted, soundTitle } from '../ui/player';
import { PostGrid, suggestReason } from '../ui/profile';
import { BootGate, Overlays, Stack, useDeepLinks, useTheme } from '../ui/screens';
import { copyText, QrSheet, ReportSheet, ShareSheet } from '../ui/share';
import { StoryBar } from '../ui/stories';
import type { Screen } from '../ui/nav';

cfg.kind = 'surat';
cfg.name = 'Surat';
cfg.watermark = 'Surat';
cfg.url = (window as unknown as { APP_URL?: string }).APP_URL || '';
setDefaultLang('uz');

export function Logo({ small }: { small?: boolean }): React.ReactElement {
  return (
    <span className={cx('logo', small && 'logo-sm')}>
      <svg viewBox="0 0 48 48" width={small ? 28 : 46} height={small ? 28 : 46} aria-hidden="true">
        <rect x="4" y="4" width="40" height="40" rx="12" fill="none" stroke="var(--accent)" strokeWidth="4" />
        <g transform="translate(24 24)" fill="var(--accent2)">
          {[0, 45, 90, 135].map((r) => (
            <ellipse key={r} rx="3.2" ry="9.5" transform={`rotate(${r})`} opacity=".9" />
          ))}
        </g>
        <circle cx="24" cy="24" r="4" fill="var(--bg)" stroke="var(--accent)" strokeWidth="2.5" />
      </svg>
      <b>Surat</b>
    </span>
  );
}

// ---------- post card ----------
function useInView(ref: React.RefObject<HTMLElement | null>, threshold = 0.6): boolean {
  const [v, setV] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(([e]) => setV(e.isIntersecting && e.intersectionRatio >= threshold), { threshold: [0, threshold, 1] });
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return v;
}

function PostCard({ postKey, active, src, list }: { postKey: string; active: boolean; src: string; list?: string[] }): React.ReactElement | null {
  useStore();
  const p = getPost(postKey);
  const box = useRef<HTMLDivElement | null>(null);
  const inView = useInView(box);
  const [hearts, setHearts] = useState<{ id: string; x: number; y: number }[]>([]);
  const [more, setMore] = useState(false);
  const [paused, setPaused] = useState(false);
  const lastTap = useRef(0);
  const watch = useRef({ ms: 0, since: 0, max: 0, loops: 0 });
  const playing = active && inView;
  useEffect(() => {
    const w = watch.current;
    if (playing && !paused) w.since = performance.now();
    else if (w.since) {
      w.ms += performance.now() - w.since;
      w.since = 0;
      if (!playing && w.ms >= 1000 && p) {
        void recordView(postKey, w.ms, w.loops > 0 || w.max >= (p.dur || 3) * 0.9, w.max, src);
        watch.current = { ms: 0, since: 0, max: 0, loops: 0 };
      }
    }
  }, [playing, paused]);
  if (!p || !canSee(p)) return null;
  const me = S.uid;
  const liked = me ? has(S.g[me]?.lk, postKey) : false;
  const saved = me ? has(S.g[me]?.sv, postKey) : false;
  const onTap = (e: React.MouseEvent): void => {
    if ((e.target as HTMLElement).closest('button, a, .ov-poll, .ov-chip, .dots')) return;
    const nowT = performance.now();
    if (nowT - lastTap.current < 300) {
      lastTap.current = 0;
      const r = (e.currentTarget as HTMLElement).getBoundingClientRect();
      const id = rid(6);
      setHearts((h) => [...h, { id, x: e.clientX - r.left, y: e.clientY - r.top }]);
      setTimeout(() => setHearts((h) => h.filter((q) => q.id !== id)), 900);
      if (!liked) {
        haptic(15);
        void act(() => like(postKey, true));
      }
      return;
    }
    lastTap.current = nowT;
    if (p.t === 'video') setTimeout(() => lastTap.current && setPaused((v) => !v), 300);
  };
  const captionLong = p.cap.length > 110;
  return (
    <article className="card-post" ref={box}>
      <header className="cp-head">
        <Avatar uid={p.by} size={34} ring onClick={() => go('profile', { uid: p.by })} />
        <div className="grow min0 tap" onClick={() => go('profile', { uid: p.by })}>
          <b className="ell block">{S.u[p.by]?.un}</b>
          {(p.loc || p.soundKey) && <small className="ell block">{p.loc || (p.snd ? '♪ ' + soundTitle(p.soundKey) : '')}</small>}
        </div>
        {me && me !== p.by && !follows(me, p.by) && (
          <button className="link-btn accent" onClick={() => void act(() => follow(p.by, true))}>
            {t('Подписаться')}
          </button>
        )}
        <button className="icon-btn" onClick={() => sheet(() => <PostMenu postKey={postKey} />)} aria-label={t('Ещё')}>
          <Icon n="more" />
        </button>
      </header>
      <div className={cx('cp-media', p.t === 'video' && 'is-video')} onClick={onTap}>
        <PostMedia post={p} active={playing} paused={paused} eager={inView} onTime={(c) => (watch.current.max = Math.max(watch.current.max, c))} onLoop={() => watch.current.loops++} />
        {hearts.map((h) => (
          <span key={h.id} className="burst" style={{ left: h.x, top: h.y, ['--r' as string]: '0deg' }}>
            <Icon n="heart" size={90} fill />
          </span>
        ))}
        {(p.t === 'video' || p.snd) && (
          <button className="cp-mute" onClick={() => setMuted(!audio.muted)} aria-label={t('Звук')}>
            <Icon n={audio.muted ? 'mute' : 'volume'} size={16} />
          </button>
        )}
        {paused && p.t === 'video' && (
          <div className="paused-ic">
            <Icon n="play" size={56} fill />
          </div>
        )}
      </div>
      <div className="cp-actions">
        <button className={cx('icon-btn', liked && 'liked')} onClick={() => (liked || haptic(15), void act(() => like(postKey, !liked)))} aria-label={t('Нравится')}>
          <Icon n="heart" size={26} fill={liked} />
        </button>
        <button className="icon-btn" onClick={() => sheet(() => <CommentsSheet postKey={postKey} />, true)} aria-label={t('Комментарии')}>
          <Icon n="comment" size={25} />
        </button>
        <button className="icon-btn" onClick={() => sheet(() => <ShareSheet postKey={postKey} />)} aria-label={t('Поделиться')}>
          <Icon n="send" size={24} />
        </button>
        <span className="grow" />
        <button className={cx('icon-btn', saved && 'saved')} onClick={() => void act(() => save(postKey, !saved))} aria-label={t('Сохранить')}>
          <Icon n="bookmark" size={25} fill={saved} />
        </button>
      </div>
      <div className="cp-body">
        {p.likes > 0 && (
          <b className="block">
            {t('Нравится')}: {fmtCount(p.likes)}
          </b>
        )}
        {p.cap && p.t !== 'text' && (
          <div className={cx('cp-cap', !more && captionLong && 'clamp')}>
            <b className="tap" onClick={() => go('profile', { uid: p.by })}>
              {S.u[p.by]?.un}
            </b>{' '}
            <RichText text={p.cap} />
          </div>
        )}
        {captionLong && !more && p.t !== 'text' && (
          <button className="link-btn" onClick={() => setMore(true)}>
            {t('ещё')}
          </button>
        )}
        {p.comments > 0 && (
          <button className="link-btn" onClick={() => sheet(() => <CommentsSheet postKey={postKey} />, true)}>
            {t('Посмотреть все комментарии ({n})', { n: p.comments })}
          </button>
        )}
        <small className="muted block">
          {timeAgo(p.at || p.ts)}
          {p.priv !== 'all' ? ' · ' + (p.priv === 'me' ? t('Только я') : t('Друзья')) : ''}
          {p.views ? ` · ${fmtCount(p.views)} ${t('просмотров')}` : ''}
        </small>
      </div>
      {list && null}
    </article>
  );
}

function CardList({ keys, visible, header, empty, src }: { keys: string[]; visible: boolean; header?: React.ReactNode; empty?: React.ReactNode; src: string }): React.ReactElement {
  const [limit, setLimit] = useState(8);
  const end = useRef<HTMLDivElement | null>(null);
  useEffect(() => {
    const el = end.current;
    if (!el) return;
    const io = new IntersectionObserver(([e]) => e.isIntersecting && setLimit((l) => l + 8), { rootMargin: '600px' });
    io.observe(el);
    return () => io.disconnect();
  }, [keys.length]);
  return (
    <>
      {header}
      {keys.length === 0 && empty}
      {keys.slice(0, limit).map((k) => (
        <PostCard key={k} postKey={k} active={visible} src={src} />
      ))}
      <div ref={end} className="list-end" />
    </>
  );
}

function Home({ visible }: { visible: boolean }): React.ReactElement {
  useStore();
  const [seed, setSeed] = useState(() => Math.floor(Math.random() * 1e6) + 1);
  const me = S.uid;
  const fol = followingFeed();
  const mine = useMemo(() => [...agg().posts.values()].filter((p) => p.by === me && now() - p.ts < 3 * DAY).map((p) => p.key), [S.ver]);
  const followed = [...new Set([...fol, ...mine])].sort((a, b) => (getPost(b)?.ts || 0) - (getPost(a)?.ts || 0));
  const postCount = agg().posts.size;
  const rec = useMemo(() => forYou(seed).filter((k) => !followed.includes(k)), [seed, S.phase, postCount < 40 ? postCount : 0]);
  const notif = S.uid ? unreadNotifs() : 0;
  const chats = S.uid ? unreadChats() : 0;
  const scroller = useRef<HTMLDivElement | null>(null);
  return (
    <div className="screen home">
      <header className="ig-top">
        <button onClick={() => (scroller.current?.scrollTo({ top: 0, behavior: 'smooth' }), setSeed(seed + 1))} aria-label={t('Обновить ленту')}>
          <Logo small />
        </button>
        <div className="row-icons">
          <button className="icon-btn badge-wrap" onClick={() => go('notifications')} aria-label={t('Уведомления')}>
            <Icon n="heart" size={26} />
            {notif > 0 && <span className="dot" />}
          </button>
          <button className="icon-btn badge-wrap" onClick={() => go('dms')} aria-label={t('Сообщения')}>
            <Icon n="messenger" size={26} />
            {chats > 0 && <span className="badge-num">{chats}</span>}
          </button>
        </div>
      </header>
      <ReadOnlyNote />
      <div className="scroll" ref={scroller}>
        <StoryBar />
        <CardList keys={followed} visible={visible} src="home" />
        {followed.length > 0 && (
          <div className="caught-up">
            <Icon n="check" size={30} />
            <b>{t('Вы всё посмотрели')}</b>
            <small className="muted">{t('Новые публикации от подписок за последние дни')}</small>
          </div>
        )}
        {followed.length === 0 && suggestions(1).length > 0 && (
          <div className="pad col gap">
            <b>{t('Вы можете знать')}</b>
            <div className="sugg-cards hscroll">
              {suggestions(10).map((u) => (
                <div key={u} className="sugg-card">
                  <button className="sugg-x" aria-label={t('Скрыть')} onClick={(e) => (e.currentTarget.parentElement as HTMLElement).remove()}>
                    <Icon n="close" size={14} />
                  </button>
                  <Avatar uid={u} size={72} onClick={() => go('profile', { uid: u })} />
                  <b className="ell">{S.u[u]?.nm}</b>
                  <small className="muted ell">{suggestReason(u)}</small>
                  <FollowButton uid={u} small />
                </div>
              ))}
            </div>
          </div>
        )}
        {rec.length > 0 && <div className="sec-hdr"><b>{t('Рекомендуемые публикации')}</b></div>}
        <CardList keys={rec} visible={visible} src="fy" empty={followed.length === 0 ? <Empty icon="image" title={t('Пока нет публикаций')} text={t('Опубликуйте первое фото или видео')} /> : null} />
      </div>
    </div>
  );
}

function Explore(): React.ReactElement {
  useStore();
  const A = agg();
  const keys = [...A.posts.values()]
    .filter((p) => p.priv === 'all' && canSee(p) && p.by !== S.uid)
    .sort((a, b) => popularity(b) - popularity(a))
    .map((p) => p.key);
  return (
    <div className="screen">
      <div className="search-bar">
        <button className="search-input fake" onClick={() => go('search')}>
          <Icon n="search" size={18} />
          <span className="muted">{t('Поиск')}</span>
        </button>
      </div>
      <div className="scroll">
        {keys.length === 0 && <Empty icon="compass" title={t('Здесь появятся популярные публикации')} />}
        <div className="explore-grid">
          {keys.map((k, i) => {
            const p = getPost(k)!;
            const big = i % 10 === 2 || i % 10 === 5;
            return (
              <div key={k} className={cx('eg-item', big && 'big')} onClick={() => go('post', { postKey: k, list: keys, src: 'explore' })}>
                {p.poster || p.ph?.[0] ? <img src={'/_blob/' + (p.poster || p.ph?.[0])} alt="" loading="lazy" /> : <div className="thumb-text" style={{ background: p.txt?.bg }}>{p.cap.slice(0, 60)}</div>}
                {p.t === 'video' && <Icon n="reels" size={18} className="eg-ic" />}
                {p.t === 'photo' && (p.ph?.length || 0) > 1 && <Icon n="layers" size={18} className="eg-ic" />}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function Reels({ visible }: { visible: boolean }): React.ReactElement {
  useStore();
  const [seed, setSeed] = useState(() => Math.floor(Math.random() * 1e6) + 1);
  const postCount = agg().posts.size;
  const keys = useMemo(() => forYou(seed).filter((k) => getPost(k)?.t === 'video'), [seed, S.phase, postCount < 40 ? postCount : 0]);
  return (
    <div className="screen reels dark-screen">
      <div className="reels-top">
        <b>{t('Рилсы')}</b>
        <button className="icon-btn" onClick={() => go('create')} aria-label={t('Создать')}>
          <Icon n="camera" />
        </button>
      </div>
      <VerticalFeed keys={keys} src="reels" visible={visible} onRefresh={() => setSeed(seed + 1)} empty={<Empty icon="reels" title={t('Пока нет рилсов')} text={t('Опубликуйте первое видео')} />} />
    </div>
  );
}

function SuratProfile({ uid, isTab }: { uid: string; isTab?: boolean }): React.ReactElement {
  useStore();
  const me = S.uid;
  const own = uid === me;
  const p = S.u[uid];
  const [tab, setTabState] = useState<'grid' | 'reels' | 'tagged' | 'saved'>('grid');
  useEffect(() => {
    if (!own) void recordProfileView(uid);
  }, [uid]);
  if (!p || p.del)
    return (
      <div className="screen">
        <header className="hdr">
          <button className="icon-btn" onClick={back}><Icon n="back" /></button>
          <span />
          <span />
        </header>
        <Empty icon="user" title={t('Аккаунт не найден')} />
      </div>
    );
  const A = agg();
  const visible = canSeeProfileContent(uid);
  const blocked = blockedEither(me, uid);
  const posts = visible ? profilePosts(uid) : [];
  const followers = A.followers.get(uid) || [];
  const following = A.following.get(uid) || [];
  const requests = own ? A.requests.get(uid) || [] : [];
  const tagged = visible ? [...A.posts.values()].filter((x) => x.tags?.includes(uid) && canSee(x)).map((x) => x.key) : [];
  const link = shareLink('user-' + unToHash(p.un));
  const menu = (): void =>
    sheet(() => (
      <div>
        {own && <MenuItem icon="settings" label={t('Настройки и конфиденциальность')} onClick={() => (closeSheet(), go('settings'))} />}
        {own && <MenuItem icon="chart" label={t('Аналитика')} onClick={() => (closeSheet(), go('analytics'))} />}
        {own && <MenuItem icon="file" label={t('Черновики')} onClick={() => (closeSheet(), go('drafts'))} />}
        {own && !p.pvOff && <MenuItem icon="eye" label={t('Кто смотрел ваш профиль')} onClick={() => (closeSheet(), go('profileviews'))} />}
        <MenuItem icon="qr" label={t('QR-код профиля')} onClick={() => sheet(() => <QrSheet text={link} title={'@' + p.un} />)} />
        <MenuItem icon="link" label={t('Скопировать ссылку на профиль')} onClick={() => (void copyText(link), closeSheet())} />
        {!own && me && follows(uid, me) && <MenuItem icon="users" label={t('Удалить из подписчиков')} onClick={async () => (closeSheet(), (await confirmDialog(t('Удалить подписчика?'), t('Удалить'))) && void act(() => removeFollower(uid)))} />}
        {!own && me && (
          <MenuItem
            icon="shield"
            danger={!iBlocked(uid)}
            label={iBlocked(uid) ? t('Разблокировать') : t('Заблокировать')}
            onClick={async () => {
              closeSheet();
              if (iBlocked(uid)) void act(() => block(uid, false));
              else if (await confirmDialog(t('Заблокировать @{u}?', { u: p.un }), t('Заблокировать'), t('Пользователь не сможет видеть ваш профиль, публикации и писать вам.'))) void act(() => block(uid, true));
            }}
          />
        )}
        {!own && me && <MenuItem icon="flag" label={t('Пожаловаться')} onClick={() => sheet(() => <ReportSheet k="user" id={uid} />)} />}
      </div>
    ));
  return (
    <div className="screen profile ig-profile">
      <header className="hdr">
        {isTab ? <span /> : <button className="icon-btn" onClick={back} aria-label={t('Назад')}><Icon n="back" /></button>}
        <div className="hdr-title">
          <b>
            {p.priv && <Icon n="lock" size={14} />} {p.un}
          </b>
        </div>
        <div className="hdr-right">
          {own && (
            <button className="icon-btn" onClick={() => go('create')} aria-label={t('Создать')}>
              <Icon n="plus" />
            </button>
          )}
          <button className="icon-btn" onClick={menu} aria-label={t('Меню')}>
            <Icon n={own ? 'settings' : 'more'} />
          </button>
        </div>
      </header>
      <div className="scroll">
        <div className="igp-head">
          <Avatar uid={uid} size={86} ring onClick={() => (A.stories.has(uid) && visible ? go('stories', { start: uid, only: true }) : undefined)} />
          <div className="igp-stats">
            <div>
              <b>{fmtCount(posts.length)}</b>
              <small>{t('публикаций')}</small>
            </div>
            <button onClick={() => visible && go('follows', { uid, tab: 'followers' })}>
              <b>{fmtCount(followers.length)}</b>
              <small>{t('подписчиков')}</small>
            </button>
            <button onClick={() => visible && (!p.hideFollowing || own) && go('follows', { uid, tab: 'following' })}>
              <b>{fmtCount(following.length)}</b>
              <small>{t('подписок')}</small>
            </button>
          </div>
        </div>
        <div className="igp-bio pad-x">
          <b>{p.nm}</b>
          {p.bio && <RichText text={p.bio} className="block" />}
          {p.link && (
            <a className="accent block" href={/^https?:/.test(p.link) ? p.link : 'https://' + p.link} target="_blank" rel="noopener noreferrer">
              {p.link.replace(/^https?:\/\//, '')}
            </a>
          )}
          {!own && me && follows(uid, me) && <small className="muted block">{t('Подписан(а) на вас')}</small>}
        </div>
        <div className="igp-btns pad-x">
          {own ? (
            <>
              <button className="btn btn-muted grow" onClick={() => go('editprofile')}>
                {t('Редактировать профиль')}
              </button>
              <button className="btn btn-muted grow" onClick={() => void copyText(link)}>
                {t('Поделиться профилем')}
              </button>
            </>
          ) : blocked ? (
            iBlocked(uid) && (
              <button className="btn btn-muted grow" onClick={() => void act(() => block(uid, false))}>
                {t('Разблокировать')}
              </button>
            )
          ) : (
            <>
              <FollowButton uid={uid} className="grow" />
              {me && messagePolicyOk(uid) && (
                <button
                  className="btn btn-muted grow"
                  onClick={async () => {
                    try {
                      go('chat', { cid: await openDirect(uid) });
                    } catch (e) {
                      errToast(e);
                    }
                  }}
                >
                  {t('Сообщение')}
                </button>
              )}
            </>
          )}
        </div>
        {own && requests.length > 0 && (
          <button className="req-banner mx" onClick={() => go('follows', { uid, tab: 'requests' })}>
            <Icon n="users" size={18} /> {t('Заявки на подписку')}: <b>{requests.length}</b>
          </button>
        )}
        {blocked ? (
          <Empty icon="shield" title={t('Профиль недоступен')} />
        ) : !visible ? (
          <Empty icon="lock" title={t('Это закрытый аккаунт')} text={t('Подпишитесь, чтобы видеть публикации')} />
        ) : (
          <>
            <Tabs
              className="prof-tabs"
              value={tab}
              onChange={setTabState}
              items={[
                ['grid', <Icon key="g" n="grid" size={22} />],
                ['reels', <Icon key="r" n="reels" size={22} />],
                ['tagged', <Icon key="t" n="user" size={22} />],
                ...(own ? ([['saved', <Icon key="s" n="bookmark" size={22} />]] as [typeof tab, React.ReactNode][]) : []),
              ]}
            />
            {tab === 'grid' && <PostGrid keys={posts} src="profile" pins={p.pins} empty={<Empty icon="camera" title={own ? t('Поделитесь первым фото или видео') : t('Пока нет публикаций')} />} />}
            {tab === 'reels' && <PostGrid keys={posts.filter((k) => getPost(k)?.t === 'video')} src="profile" empty={<Empty icon="reels" title={t('Пока нет рилсов')} />} />}
            {tab === 'tagged' && <PostGrid keys={tagged} src="profile" empty={<Empty icon="user" title={t('Пока нет отметок')} />} />}
            {tab === 'saved' && own && <PostGrid keys={userKeys(uid, 'sv')} src="profile" empty={<Empty icon="bookmark" title={t('Здесь появится сохранённое')} />} />}
          </>
        )}
      </div>
    </div>
  );
}

function PostsScreen({ postKey, list, src, openComments, visible }: { postKey: string; list?: string[]; src?: string; openComments?: boolean; visible: boolean }): React.ReactElement {
  const keys = list && list.includes(postKey) ? list : [postKey];
  const box = useRef<HTMLDivElement | null>(null);
  useLayoutEffect(() => {
    const el = box.current?.querySelector(`[data-k="${CSS.escape(postKey)}"]`);
    el?.scrollIntoView();
  }, []);
  useEffect(() => {
    if (openComments) sheet(() => <CommentsSheet postKey={postKey} />, true);
  }, []);
  return (
    <div className="screen">
      <header className="hdr">
        <button className="icon-btn" onClick={back} aria-label={t('Назад')}>
          <Icon n="back" />
        </button>
        <div className="hdr-title">
          <b>{t('Публикации')}</b>
        </div>
        <span />
      </header>
      <div className="scroll" ref={box}>
        {keys.map((k) => (
          <div key={k} data-k={k}>
            <PostCard postKey={k} active={visible} src={src || 'post'} />
          </div>
        ))}
      </div>
    </div>
  );
}

function DmsScreen(): React.ReactElement {
  return (
    <div className="screen">
      <header className="hdr">
        <button className="icon-btn" onClick={back} aria-label={t('Назад')}>
          <Icon n="back" />
        </button>
        <div className="hdr-title">
          <b>{S.u[S.uid || '']?.un || t('Сообщения')}</b>
        </div>
        <div className="hdr-right">
          <button className="icon-btn" onClick={() => go('newchat')} aria-label={t('Новое сообщение')}>
            <Icon n="edit" />
          </button>
        </div>
      </header>
      <div className="scroll">
        <ChatList />
      </div>
    </div>
  );
}

function renderSurat(s: Screen, visible: boolean): React.ReactNode | undefined {
  const p = s.props as Record<string, never>;
  if (s.name === 'post') return <PostsScreen postKey={p.postKey} list={p.list} src={p.src} openComments={p.openComments} visible={visible} />;
  if (s.name === 'profile') return <SuratProfile uid={p.uid} />;
  if (s.name === 'dms') return <DmsScreen />;
  return undefined;
}

function BottomNav(): React.ReactElement {
  useStore();
  const me = S.uid;
  const item = (k: string, icon: string, label: string): React.ReactElement => (
    <button className={cx('nav-item', nav.tab === k && 'on')} onClick={() => setTab(k)} aria-label={label}>
      <Icon n={icon} size={27} sw={nav.tab === k ? 2.4 : 1.8} fill={nav.tab === k && (k === 'home')} />
    </button>
  );
  return (
    <nav className={cx('bottom-nav', nav.tab === 'reels' && 'on-video')}>
      {item('home', 'home', t('Главная'))}
      {item('explore', 'search', t('Поиск'))}
      <button className="nav-item" onClick={() => go('create')} aria-label={t('Создать')}>
        <Icon n="plus" size={27} />
      </button>
      {item('reels', 'reels', t('Рилсы'))}
      <button className={cx('nav-item', nav.tab === 'profile' && 'on')} onClick={() => setTab('profile')} aria-label={t('Профиль')}>
        <span className={cx('nav-av', nav.tab === 'profile' && 'on')}>
          <Avatar uid={me} size={26} />
        </span>
      </button>
    </nav>
  );
}

function App(): React.ReactElement {
  useStore();
  useTheme('system');
  useDeepLinks();
  const noScreen = nav.stack.length === 0;
  return (
    <>
      <BootGate logo={<Logo />} onboarding={<Onboarding logo={<Logo />} />}>
        <div className="app">
          <div className="tab-area">
            <div className="tab-pane" hidden={nav.tab !== 'home'}>
              <Home visible={noScreen && nav.tab === 'home'} />
            </div>
            {nav.tab === 'explore' && (
              <div className="tab-pane">
                <Explore />
              </div>
            )}
            <div className="tab-pane" hidden={nav.tab !== 'reels'}>
              <Reels visible={noScreen && nav.sheets.length === 0 && nav.tab === 'reels'} />
            </div>
            {nav.tab === 'profile' && (
              <div className="tab-pane">
                {S.uid && S.u[S.uid] ? <SuratProfile uid={S.uid} isTab /> : <div className="screen"><ReadOnlyNote /><Empty icon="user" title={t('Профиль недоступен в режиме просмотра')} /></div>}
              </div>
            )}
          </div>
          <BottomNav />
          <Stack render={renderSurat} />
        </div>
      </BootGate>
      <Overlays />
    </>
  );
}

createRoot(document.getElementById('root')!).render(<App />);
void boot();
