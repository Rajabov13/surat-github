import React, { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { deletePost, follow, like, notInterested, pinPost, recordView, save, saveSettings } from '../core/actions';
import { canSee, followState, getPost, type PostX } from '../core/derive';
import { S, useStore } from '../core/store';
import { cx, fmtCount, fmtDur, has, haptic, rid } from '../core/util';
import { CommentsSheet } from './comments';
import { t } from './i18n';
import { Icon } from './icons';
import { act, Avatar, Empty, errToast, MenuItem, RichText } from './kit';
import { closeAllSheets, closeSheet, confirmDialog, go, sheet, toast } from './nav';
import { audio, msrc, PostMedia, soundTitle, clipLen } from './player';
import { canDownload, downloadPost, ReportSheet, ShareSheet } from './share';

export function likePost(key: string, on: boolean): void {
  if (on) haptic(15);
  void act(() => like(key, on));
}

export function PostMenu({ postKey, rate, setRate }: { postKey: string; rate?: number; setRate?: (r: number) => void }): React.ReactElement {
  useStore();
  const p = getPost(postKey);
  if (!p) return <div className="pad">{t('Публикация недоступна')}</div>;
  const me = S.uid;
  const mine = p.by === me;
  const saved = me ? has(S.g[me]?.sv, postKey) : false;
  const allowDuet = p.t === 'video' && !p.duet && p.du && S.u[p.by]?.duet !== 'none';
  const auto = !!S.me.set?.auto;
  return (
    <div>
      {setRate && (
        <div className="pad-x speed-row">
          <span className="muted">{t('Скорость')}</span>
          {[0.5, 1, 1.5, 2].map((r) => (
            <button key={r} className={cx('chip', rate === r && 'on')} onClick={() => (setRate(r), closeSheet())}>
              {r}x
            </button>
          ))}
        </div>
      )}
      {!mine && <MenuItem icon="eyeoff" label={t('Не интересно')} onClick={() => void act(() => notInterested(postKey), t('Будем показывать меньше похожего')).then(closeAllSheets)} />}
      <MenuItem icon="bookmark" label={saved ? t('Убрать из избранного') : t('Добавить в избранное')} onClick={() => (void act(() => save(postKey, !saved), saved ? t('Удалено из избранного') : t('Сохранено в избранное')), closeSheet())} />
      {canDownload(p) && p.t !== 'text' && <MenuItem icon="download" label={t('Сохранить видео')} onClick={() => (closeSheet(), void downloadPost(p))} />}
      {allowDuet && <MenuItem icon="duet" label={t('Дуэт')} onClick={() => (closeAllSheets(), go('create', { duet: postKey }))} />}
      {allowDuet && p.stc && <MenuItem icon="stitch" label={t('Стежок')} onClick={() => (closeAllSheets(), go('create', { stitch: postKey }))} />}
      <MenuItem icon="refresh" label={t('Автопрокрутка')} right={<span className={cx('pill', auto && 'on')}>{auto ? t('Вкл') : t('Выкл')}</span>} onClick={() => void act(() => saveSettings({ auto: !auto }))} />
      {mine && (
        <>
          <MenuItem icon="edit" label={t('Редактировать')} onClick={() => (closeAllSheets(), go('editpost', { postKey }))} />
          <MenuItem icon="chart" label={t('Статистика')} onClick={() => (closeAllSheets(), go('poststats', { postKey }))} />
          <MenuItem icon="pin" label={S.u[me!]?.pins?.includes(p.id) ? t('Открепить из профиля') : t('Закрепить в профиле')} onClick={() => (void act(() => pinPost(p.id, !S.u[me!]?.pins?.includes(p.id))), closeSheet())} />
          <MenuItem
            icon="trash"
            danger
            label={t('Удалить')}
            onClick={async () => {
              closeSheet();
              if (await confirmDialog(t('Удалить публикацию?'), t('Удалить'), t('Это действие нельзя отменить'))) void act(() => deletePost(p.id), t('Публикация удалена'));
            }}
          />
        </>
      )}
      {!mine && <MenuItem icon="flag" label={t('Пожаловаться')} onClick={() => sheet(() => <ReportSheet k="post" id={postKey} />)} />}
    </div>
  );
}

interface ItemProps {
  postKey: string;
  active: boolean;
  near: boolean;
  src: string;
  via?: string;
  onLooped?: () => void;
  compactBottom?: boolean;
}

export function FeedItem({ postKey, active, near, src, via, onLooped }: ItemProps): React.ReactElement | null {
  useStore();
  const p = getPost(postKey);
  const [paused, setPaused] = useState(false);
  const [rate, setRate] = useState(1);
  const [more, setMore] = useState(false);
  const [hearts, setHearts] = useState<{ id: string; x: number; y: number; r: number }[]>([]);
  const [seek, setSeek] = useState<{ t: number; n: number } | null>(null);
  const [scrub, setScrub] = useState<{ t: number; x: number } | null>(null);
  const prog = useRef<HTMLDivElement | null>(null);
  const totalRef = useRef(0);
  const watch = useRef({ ms: 0, since: 0, max: 0, loops: 0 });
  const tap = useRef<{ t: number; timer: number; lp: number; x: number; y: number; moved: boolean }>({ t: 0, timer: 0, lp: 0, x: 0, y: 0, moved: false });

  const flush = (): void => {
    const w = watch.current;
    if (w.since) {
      w.ms += performance.now() - w.since;
      w.since = 0;
    }
    if (w.ms >= 1000 && p) {
      const dur = p.dur || totalRef.current || 1;
      void recordView(postKey, w.ms, w.loops > 0 || w.max >= dur * 0.9, w.max, src);
    }
    watch.current = { ms: 0, since: 0, max: 0, loops: 0 };
  };
  useEffect(() => {
    if (active && !paused) watch.current.since = performance.now();
    return () => {
      const w = watch.current;
      if (w.since) {
        w.ms += performance.now() - w.since;
        w.since = 0;
      }
    };
  }, [active, paused]);
  useEffect(() => {
    if (!active) {
      flush();
      setPaused(false);
    }
  }, [active]);
  useEffect(() => () => flush(), []);

  if (!p || !canSee(p)) {
    return <div className="feed-item feed-gone">{t('Публикация недоступна')}</div>;
  }
  const me = S.uid;
  const liked = me ? has(S.g[me]?.lk, postKey) : false;
  const saved = me ? has(S.g[me]?.sv, postKey) : false;
  const fstate = me && me !== p.by ? followState(me, p.by) : 'yes';
  const author = S.u[p.by];
  const total = p.t === 'video' ? (p.clips || []).reduce((a, c) => a + clipLen(c), 0) + (p.stitch ? p.stitch.e - p.stitch.s : 0) : 0;

  const onTime = (cur: number, tot: number): void => {
    totalRef.current = tot;
    if (cur > watch.current.max) watch.current.max = cur;
    if (prog.current && !scrub) prog.current.style.transform = `scaleX(${tot ? cur / tot : 0})`;
  };
  const onLoop = (): void => {
    watch.current.loops++;
    onLooped?.();
  };

  const onPointerDown = (e: React.PointerEvent): void => {
    if ((e.target as HTMLElement).closest('button, a, .no-tap, .ov-poll, .ov-chip, .photos .dots')) return;
    tap.current.x = e.clientX;
    tap.current.y = e.clientY;
    tap.current.moved = false;
    const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    tap.current.lp = window.setTimeout(() => {
      tap.current.lp = -1;
      haptic(20);
      sheet(() => <PostMenu postKey={postKey} rate={rate} setRate={setRate} />);
    }, 550);
    (e.currentTarget as HTMLElement).dataset.x = String(x);
    (e.currentTarget as HTMLElement).dataset.y = String(y);
  };
  const onPointerMove = (e: React.PointerEvent): void => {
    if (Math.abs(e.clientX - tap.current.x) + Math.abs(e.clientY - tap.current.y) > 12) {
      tap.current.moved = true;
      if (tap.current.lp > 0) clearTimeout(tap.current.lp);
    }
  };
  const onPointerUp = (e: React.PointerEvent): void => {
    if (tap.current.lp === -1) {
      tap.current.lp = 0;
      return;
    }
    if (tap.current.lp > 0) clearTimeout(tap.current.lp);
    tap.current.lp = 0;
    if (tap.current.moved) return;
    if ((e.target as HTMLElement).closest('button, a, .no-tap, .ov-poll, .ov-chip')) return;
    const el = e.currentTarget as HTMLElement;
    const x = Number(el.dataset.x);
    const y = Number(el.dataset.y);
    const nowT = performance.now();
    if (nowT - tap.current.t < 300) {
      clearTimeout(tap.current.timer);
      tap.current.t = 0;
      const id = rid(6);
      setHearts((h) => [...h, { id, x, y, r: Math.random() * 30 - 15 }]);
      setTimeout(() => setHearts((h) => h.filter((q) => q.id !== id)), 900);
      if (!liked) likePost(postKey, true);
      else haptic(10);
      return;
    }
    tap.current.t = nowT;
    const justUnlocked = audio.justUnlocked;
    tap.current.timer = window.setTimeout(() => {
      if (!justUnlocked) setPaused((v) => !v);
    }, 280);
  };

  const scrubAt = (clientX: number, el: HTMLElement): number => {
    const r = el.getBoundingClientRect();
    return Math.max(0, Math.min(1, (clientX - r.left) / r.width)) * (totalRef.current || total);
  };
  const seekable = p.t === 'video';
  const firstClip = p.clips?.[0];

  return (
    <div className="feed-item" onPointerDown={onPointerDown} onPointerMove={onPointerMove} onPointerUp={onPointerUp} onContextMenu={(e) => e.preventDefault()}>
      {near ? <PostMedia post={p} active={active} paused={paused} rate={rate} eager={near} onTime={onTime} onLoop={onLoop} seek={seek} /> : <div className="media" />}
      {paused && active && (
        <div className="paused-ic">
          <Icon n="play" size={64} fill />
        </div>
      )}
      {hearts.map((h) => (
        <span key={h.id} className="burst" style={{ left: h.x, top: h.y, ['--r' as string]: `${h.r}deg` }}>
          <Icon n="heart" size={96} fill />
        </span>
      ))}
      <div className="side">
        <div className="side-av">
          <Avatar uid={p.by} size={48} ring onClick={() => go('profile', { uid: p.by })} />
          {me && fstate === 'no' && (
            <button className="side-plus" onClick={() => void act(() => follow(p.by, true))} aria-label={t('Подписаться')}>
              <Icon n="plus" size={14} sw={3} />
            </button>
          )}
        </div>
        <button className={cx('side-btn', liked && 'liked')} onClick={() => likePost(postKey, !liked)} aria-label={t('Нравится')}>
          <Icon n="heart" size={34} fill />
          <small>{fmtCount(p.likes)}</small>
        </button>
        <button className="side-btn" onClick={() => sheet(() => <CommentsSheet postKey={postKey} />, true)} aria-label={t('Комментарии')}>
          <Icon n="comment" size={32} fill />
          <small>{p.cm ? fmtCount(p.comments) : '—'}</small>
        </button>
        <button className={cx('side-btn', saved && 'saved')} onClick={() => void act(() => save(postKey, !saved), saved ? undefined : t('Сохранено в избранное'))} aria-label={t('Сохранить')}>
          <Icon n="bookmark" size={30} fill />
          <small>{fmtCount(p.saves)}</small>
        </button>
        <button className="side-btn" onClick={() => sheet(() => <ShareSheet postKey={postKey} />)} aria-label={t('Поделиться')}>
          <Icon n="share" size={30} fill />
          <small>{fmtCount(p.shares + p.reposts)}</small>
        </button>
        {p.soundKey && (
          <button className={cx('disc', active && !paused && 'spinning')} onClick={() => go('sound', { key: p.soundKey })} aria-label={t('Звук')}>
            <Avatar uid={p.soundKey.split(':')[1]?.split('~')[0]} size={30} />
          </button>
        )}
      </div>
      <div className="bottom">
        {via && (
          <div className="via">
            <Icon n="repost" size={14} /> {t('{u} сделал(а) репост', { u: S.u[via]?.nm || '' })}
          </div>
        )}
        {p.priv !== 'all' && <div className="via">{p.priv === 'me' ? <><Icon n="lock" size={14} /> {t('Только я')}</> : <><Icon n="users" size={14} /> {t('Друзья')}</>}</div>}
        {p.at && p.at > Date.now() && <div className="via"><Icon n="clock" size={14} /> {t('Запланировано')}: {new Date(p.at).toLocaleString()}</div>}
        <a className="b-name" onClick={() => go('profile', { uid: p.by })}>
          @{author?.un}
        </a>
        {p.cap && p.t !== 'text' && (
          <div className={cx('b-cap', more && 'open')}>
            <RichText text={p.cap} />
          </div>
        )}
        {p.cap.length > 90 && p.t !== 'text' && (
          <button className="link-btn b-more" onClick={() => setMore(!more)}>
            {more ? t('Скрыть') : t('ещё')}
          </button>
        )}
        {p.t === 'text' && (p.ht || []).length > 0 && (
          <div className="b-cap">
            <RichText text={(p.ht || []).map((h) => '#' + h).join(' ')} />
          </div>
        )}
        {(p.duet || p.stitch) && (
          <a className="b-loc" onClick={() => go('post', { postKey: p.duet ? `${p.duet.au}~${p.duet.pid}` : `${p.stitch!.au}~${p.stitch!.pid}` })}>
            <Icon n={p.duet ? 'duet' : 'stitch'} size={14} /> {p.duet ? t('Дуэт с @{u}', { u: S.u[p.duet.au]?.un || '' }) : t('Стежок с @{u}', { u: S.u[p.stitch!.au]?.un || '' })}
          </a>
        )}
        {p.loc && (
          <div className="b-loc">
            <Icon n="location" size={14} /> {p.loc}
          </div>
        )}
        {p.tags && p.tags.length > 0 && (
          <div className="b-loc">
            <Icon n="user" size={14} />{' '}
            {p.tags.map((u) => (
              <a key={u} onClick={() => go('profile', { uid: u })}>
                @{S.u[u]?.un}{' '}
              </a>
            ))}
          </div>
        )}
        {p.soundKey && (
          <a className="b-sound" onClick={() => go('sound', { key: p.soundKey })}>
            <Icon n="music" size={14} />
            <span className="marquee">
              <span>{soundTitle(p.soundKey)}</span>
            </span>
          </a>
        )}
      </div>
      {seekable && (
        <div
          className={cx('prog', scrub && 'scrubbing')}
          onPointerDown={(e) => {
            e.stopPropagation();
            (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
            setScrub({ t: scrubAt(e.clientX, e.currentTarget as HTMLElement), x: e.clientX });
          }}
          onPointerMove={(e) => scrub && setScrub({ t: scrubAt(e.clientX, e.currentTarget as HTMLElement), x: e.clientX })}
          onPointerUp={(e) => {
            e.stopPropagation();
            if (scrub) setSeek({ t: scrub.t, n: (seek?.n || 0) + 1 });
            setScrub(null);
          }}
          onPointerCancel={() => setScrub(null)}
        >
          <div className="prog-track">
            <div className="prog-fill" ref={prog} style={scrub ? { transform: `scaleX(${scrub.t / (totalRef.current || total || 1)})` } : undefined} />
          </div>
          {scrub && (
            <div className="scrub-pop" style={{ left: Math.max(60, Math.min(window.innerWidth - 60, scrub.x)) }}>
              {total > 60 && firstClip && p.clips!.length === 1 && <ScrubFrame src={msrc(firstClip.a)} time={firstClip.s + scrub.t * (firstClip.r || 1)} />}
              <b>
                {fmtDur(scrub.t)} / {fmtDur(totalRef.current || total)}
              </b>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function ScrubFrame({ src, time }: { src: string; time: number }): React.ReactElement {
  const v = useRef<HTMLVideoElement | null>(null);
  useEffect(() => {
    if (v.current && isFinite(time)) v.current.currentTime = time;
  }, [time]);
  return <video ref={v} className="scrub-frame" src={src} muted playsInline preload="auto" />;
}

export function VerticalFeed({
  keys,
  src,
  via,
  onRefresh,
  empty,
  visible,
  initial = 0,
  end,
}: {
  keys: string[];
  src: string;
  via?: Record<string, string>;
  onRefresh?: () => void;
  empty?: React.ReactNode;
  visible: boolean;
  initial?: number;
  end?: React.ReactNode;
}): React.ReactElement {
  useStore();
  const box = useRef<HTMLDivElement | null>(null);
  const [h, setH] = useState(0);
  const [idx, setIdx] = useState(initial);
  const [pull, setPull] = useState(0);
  const touch = useRef<number | null>(null);
  const saver = !!S.me.set?.saver;
  const ahead = saver ? 1 : 3;
  const n = keys.length + (end ? 1 : 0);

  useLayoutEffect(() => {
    const el = box.current;
    if (!el) return;
    const ro = new ResizeObserver(() => setH(el.clientHeight));
    ro.observe(el);
    setH(el.clientHeight);
    return () => ro.disconnect();
  }, []);
  useLayoutEffect(() => {
    if (h && box.current && initial) box.current.scrollTop = initial * h;
  }, [h > 0]);
  useEffect(() => {
    if (!visible) return;
    const onKey = (e: KeyboardEvent): void => {
      const tag = (e.target as HTMLElement)?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA') return;
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        e.preventDefault();
        box.current?.scrollTo({ top: (idx + (e.key === 'ArrowDown' ? 1 : -1)) * h, behavior: 'smooth' });
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [visible, idx, h]);

  const goNext = (): void => {
    if (S.me.set?.auto && box.current) box.current.scrollTo({ top: (idx + 1) * h, behavior: 'smooth' });
  };

  if (!keys.length && !end) return <div className="vfeed vfeed-empty">{empty || <Empty icon="video" title={t('Пока нет видео — снимите первое!')} />}</div>;

  const items: number[] = [];
  for (let i = Math.max(0, idx - 1); i <= Math.min(n - 1, idx + ahead); i++) items.push(i);

  return (
    <div
      className="vfeed"
      ref={box}
      onScroll={(e) => {
        const el = e.currentTarget;
        if (!h) return;
        const i = Math.round(el.scrollTop / h);
        if (i !== idx) setIdx(i);
      }}
      onTouchStart={(e) => {
        if (box.current && box.current.scrollTop <= 0 && onRefresh) touch.current = e.touches[0].clientY;
      }}
      onTouchMove={(e) => {
        if (touch.current !== null) setPull(Math.max(0, Math.min(110, e.touches[0].clientY - touch.current)));
      }}
      onTouchEnd={() => {
        if (pull > 70 && onRefresh) {
          onRefresh();
          toast(t('Лента обновлена'));
        }
        touch.current = null;
        setPull(0);
      }}
    >
      {pull > 0 && (
        <div className="pull" style={{ transform: `translateY(${pull - 40}px)`, opacity: pull / 70 }}>
          <Icon n="refresh" size={22} />
        </div>
      )}
      <div style={{ height: n * h, position: 'relative' }}>
        {h > 0 &&
          items.map((i) => (
            <div key={i < keys.length ? keys[i] : 'end'} className="vitem" style={{ top: i * h, height: h }}>
              {i < keys.length ? (
                <FeedItem postKey={keys[i]} active={visible && i === idx} near={Math.abs(i - idx) <= ahead} src={src} via={via?.[keys[i]]} onLooped={i === idx ? goNext : undefined} />
              ) : (
                end
              )}
            </div>
          ))}
      </div>
    </div>
  );
}

export function FeedEnd({ onRefresh }: { onRefresh: () => void }): React.ReactElement {
  return (
    <div className="feed-end">
      <Empty icon="check" title={t('Вы всё посмотрели')} text={t('Новые публикации появятся здесь, как только их опубликуют')}>
        <button className="btn btn-primary" onClick={onRefresh}>
          {t('Обновить ленту')}
        </button>
      </Empty>
    </div>
  );
}

export function openPost(postKey: string, list?: string[], src = 'profile'): void {
  const p = getPost(postKey);
  if (!p) {
    errToast(new Error('missing'));
    return;
  }
  go('post', { postKey, list, src });
}
export type { PostX };
