// Access to the claude.ai runtime capabilities (db, user, assets, room, downloads).
export type DB = ClaudeCapabilityMap['db'];
export type DocRef = ReturnType<DB['doc']>;
export type UserNs = ClaudeCapabilityMap['user'];
export type AssetsNs = ClaudeCapabilityMap['assets'];
export type RoomNs = ClaudeCapabilityMap['room'];
export type DownloadsNs = ClaudeCapabilityMap['downloads'];

export interface Caps {
  db: DB | null;
  user: UserNs | null;
  assets: AssetsNs | null;
  room: RoomNs | null;
  downloads: DownloadsNs | null;
}

export const caps: Caps = { db: null, user: null, assets: null, room: null, downloads: null };

export async function loadCaps(): Promise<Caps> {
  const c = window.claude;
  if (!c || typeof c.use !== 'function') return caps;
  const [db, user, assets, room, downloads] = await Promise.all([
    c.use('db').catch(() => null),
    c.use('user').catch(() => null),
    c.use('assets').catch(() => null),
    c.use('room').catch(() => null),
    c.use('downloads').catch(() => null),
  ]);
  caps.db = db;
  caps.user = user;
  caps.assets = assets;
  caps.room = room;
  caps.downloads = downloads;
  return caps;
}

/** Ask the viewer to save a generated file. Resolves false when declined or unavailable. */
export async function saveFile(filename: string, data: Blob | string): Promise<boolean> {
  if (!caps.downloads) return false;
  try {
    await caps.downloads.save({ filename, data });
    return true;
  } catch {
    return false;
  }
}
