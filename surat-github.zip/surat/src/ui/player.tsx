import React, { useEffect, useMemo, useRef, useState } from 'react';
import { vote } from '../core/actions';
import { agg, getPost, uidByName } from '../core/derive';
import { S, useStore } from '../core/store';
import type { Adjust, Clip, Overlay, Post, SoundRef } from '../core/types';
import { blob, cx, live, pkey } from '../core/util';
import { t } from './i18n';
import { act } from './kit';
import { go } from './nav';

export const FONTS = [
  "'Manrope', system-ui, sans-serif",
  "'Unbounded', system-ui, sans-serif",
  "'Caveat', cursive",
  "'Playfair Display', Georgia, serif",
  "'Russo One', system-ui, sans-serif",
  "'Pacifico', cursive",
  "'Comfortaa', system-ui, sans-serif",
  "'Oswald', 'Arial Narrow', sans-serif",
  "'Lobster', cursive",
  "'PT Mono', ui-monospace, monospace",
  "'Rubik Mono One', system-ui, sans-serif",
  "'Neucha', cursive",
];
export const FONT_NAMES = ['Classic', 'Bold', 'Hand', 'Serif', 'Block', 'Retro', 'Round', 'Tall', 'Script', 'Mono', 'Poster', 'Sketch'];

export const FILTERS: Record<string, string> = {
  none: '',
  vivid: 'saturate(1.45) contrast(1.08)',
  warm: 'sepia(.22) saturate(1.25) brightness(1.03)',
  cool: 'saturate(1.05) hue-rotate(-12deg) brightness(1.04)',
  mono: 'grayscale(1)',
  noir: 'grayscale(1) contrast(1.45) brightness(.92)',
  vintage: 'sepia(.5) contrast(.92) saturate(.9)',
  fade: 'contrast(.84) brightness(1.1) saturate(.78)',
  pop: 'saturate(1.9) contrast(1.15)',
  dusk: 'hue-rotate(-20deg) saturate(1.3) brightness(.95)',
};

export function filterCss(a?: Adjust): string {
  if (!a) return '';
  const parts: string[] = [];
  if (a.f && FILTERS[a.f]) parts.push(FILTERS[a.f]);
  if (a.b) parts.push(`brightness(${1 + a.b / 100})`);
  if (a.c) parts.push(`contrast(${1 + a.c / 100})`);
  if (a.s) parts.push(`saturate(${1 + a.s / 100})`);
  if (a.w) parts.push(a.w > 0 ? `sepia(${a.w / 160}) hue-rotate(${-a.w / 8}deg)` : `hue-rotate(${-a.w / 3}deg) saturate(${1 - a.w / 300})`);
  return parts.join(' ');
}

export const msrc = (a?: string): string => (!a ? '' : a.startsWith('blob:') || a.startsWith('data:') ? a : blob(a));

// ---- autoplay with sound needs one user gesture ----
export const audio = { unlocked: false, muted: false, justUnlocked: false };
/** Global sound on/off (used by card feeds); re-applies to whatever is playing. */
export function setMuted(m: boolean): void {
  audio.muted = m;
  window.dispatchEvent(new Event('audiounlock'));
}
if (typeof window !== 'undefined') {
  const unlock = (): void => {
    audio.unlocked = true;
    audio.justUnlocked = true;
    setTimeout(() => (audio.justUnlocked = false), 450);
    window.removeEventListener('pointerdown', unlock, true);
    window.removeEventListener('keydown', unlock, true);
    setTimeout(() => window.dispatchEvent(new Event('audiounlock')), 0);
  };
  window.addEventListener('pointerdown', unlock, true);
  window.addEventListener('keydown', unlock, true);
}

function safePlay(el: HTMLMediaElement | null, wantSound: boolean): void {
  if (!el) return;
  el.muted = !wantSound || !audio.unlocked || audio.muted || el.dataset.forceMute === '1';
  const p = el.play();
  if (p)
    p.catch(() => {
      if (!el.muted) {
        el.muted = true;
        void el.play().catch(() => undefined);
      }
    });
}

export interface SoundSrc {
  url: string;
  start: number;
  vol: number;
}
export function resolveSound(ref?: SoundRef): SoundSrc | null {
  if (!ref) return null;
  if (ref.k === 's') {
    const tr = S.p[ref.au]?.tracks?.[ref.id];
    if (!tr) return null;
    return { url: msrc(tr.a), start: ref.st || 0, vol: ref.v ?? 1 };
  }
  const origin = getPost(pkey(ref.au, ref.id));
  const c = origin?.clips?.[0];
  if (!c) return null;
  return { url: msrc(c.a), start: c.s + (ref.st || 0), vol: ref.v ?? 1 };
}

/** Plays a post's added sound in sync with its media. */
function useSound(src: SoundSrc | null, playing: boolean, restart: number): void {
  const el = useRef<HTMLAudioElement | null>(null);
  useEffect(() => {
    if (!src) return;
    const a = new Audio();
    a.preload = 'auto';
    a.loop = true;
    a.src = src.url;
    a.volume = Math.max(0, Math.min(1, src.vol));
    el.current = a;
    return () => {
      a.pause();
      a.removeAttribute('src');
      a.load();
      el.current = null;
    };
  }, [src?.url]);
  useEffect(() => {
    const a = el.current;
    if (!a || !src) return;
    a.volume = Math.max(0, Math.min(1, src.vol));
    if (playing) safePlay(a, true);
    else a.pause();
    const h = (): void => {
      if (playing && el.current) safePlay(el.current, true);
    };
    window.addEventListener('audiounlock', h);
    return () => window.removeEventListener('audiounlock', h);
  }, [playing, src?.vol, src?.url]);
  useEffect(() => {
    const a = el.current;
    if (!a || !src) return;
    try {
      a.currentTime = src.start;
    } catch {
      /* not seekable yet */
    }
    if (playing) safePlay(a, true);
  }, [restart, src?.start]);
}

export interface MediaProps {
  post: Post;
  active: boolean;
  paused?: boolean;
  rate?: number;
  fit?: 'cover' | 'contain';
  eager?: boolean;
  seek?: { t: number; n: number } | null;
  onTime?: (cur: number, total: number) => void;
  onLoop?: () => void;
  onPhoto?: (i: number, n: number) => void;
  overlays?: boolean;
  className?: string;
}

export function PostMedia(props: MediaProps): React.ReactElement {
  const { post } = props;
  const style = { filter: filterCss(post.adj) || undefined };
  let body: React.ReactElement;
  if (post.t === 'text') body = <TextMedia {...props} />;
  else if (post.t === 'photo') body = <PhotoMedia {...props} />;
  else if (post.duet) body = <DuetMedia {...props} />;
  else body = <VideoMedia {...props} />;
  return (
    <div className={cx('media', props.fit === 'contain' && 'fit-contain', props.className)}>
      <div className="media-inner" style={style}>
        {body}
      </div>
      {props.overlays !== false && <Overlays post={post} active={props.active} />}
      {post.vreply && (
        <div className="vreply-sticker">
          <small>{t('Ответ на комментарий')}</small>
          <span>{post.vreply.t}</span>
        </div>
      )}
    </div>
  );
}

function stitchClips(post: Post): Clip[] {
  const own = post.clips || [];
  if (!post.stitch) return own;
  const orig = getPost(pkey(post.stitch.au, post.stitch.pid));
  const oc = orig?.clips?.[0];
  if (!oc) return own;
  return [{ a: oc.a, s: oc.s + post.stitch.s, e: oc.s + post.stitch.e, r: 1, d: oc.d }, ...own];
}

export const clipLen = (c: Clip): number => Math.max(0.1, (c.e - c.s) / (c.r || 1));
export const totalLen = (clips: Clip[]): number => clips.reduce((a, c) => a + clipLen(c), 0);

export function VideoMedia({ post, active, paused, rate = 1, eager, seek, onTime, onLoop, fit }: MediaProps): React.ReactElement {
  const clips = useMemo(() => stitchClips(post), [post]);
  const total = totalLen(clips);
  const [ci, setCi] = useState(0);
  const ciRef = useRef(0);
  ciRef.current = ci;
  const vids = useRef<(HTMLVideoElement | null)[]>([]);
  const [restart, setRestart] = useState(0);
  const [ready, setReady] = useState(false);
  const playing = active && !paused;
  const sound = resolveSound(post.snd);
  const ovol = post.snd ? post.ovol ?? 0 : post.ovol ?? 1;
  useSound(sound, playing, restart);
  const offsets = useMemo(() => {
    const o: number[] = [];
    let acc = 0;
    for (const c of clips) {
      o.push(acc);
      acc += clipLen(c);
    }
    return o;
  }, [clips]);

  const startClip = (i: number, play: boolean): void => {
    const v = vids.current[i];
    const c = clips[i];
    if (!v || !c) return;
    try {
      v.currentTime = c.s;
    } catch {
      /* not ready */
    }
    v.playbackRate = (c.r || 1) * rate;
    if (play) safePlay(v, ovol > 0);
  };
  const next = (): void => {
    const i = ciRef.current;
    vids.current[i]?.pause();
    if (i + 1 < clips.length) {
      setCi(i + 1);
      startClip(i + 1, true);
    } else {
      onLoop?.();
      setCi(0);
      startClip(0, true);
      setRestart((r) => r + 1);
    }
  };

  useEffect(() => {
    const v = vids.current[ci];
    if (!v) return;
    v.volume = Math.max(0, Math.min(1, ovol));
    v.dataset.forceMute = ovol <= 0 ? '1' : '0';
    v.playbackRate = (clips[ci]?.r || 1) * rate;
    if (playing) safePlay(v, ovol > 0);
    else v.pause();
    const h = (): void => {
      if (playing) safePlay(vids.current[ciRef.current], ovol > 0);
    };
    window.addEventListener('audiounlock', h);
    return () => window.removeEventListener('audiounlock', h);
  }, [playing, ci, rate, ovol]);

  useEffect(() => {
    if (!active) {
      // rewind when scrolled away so the next visit starts at the beginning
      vids.current.forEach((v) => v?.pause());
      setCi(0);
      const v0 = vids.current[0];
      if (v0 && clips[0]) {
        try {
          v0.currentTime = clips[0].s;
        } catch {
          /* ignore */
        }
      }
      setRestart((r) => r + 1);
    }
  }, [active]);

  useEffect(() => {
    if (!seek) return;
    let i = clips.length - 1;
    for (let k = 0; k < clips.length; k++)
      if (seek.t < offsets[k] + clipLen(clips[k])) {
        i = k;
        break;
      }
    vids.current.forEach((v, k) => k !== i && v?.pause());
    setCi(i);
    const v = vids.current[i];
    const c = clips[i];
    if (v && c) {
      v.currentTime = c.s + (seek.t - offsets[i]) * (c.r || 1);
      if (playing) safePlay(v, ovol > 0);
    }
  }, [seek?.n]);

  useEffect(() => {
    if (!active || !onTime) return;
    let raf = 0;
    const tick = (): void => {
      const i = ciRef.current;
      const v = vids.current[i];
      const c = clips[i];
      if (v && c) {
        const cur = offsets[i] + Math.max(0, (v.currentTime - c.s) / (c.r || 1));
        onTime(Math.min(total, cur), total);
        if (v.currentTime >= c.e - 0.04 && !v.paused) next();
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [active, clips, total, onTime]);

  return (
    <>
      {post.poster && !ready && <img className="media-poster" src={msrc(post.poster)} alt="" />}
      {clips.map((c, i) => {
        const near = active || eager;
        return (
          <video
            key={i + c.a}
            ref={(el) => (vids.current[i] = el)}
            className={cx('media-video', i !== ci && 'hidden-clip', fit === 'contain' && 'contain')}
            src={near || i === 0 ? msrc(c.a) + `#t=${c.s.toFixed(2)}` : undefined}
            poster={i === 0 && post.poster ? msrc(post.poster) : undefined}
            playsInline
            muted
            preload={near ? 'auto' : 'metadata'}
            onPlaying={() => setReady(true)}
            onTimeUpdate={(e) => {
              if (!onTime && i === ciRef.current && e.currentTarget.currentTime >= c.e - 0.04) next();
            }}
            onEnded={() => i === ciRef.current && next()}
          />
        );
      })}
    </>
  );
}

function DuetMedia(props: MediaProps): React.ReactElement {
  const { post, active, paused } = props;
  const d = post.duet!;
  const orig = getPost(pkey(d.au, d.pid));
  const ov = useRef<HTMLVideoElement | null>(null);
  const oc = orig?.clips?.[0];
  const playing = active && !paused;
  useEffect(() => {
    const v = ov.current;
    if (!v) return;
    if (playing) safePlay(v, true);
    else v.pause();
  }, [playing]);
  const onTime = (cur: number, total: number): void => {
    const v = ov.current;
    if (v && oc) {
      const want = oc.s + cur;
      if (want < oc.e && Math.abs(v.currentTime - want) > 0.35) v.currentTime = want;
    }
    props.onTime?.(cur, total);
  };
  const onLoop = (): void => {
    if (ov.current && oc) ov.current.currentTime = oc.s;
    props.onLoop?.();
  };
  const left = oc ? <video ref={ov} className="media-video" src={msrc(oc.a) + `#t=${oc.s}`} poster={orig?.poster ? msrc(orig.poster) : undefined} playsInline muted preload="auto" /> : <div className="media-missing">{t('Оригинал удалён')}</div>;
  const right = <VideoMedia {...props} onTime={onTime} onLoop={onLoop} />;
  return (
    <div className={cx('duet', 'duet-' + d.lay)}>
      <div className="duet-a">{d.lay === 'rl' ? right : left}</div>
      <div className="duet-b">{d.lay === 'rl' ? left : right}</div>
    </div>
  );
}

function PhotoMedia({ post, active, paused, onPhoto, onTime, fit }: MediaProps): React.ReactElement {
  const ph = post.ph || [];
  const [i, setI] = useState(0);
  const box = useRef<HTMLDivElement | null>(null);
  const sound = resolveSound(post.snd);
  useSound(sound, active && !paused, 0);
  useEffect(() => {
    onPhoto?.(i, ph.length);
  }, [i, ph.length]);
  useEffect(() => {
    if (!active || !onTime) return;
    const t0 = performance.now();
    const total = ph.length * 3;
    const id = setInterval(() => onTime(Math.min(total, (performance.now() - t0) / 1000), total), 250);
    return () => clearInterval(id);
  }, [active]);
  const onScroll = (): void => {
    const el = box.current;
    if (!el) return;
    setI(Math.round(el.scrollLeft / Math.max(1, el.clientWidth)));
  };
  return (
    <div className="photos">
      <div className="photos-track" ref={box} onScroll={onScroll}>
        {ph.map((a, k) => (
          <div className="photo-slide" key={k}>
            <img src={msrc(a)} alt="" className={fit === 'contain' ? 'contain' : undefined} loading={k < 2 || active ? 'eager' : 'lazy'} draggable={false} />
          </div>
        ))}
      </div>
      {ph.length > 1 && (
        <div className="dots">
          {ph.map((_, k) => (
            <span key={k} className={k === i ? 'on' : ''} />
          ))}
        </div>
      )}
      {ph.length > 1 && <div className="photo-count">{i + 1}/{ph.length}</div>}
    </div>
  );
}

function TextMedia({ post, active, paused }: MediaProps): React.ReactElement {
  const st = post.txt || { bg: '#222', f: 0, c: '#fff' };
  const sound = resolveSound(post.snd);
  useSound(sound, active && !paused, 0);
  const text = post.cap.replace(/#[\p{L}\p{N}_]+/gu, '').trim() || post.cap;
  const size = text.length > 160 ? 'sm' : text.length > 60 ? 'md' : 'lg';
  return (
    <div className="textpost" style={{ background: st.bg, color: st.c, fontFamily: FONTS[st.f] || FONTS[0] }}>
      <p className={'tp-' + size}>{text}</p>
    </div>
  );
}

// ---------- overlays (text, stickers, polls) ----------
function Overlays({ post, active }: { post: Post; active: boolean }): React.ReactElement | null {
  const ov = post.ov;
  const [tl, setTl] = useState(0);
  const timed = !!ov?.some((o) => o.from !== undefined || o.to !== undefined);
  useEffect(() => {
    if (!timed || !active) return;
    const t0 = performance.now();
    const total = post.dur || 15;
    const id = setInterval(() => setTl(((performance.now() - t0) / 1000) % total), 200);
    return () => clearInterval(id);
  }, [timed, active]);
  if (!ov || !ov.length) return null;
  return (
    <div className="overlays">
      {ov.map((o) => {
        const vis = !timed || ((o.from ?? 0) <= tl && tl <= (o.to ?? 1e9));
        if (!vis) return null;
        return <OverlayView key={o.id} o={o} postKey={pkey(post.by, post.id)} />;
      })}
    </div>
  );
}

export function overlayStyle(o: Overlay): React.CSSProperties {
  return {
    left: `${o.x * 100}%`,
    top: `${o.y * 100}%`,
    transform: `translate(-50%,-50%) rotate(${o.rot}deg) scale(${o.sc})`,
  };
}

export function OverlayView({ o, postKey, editing }: { o: Overlay; postKey: string; editing?: boolean }): React.ReactElement {
  useStore();
  const st = overlayStyle(o);
  if (o.k === 'poll') {
    const counts = (o.o || []).map(() => 0);
    let mine = -1;
    for (const uid in S.g) {
      const v = S.g[uid]?.pl?.[postKey];
      if (v && v - 1 < counts.length) {
        counts[v - 1]++;
        if (uid === S.uid) mine = v - 1;
      }
    }
    const sum = counts.reduce((a, b) => a + b, 0);
    return (
      <div className="ov ov-poll" style={st} onClick={(e) => e.stopPropagation()}>
        <b>{o.t}</b>
        {(o.o || []).map((opt, i) => (
          <button
            key={i}
            className={cx('poll-opt', mine === i && 'on')}
            disabled={editing}
            onClick={() => !editing && postKey && void act(() => vote(postKey, i))}
          >
            {mine >= 0 && <span className="poll-bar" style={{ width: `${sum ? (counts[i] / sum) * 100 : 0}%` }} />}
            <span className="poll-label">{opt}</span>
            {mine >= 0 && <span className="poll-pct">{sum ? Math.round((counts[i] / sum) * 100) : 0}%</span>}
          </button>
        ))}
      </div>
    );
  }
  const textStyle: React.CSSProperties = {
    color: o.c || '#fff',
    fontFamily: FONTS[o.f || 0],
    textAlign: o.al === 'l' ? 'left' : o.al === 'r' ? 'right' : 'center',
    background: o.bg === 1 ? (o.c === '#000000' || o.c === '#111111' ? '#fff' : 'rgba(0,0,0,.85)') : o.bg === 2 ? 'rgba(0,0,0,.42)' : undefined,
  };
  const click = (e: React.MouseEvent): void => {
    if (editing) return;
    if (o.k === 'mention') {
      e.stopPropagation();
      const uid = o.u || uidByName(o.t.replace('@', ''));
      if (uid) go('profile', { uid });
    } else if (o.k === 'tag') {
      e.stopPropagation();
      go('tag', { tag: o.t.replace('#', '').toLowerCase() });
    }
  };
  return (
    <div className={cx('ov', 'ov-' + o.k, o.an && o.an !== 'none' && 'an-' + o.an, (o.k === 'mention' || o.k === 'tag') && 'ov-chip')} style={st} onClick={click}>
      <span style={textStyle} className={cx(o.bg ? 'ov-bg' : 'ov-shadow')}>
        {o.t}
      </span>
    </div>
  );
}

/** Grid thumbnail for a post (cover image, text card or first photo). */
export function Thumb({ post, children, onClick }: { post: Post; children?: React.ReactNode; onClick?: () => void }): React.ReactElement {
  const img = post.poster || post.ph?.[0];
  return (
    <div className="thumb tap" onClick={onClick}>
      {img ? (
        <img src={msrc(img)} alt="" loading="lazy" style={{ filter: filterCss(post.adj) || undefined }} />
      ) : post.t === 'text' ? (
        <div className="thumb-text" style={{ background: post.txt?.bg, color: post.txt?.c, fontFamily: FONTS[post.txt?.f || 0] }}>
          {post.cap.slice(0, 80)}
        </div>
      ) : (
        <div className="thumb-text">▶</div>
      )}
      {children}
    </div>
  );
}

export function soundTitle(key: string | null): string {
  if (!key) return '';
  const s = agg().sounds.get(key);
  if (!s) return t('Оригинальный звук');
  if (s.track) return s.track.n;
  return `${t('Оригинальный звук')} — @${S.u[s.au]?.un || '…'}`;
}

export function pollResultsCount(postKey: string): number {
  let n = 0;
  for (const uid in S.g) if (live(S.g[uid]?.pl).some(([k]) => k === postKey)) n++;
  return n;
}
