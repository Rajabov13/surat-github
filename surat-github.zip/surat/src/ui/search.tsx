import React, { useState } from 'react';
import { patchMe, S, useStore } from '../core/store';
import { agg, canSee, getPost, popularity, searchPosts, searchSounds, searchTags, searchUsers, soundName, trendingTags } from '../core/derive';
import { cx, fmtCount, now, DAY } from '../core/util';
import { t } from './i18n';
import { Icon } from './icons';
import { act, Avatar, Empty, Header, Tabs, UserRow } from './kit';
import { back, go } from './nav';
import { msrc, Thumb } from './player';
import { PostGrid } from './profile';

function pushHistory(q: string): void {
  if (!S.uid || S.readOnly || !q.trim()) return;
  const sh = [q.trim(), ...(S.me.sh || []).filter((x) => x !== q.trim())].slice(0, 15);
  void patchMe({ sh }).catch(() => undefined);
}

export function SearchScreen({ q: q0 }: { q?: string }): React.ReactElement {
  useStore();
  const [q, setQ] = useState(q0 || '');
  const [submitted, setSubmitted] = useState(q0 || '');
  const [tab, setTab] = useState<'top' | 'users' | 'videos' | 'sounds' | 'tags'>('top');
  const submit = (v: string): void => {
    setQ(v);
    setSubmitted(v);
    pushHistory(v);
  };
  const typing = q !== submitted;
  return (
    <div className="screen search">
      <div className="search-bar">
        <button className="icon-btn" onClick={back} aria-label={t('Назад')}>
          <Icon n="back" />
        </button>
        <div className="search-input">
          <Icon n="search" size={18} />
          <input id="search-q" autoFocus placeholder={t('Поиск')} value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && submit(q)} />
          {q && (
            <button className="icon-btn" onClick={() => (setQ(''), setSubmitted(''))} aria-label={t('Очистить')}>
              <Icon n="close" size={16} />
            </button>
          )}
        </div>
        <button className="link-btn accent" onClick={() => submit(q)}>
          {t('Найти')}
        </button>
      </div>
      {!submitted || typing ? (
        <div className="scroll">
          {q.trim() ? (
            <Suggestions q={q} onPick={submit} />
          ) : (
            <>
              {(S.me.sh || []).length > 0 && (
                <div className="pad-x">
                  <div className="row">
                    <b className="grow">{t('Недавние')}</b>
                    <button className="link-btn" onClick={() => void act(() => patchMe({ sh: [] }))}>
                      {t('Очистить всё')}
                    </button>
                  </div>
                  {(S.me.sh || []).map((h) => (
                    <div key={h} className="row hist-row">
                      <Icon n="clock" size={18} />
                      <button className="grow left link-plain" onClick={() => submit(h)}>
                        {h}
                      </button>
                      <button className="icon-btn" onClick={() => void act(() => patchMe({ sh: (S.me.sh || []).filter((x) => x !== h) }))} aria-label={t('Удалить')}>
                        <Icon n="close" size={16} />
                      </button>
                    </div>
                  ))}
                </div>
              )}
              <Discover compact />
            </>
          )}
        </div>
      ) : (
        <>
          <Tabs
            className="tabs-scroll"
            value={tab}
            onChange={setTab}
            items={[
              ['top', t('Топ')],
              ['users', t('Пользователи')],
              ['videos', t('Видео')],
              ['sounds', t('Звуки')],
              ['tags', t('Хэштеги')],
            ]}
          />
          <div className="scroll">
            <Results q={submitted} tab={tab} setTab={setTab} />
          </div>
        </>
      )}
    </div>
  );
}

function Suggestions({ q, onPick }: { q: string; onPick: (v: string) => void }): React.ReactElement {
  const users = searchUsers(q, 4);
  const tags = searchTags(q, 4);
  return (
    <div>
      {users.map((u) => (
        <button key={u} className="menu-item" onClick={() => go('profile', { uid: u })}>
          <Avatar uid={u} size={32} />
          <span className="grow left">
            {S.u[u].nm} <small className="muted">@{S.u[u].un}</small>
          </span>
        </button>
      ))}
      {tags.map((x) => (
        <button key={x.tag} className="menu-item" onClick={() => go('tag', { tag: x.tag })}>
          <Icon n="hash" size={20} />
          <span className="grow left">#{x.tag}</span>
          <small className="muted">{fmtCount(x.views)}</small>
        </button>
      ))}
      <button className="menu-item" onClick={() => onPick(q)}>
        <Icon n="search" size={20} />
        <span className="grow left">{t('Искать «{q}»', { q })}</span>
      </button>
    </div>
  );
}

function Results({ q, tab, setTab }: { q: string; tab: string; setTab: (v: 'top' | 'users' | 'videos' | 'sounds' | 'tags') => void }): React.ReactElement {
  const users = searchUsers(q, tab === 'top' ? 3 : 40);
  const posts = searchPosts(q, tab === 'top' ? 12 : 90);
  const sounds = searchSounds(q, t('Оригинальный звук'), tab === 'top' ? 3 : 40);
  const tags = searchTags(q, tab === 'top' ? 4 : 40);
  if (tab === 'users') return users.length ? <>{users.map((u) => <UserRow key={u} uid={u} />)}</> : <Empty icon="user" title={t('Никого не нашли')} />;
  if (tab === 'videos') return <PostGrid keys={posts} src="search" empty={<Empty icon="video" title={t('Ничего не нашли')} />} />;
  if (tab === 'sounds') return sounds.length ? <>{sounds.map((s) => <SoundLine key={s.key} k={s.key} />)}</> : <Empty icon="music" title={t('Звуков не нашли')} />;
  if (tab === 'tags') return tags.length ? <>{tags.map((x) => <TagLine key={x.tag} tag={x.tag} />)}</> : <Empty icon="hash" title={t('Хэштегов не нашли')} />;
  const nothing = !users.length && !posts.length && !sounds.length && !tags.length;
  if (nothing) return <Empty icon="search" title={t('Ничего не нашли')} text={t('Попробуйте другой запрос')} />;
  return (
    <div>
      {users.length > 0 && (
        <section>
          <div className="sec-hdr">
            <b>{t('Пользователи')}</b>
            <button className="link-btn" onClick={() => setTab('users')}>
              {t('Все')}
            </button>
          </div>
          {users.map((u) => (
            <UserRow key={u} uid={u} />
          ))}
        </section>
      )}
      {tags.length > 0 && (
        <section>
          <div className="sec-hdr">
            <b>{t('Хэштеги')}</b>
          </div>
          {tags.map((x) => (
            <TagLine key={x.tag} tag={x.tag} />
          ))}
        </section>
      )}
      {sounds.length > 0 && (
        <section>
          <div className="sec-hdr">
            <b>{t('Звуки')}</b>
          </div>
          {sounds.map((s) => (
            <SoundLine key={s.key} k={s.key} />
          ))}
        </section>
      )}
      {posts.length > 0 && (
        <section>
          <div className="sec-hdr">
            <b>{t('Видео')}</b>
          </div>
          <PostGrid keys={posts} src="search" />
        </section>
      )}
    </div>
  );
}

export function TagLine({ tag }: { tag: string }): React.ReactElement {
  const x = agg().tags.get(tag);
  return (
    <button className="menu-item" onClick={() => go('tag', { tag })}>
      <span className="tag-ic">#</span>
      <span className="grow left">
        <b>#{tag}</b>
        <small className="muted block">
          {fmtCount(x?.posts.length || 0)} {t('публикаций')} · {fmtCount(x?.views || 0)} {t('просмотров')}
        </small>
      </span>
    </button>
  );
}
function SoundLine({ k }: { k: string }): React.ReactElement | null {
  const s = agg().sounds.get(k);
  if (!s) return null;
  return (
    <button className="menu-item" onClick={() => go('sound', { key: k })}>
      {s.cover ? <img className="sq-cover" src={msrc(s.cover)} alt="" /> : <Avatar uid={s.au} size={44} />}
      <span className="grow left min0">
        <b className="ell block">{soundName(s, t('Оригинальный звук'))}</b>
        <small className="muted">
          {fmtCount(s.posts.length)} {t('видео')}
        </small>
      </span>
    </button>
  );
}

/** Explore: banners, trending hashtags (with previews) and popular sounds. */
export function Discover({ compact }: { compact?: boolean }): React.ReactElement {
  useStore();
  const tags = trendingTags(compact ? 6 : 12);
  const sounds = searchSounds('', t('Оригинальный звук'), 8).filter((s) => s.posts.length > 0);
  const banners = S.mod.banners || [];
  const A = agg();
  const hot = [...A.posts.values()]
    .filter((p) => p.priv === 'all' && canSee(p) && now() - p.ts < 14 * DAY)
    .sort((a, b) => popularity(b) - popularity(a))
    .slice(0, 9)
    .map((p) => p.key);
  return (
    <div className="discover">
      {banners.length > 0 && (
        <div className="hscroll banners">
          {banners.map((b) => (
            <button key={b.id} className="banner" style={{ background: b.color }} onClick={() => b.tag && go('tag', { tag: b.tag })}>
              <b>{b.title}</b>
              <span>{b.text}</span>
            </button>
          ))}
        </div>
      )}
      <div className="sec-hdr pad-x">
        <b>{t('В тренде')}</b>
      </div>
      {tags.length === 0 && <p className="muted pad-x">{t('Тренды появятся, когда в публикациях будут хэштеги')}</p>}
      {tags.map((x) => (
        <div key={x.tag} className="trend">
          <TagLine tag={x.tag} />
          {!compact && (
            <div className="hscroll trend-row">
              {x.posts
                .map((k) => getPost(k))
                .filter((p): p is NonNullable<typeof p> => !!p && canSee(p))
                .slice(0, 8)
                .map((p) => (
                  <div key={p.key} className="trend-thumb">
                    <Thumb post={p} onClick={() => go('post', { postKey: p.key, list: x.posts, src: 'tag' })} />
                  </div>
                ))}
            </div>
          )}
        </div>
      ))}
      {sounds.length > 0 && (
        <>
          <div className="sec-hdr pad-x">
            <b>{t('Популярные звуки')}</b>
          </div>
          {sounds.map((s) => (
            <SoundLine key={s.key} k={s.key} />
          ))}
        </>
      )}
      {!compact && hot.length > 0 && (
        <>
          <div className="sec-hdr pad-x">
            <b>{t('Популярное сейчас')}</b>
          </div>
          <PostGrid keys={hot} src="explore" />
        </>
      )}
    </div>
  );
}

export function TagScreen({ tag }: { tag: string }): React.ReactElement {
  useStore();
  const [tab, setTab] = useState<'top' | 'new'>('top');
  const x = agg().tags.get(tag);
  const keys = (x?.posts || [])
    .map((k) => getPost(k))
    .filter((p): p is NonNullable<typeof p> => !!p && canSee(p))
    .sort((a, b) => (tab === 'top' ? popularity(b) - popularity(a) : (b.at || b.ts) - (a.at || a.ts)))
    .map((p) => p.key);
  const desc = S.mod.tagDesc?.[tag];
  return (
    <div className="screen">
      <Header title={'#' + tag} />
      <div className="scroll">
        <div className="tag-head pad">
          <span className="tag-big">#</span>
          <div className="col gap-s min0">
            <b className="tag-title">#{tag}</b>
            <small className="muted">
              {fmtCount(x?.views || 0)} {t('просмотров')} · {fmtCount(keys.length)} {t('публикаций')}
            </small>
            {desc && <p className="tag-desc">{desc}</p>}
          </div>
        </div>
        <Tabs value={tab} onChange={setTab} items={[['top', t('Популярные')], ['new', t('Новые')]]} />
        <PostGrid keys={keys} src="tag" empty={<Empty icon="hash" title={t('Пока нет публикаций с этим хэштегом')} />} />
      </div>
      {!S.readOnly && (
        <div className="float-cta">
          <button className={cx('btn btn-primary btn-lg')} onClick={() => go('create', { tag })}>
            <Icon n="video" size={20} /> {t('Снять видео с этим хэштегом')}
          </button>
        </div>
      )}
    </div>
  );
}
